# AZX Scanner v3.0

Free Fire Trace Engine: deteksi jejak cheat + verifikasi integritas Free Fire terhadap versi Play Store.

## Prinsip root / non-root
- **Non-root:** hal yang memang tidak bisa dibuka tanpa root (`/data/adb`, `/data/data`, `Android/data`, memori game, `kallsyms`) dilaporkan sebagai **"tidak dapat diverifikasi"** (catatan INFO), **bukan cheat**.
- **Root (akses su diberikan):** semua itu dibaca lewat `su` dan diperiksa penuh.
- Root, VPN, bootloader unlocked, USB debugging = **LOW** (informasi). Status **CHEAT** hanya bila ada bukti nyata (HIGH) atau minimal 3 indikasi MEDIUM.

## Yang dicek
| Modul | Non-root | Root |
|-------|:-------:|:----:|
| Sumber install FF (Play Store / toko lain / sideload) | ✓ | ✓ |
| Sertifikat penanda tangan, kunci debug, debuggable | ✓ | ✓ |
| Isi APK + split di-hash (libil2cpp.so, libunity.so, global-metadata.dat, dex) | ✓ | ✓ |
| ELF menyamar (bukan .so), .so palsu, DEX tersembunyi, entry ganda | ✓ | ✓ |
| Perbandingan dengan baseline Play Store (hash, rename, hilang, tambahan) | ✓ | ✓ |
| Lib hasil ekstrak vs isi APK | ✓ (bila terbaca) | ✓ |
| Jejak root yang terlihat dari mount & library di proses scanner | ✓ | ✓ |
| Memori game `/proc/PID/maps` (lib dari lokasi aneh, memfd, deleted, rwx, hook) | – | ✓ |
| Folder data game (ELF/DEX menyamar, residual hook/inject/drip) | Android <= 10 | ✓ |
| Modul Magisk/KernelSU di `/data/adb/modules`, simbol kernel | – | ✓ |
| Package, container/virtual space, accessibility, Shizuku, ADB, port | ✓ | ✓ |

## Modul Proxy/VPN (baru v5.1)
Cheat berbasis proxy/VPN memakai VpnService per-aplikasi (hanya Free Fire) sehingga tidak muncul sebagai VPN di scanner. Modul `ProxyVpnScanner` memakai korelasi sinyal:
| Sinyal | Non-root | Root |
|--------|:-------:|:----:|
| App ber-VpnService: bedah isi APK (packer/shell, native tun2socks, APK tersembunyi di assets, nama entri aneh, izin overlay, bukan Play Store) | ✓ | ✓ |
| Nama package / string sampel cheat dikenal (BAGASXIT PROXY) | ✓ | ✓ |
| Interface tun/ppp/wg ada tetapi VPN tidak terlihat (VPN per-app tersembunyi) | ✓ (best effort) | ✓ |
| Proxy sistem, CA pengguna | ✓ | ✓ |
| Overlay menutupi scanner saat dipakai | ✓ | ✓ |
| Pemilik VPN aktif (dumpsys connectivity) | – | ✓ |
| Free Fire diarahkan ke tun (ip rule per-UID, koneksi ss) | – | ✓ |

HIGH hanya bila: sampel dikenal, skor APK >= 5, atau VPN aktif + app VPN mencurigakan (korelasi).

## Validasi dari ISI, anti salah deteksi (baru v5.4)
Prinsip: **nama tidak pernah cukup**. Nama hanya memilih apa yang diperiksa; vonis berat (HIGH) hanya dari isi yang menunjukkan alat cheat.

**Aturan anti salah deteksi (dikunci di `VerdictPolicy.kt`, diuji di `VerdictPolicyTest.kt`)**
1. Temuan lingkungan (root, ROM/kernel custom, bootloader, framework injeksi umum) tidak pernah mempengaruhi vonis, seberapa pun severity-nya.
2. CHEAT hanya bila ada temuan bukti bersaverity HIGH, dan HIGH hanya dibuat dari bukti isi/sumber, bukan nama.
3. Berapa pun jumlah MEDIUM tidak pernah naik menjadi CHEAT (paling tinggi PERLU DIPERIKSA).
4. LOW dan INFO tidak mempengaruhi vonis.
Menjalankan uji: `./gradlew testDebugUnitTest` (atau `gradle testDebugUnitTest` bila workflow memakai Gradle terpasang). Uji tidak ikut `assembleRelease`, jadi tidak menghambat build APK.
Uji mencakup: HP root+ROM custom+Zygisk tanpa cheat harus BERSIH, nama mirip cheat tanpa bukti isi tidak boleh CHEAT, banyak MEDIUM tidak boleh CHEAT, bukti isi harus CHEAT, dan klasifikasi judul ENV vs bukti.

**Cheat root berbasis menu melayang + driver kernel (baru v5.5)**
| Sinyal | Non-root | Root | Hasil |
|--------|:-------:|:----:|-------|
| App meminta izin root (ACCESS_SUPERUSER) + overlay + dex berisi kelas menu cheat (ESPView, Aimbot, HackerFloat, dll) | ✓ | ✓ | HIGH (tiga bukti isi sekaligus) |
| Kelas menu cheat + salah satu dari root/overlay | ✓ | ✓ | MEDIUM |
| Root + overlay + isi menyebut Free Fire, tanpa kelas cheat | ✓ | ✓ | MEDIUM |
| Root + overlay saja | ✓ | ✓ | LOW |
| Proses lain membuka memori/maps Free Fire (perilaku nyata) | – | ✓ | HIGH |
| Modul kernel bernama mirip driver cheat dan berkasnya tidak ada di partisi sistem | – | ✓ | MEDIUM |
| Modul kernel tanpa berkas di partisi sistem | – | ✓ | LOW (bisa dari ROM/ramdisk sah) |

Batas jujur: driver kernel yang membaca memori tanpa membuka `/proc/<pid>/mem`, tanpa nama mencurigakan, dan tanpa app pendamping yang terbaca, tidak bisa dipastikan dari aplikasi biasa. Pola kelas bisa diacak, dan bila diacak hasilnya turun ke MEDIUM/LOW, bukan CHEAT.

**Tiga vonis**
| Vonis | Syarat |
|-------|--------|
| CHEAT | Ada bukti HIGH dari isi/sumber (mis. string sampel cheat/packer/tunnel di isi APK, library asing berpenanda hook di proses game, modul root berpenanda hook yang menyebut Free Fire, tracer = alat cheat, file hook terbukti dari isinya) |
| PERLU DIPERIKSA | Hanya indikasi (MEDIUM): nama mirip cheat tapi isi belum terbukti, port Frida tanpa pemilik, perubahan data saat game mati, dll. **Tidak disimpulkan cheat** |
| BERSIH | Tidak ada bukti. Tanpa root ditampilkan "BERSIH (terbatas)" karena banyak hal memang tidak bisa diperiksa |

**Lingkungan perangkat bukan bukti cheat.** Root, ROM custom, kernel custom/KernelSU, bootloader unlocked, mount Magisk, simbol kernel, Zygisk/LSPosed yang hanya terpasang tidak pernah mempengaruhi vonis. Muncul di bagian terpisah "Lingkungan perangkat (BUKAN bukti cheat)" dan ada "Profil perangkat" (ROM stok/custom, bootloader, kernel).

**Yang diperiksa dari isi, bukan nama**
| Objek | Cara validasi isi | Hasil |
|-------|-------------------|-------|
| Package bernama mirip cheat | Bedah dex/lib/manifest: string sampel, packer, tunnel, penanda hook | isi cocok = HIGH, nama saja = MEDIUM |
| Library di proses game (root) | Library asing (bukan sistem/bukan milik FF) dicari penanda hook (MSHookFunction, DobbyHook, xhook, shadowhook, SandHook, frida-gadget, dll) | penanda ada = HIGH, nama mirip tanpa penanda = MEDIUM |
| Zygisk/LSPosed/Riru/Xposed di proses game | Dicek apakah modulnya menyebut paket Free Fire | menargetkan FF = MEDIUM, sekadar ada = LOW (lingkungan) |
| Modul `/data/adb/modules` (root) | grep isi seluruh modul: menyebut paket Free Fire? memuat penanda hook? | hook + FF = HIGH, menyebut FF = MEDIUM, nama saja = LOW |
| File residu di data game / `/data/local/tmp` | Isi file dicari penanda hook | terbukti = HIGH, nama saja = MEDIUM |
| TracerPid pada game (root) | Identitas proses tracer dibaca | frida/GameGuardian/CheatEngine = HIGH, lainnya = MEDIUM |
| Port Frida | Root: pemilik port dilihat; tanpa root pemilik tak terlihat | proses frida = HIGH, selainnya = MEDIUM |
| Sumber install bukan Play Store | Tidak lagi dianggap bukti; dinilai dari sertifikat + hash isi APK (butuh baseline) | LOW |
| Sesi ADB | Hanya jalur/perintah ubah data game yang dihitung; sekadar menjalankan game bukan bukti | lihat Modul ADB |
| Virtual space / Shizuku / accessibility bernama aneh | Nama/keberadaan saja = bukan bukti | LOW/MEDIUM |

**Non-root**: bagian yang tidak bisa dibuka (memori game, `/data/adb`, data game Android 11+) tetap "tidak dapat diverifikasi", dan tidak pernah dianggap cheat.
**Root**: belum diuji di perangkat nyata (v5.4). Cek hasil pertama dengan teliti dan laporkan temuan yang janggal.

## Modul ADB (baru v5.3): cari perangkat TERSAMBUNG, bukan sekadar setelan menyala
Debugging nirkabel / USB debugging yang hanya menyala **bukan cheat**. `AdbSessionScanner` menilai sesi nyata:
| Kondisi | Severity |
|---------|:--------:|
| Setelan menyala, tidak ada perangkat tersambung (atau tanpa root: tidak dapat diverifikasi) | INFO |
| Perangkat tersambung (USB atau nirkabel) | LOW |
| Tersambung + Free Fire sedang berjalan | MEDIUM |
| ADB dari HP sendiri / localhost (pola Shizuku, LADB) | MEDIUM |
| Tersambung + bukti data game diubah (file berpemilik shell, sesi shell menyebut data game, file game berubah saat game mati) | HIGH |
| Sisa file kiriman shell di data game tanpa sesi aktif | MEDIUM |
| Non-root | Status USB dibaca dari broadcast sistem; koneksi nirkabel tidak bisa dipastikan = INFO |
| Root | soket `adbd` (ss/netstat), anak proses `adbd`, proses user shell, `find -user 2000` dan perubahan 20 menit terakhir di data game |

## Jejak walau sudah dihapus / diputus (baru v5.3)
Modul `TraceHistoryScanner` + `TraceJournal` + `PackageRemovedReceiver`.
| Jejak | Non-root | Root |
|-------|:-------:|:----:|
| Aplikasi yang hilang sejak scan terakhir (jurnal snapshot) | ✓ (mulai scan pertama v5.3) | ✓ |
| Waktu PASTI aplikasi dihapus (receiver sistem) | ✓ bila scanner pernah dibuka dan tidak di-force-stop | ✓ |
| Perubahan status USB debugging / debugging nirkabel antar scan (rentang waktu) | ✓ | ✓ |
| Aplikasi dipasang lewat ADB/sideload 30 hari terakhir | ✓ | ✓ |
| Berkas verifikasi/pairing ADB (`/data/misc/adb`: nama perangkat yang pernah diizinkan, waktu terakhir diubah) | – | ✓ |
| Log sistem: kapan ADB terakhir tersambung / terputus (terbatas buffer log) | – | ✓ |
| Aplikasi yang pernah dipakai tapi kini tidak terpasang (usagestats), sisa folder data app terhapus | – | ✓ |
| File yang pernah didorong ke `/data/local/tmp` (.so/.dex/.apk/.sh, nama hook/inject) | – | ✓ |

Aplikasi cheat yang dihapus = HIGH; mirip alat proxy = MEDIUM. Debugging dimatikan + aplikasi mencurigakan dihapus di rentang waktu yang sama = pola menghapus jejak (MEDIUM).
Batas: waktu terputus yang tepat tidak bisa dibaca tanpa root; log sistem hilang saat restart.

## Kecepatan (v5.3)
- Semua modul scan berjalan paralel (coroutine), hasil digabung berurutan.
- Hash isi APK dibagi paralel per entry (buffer 256 KB), bedah APK app VPN juga paralel.

## Korelasi VPN/proxy (diperketat v5.3)
VPN per-aplikasi yang tersembunyi (interface tun ada, VPN tidak terlihat) + app VPN non-sah berskor >= 2 sekarang langsung HIGH, tidak berhenti di MEDIUM/LOW.

## Baseline (perbandingan dengan FF Play Store)
Baseline = daftar hash isi FF Play Store untuk satu versi.
1. Di HP yang FF-nya dari **Play Store** dan bersih, buka app, tekan **BUAT BASELINE**.
   (Ditolak otomatis bila FF tidak terpasang dari Play Store.)
2. Bagikan file `baseline_<paket>_<versionCode>.json` ke komputer.
3. Taruh di `app/src/main/assets/baselines/`, commit, build ulang. Satu file per versi FF dan per ABI (arm64/armv7).
4. (Opsional) isi `REMOTE_BASELINE_URL` di `IntegrityScanner.kt` agar baseline diunduh dari repo.

Tanpa baseline, scanner tetap memeriksa installer, sertifikat, dan anomali struktural, tetapi perbandingan hash tidak berjalan.

## Build
Letakkan zip ini di repo; workflow GitHub Actions `Build APK` seperti biasa. Lokal: `./gradlew assembleRelease`.

## Catatan
- Tidak ada pemindai yang kebal. Mod yang hanya mengubah memori saat game berjalan hanya terlihat sebagian lewat root.
- Field installer bisa dipalsukan root, karena itu verifikasi utama memakai sertifikat dan hash isi APK.

## Perubahan v3.0 (anti salah deteksi)
- Nama kelas cheat (ESPView, Aimbot, dll.) hanya dihitung bila berupa NAMA KELAS milik app itu sendiri di dex, bukan potongan teks bebas dan bukan kelas di paket SDK (Google, Facebook, bidmachine, Bigo, dst.).
- `AntiBan` dihapus dari daftar penanda: itu istilah SDK iklan, bukan cheat Free Fire.
- Izin overlay dan "bukan dari Play Store" BUKAN bukti cheat. Tanpa bukti dari isi, app seperti itu hanya muncul sebagai catatan INFO.
- "Isi menyebut Free Fire" kini hanya bila memuat nama paket resmi Free Fire, bukan kata "freefire" bebas.
- Modul Proxy/VPN: overlay, baca daftar app, dan sumber non-Play Store hanya menambah skor bila isi APK sudah menunjukkan packer/tunnel/string cheat.
- Sampel root "Shadow Gardem Kernel" (com.shadowgardemx64kernel): paket + string `shadowgardem` kini penanda dikenal; kelas ESPView/HackerFloatBubble milik app + izin root + overlay = HIGH.
- Pola loader daemon (unduh + jalankan biner native sendiri: nativeLaunchDaemon, downloadDaemonWithProgress, dll.) di app yang minta root = HIGH.
- Modul baru "Daemon root" (mode root): proses milik root yang berjalan dari folder data aplikasi. HIGH bila isi APK pemiliknya terbukti cheat; MEDIUM bila aplikasinya sudah dihapus tapi daemon masih hidup; selain itu hanya LOW.
