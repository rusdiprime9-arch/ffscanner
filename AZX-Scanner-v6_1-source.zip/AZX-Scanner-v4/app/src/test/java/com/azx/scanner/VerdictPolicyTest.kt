package com.azx.scanner

import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Kind
import com.azx.scanner.CheatSignatures.Severity
import com.azx.scanner.VerdictPolicy.Verdict
import org.junit.Assert.assertEquals
import org.junit.Test

class VerdictPolicyTest {

    private fun f(title: String, sev: Severity) = Finding(title, "", sev)

    @Test
    fun emptyIsClean() {
        assertEquals(Verdict.CLEAN, VerdictPolicy.decide(emptyList()))
    }

    /** HP root + ROM/kernel custom + Zygisk, tanpa cheat: TIDAK BOLEH CHEAT. */
    @Test
    fun customRomRootZygiskWithoutCheatIsClean() {
        val list = listOf(
            f("Mode root", Severity.INFO),
            f("Profil perangkat", Severity.INFO),
            f("Mount jejak root", Severity.MEDIUM),
            f("Symbol kernel", Severity.MEDIUM),
            f("Library injeksi masuk ke proses scanner", Severity.MEDIUM),
            f("Modul injeksi aktif", Severity.MEDIUM),
            f("Boot state tidak green", Severity.LOW),
            f("Framework injeksi dimuat di proses game", Severity.LOW),
            f("Direktori root manager (/data/adb)", Severity.LOW),
            f("Aplikasi manajer root terpasang", Severity.LOW),
            f("Binary root terlihat", Severity.LOW)
        )
        assertEquals(Verdict.CLEAN, VerdictPolicy.decide(list))
    }

    /** R1: bahkan bila severity lingkungan salah dibuat HIGH, vonis tidak boleh CHEAT. */
    @Test
    fun environmentNeverCountsEvenIfHigh() {
        val list = listOf(f("Mount jejak root", Severity.HIGH), f("Symbol kernel", Severity.HIGH))
        assertEquals(Verdict.CLEAN, VerdictPolicy.decide(list))
    }

    /** Nama mirip cheat tanpa bukti isi: TIDAK PERNAH CHEAT (hanya tampil sebagai indikasi belum terbukti). */
    @Test
    fun nameOnlyIsNeverCheat() {
        assertEquals(
            Verdict.CLEAN,
            VerdictPolicy.decide(listOf(f("Package bernama mirip cheat (isi belum terbukti)", Severity.MEDIUM)))
        )
        assertEquals(
            Verdict.CLEAN,
            VerdictPolicy.decide(listOf(f("Library bernama mirip cheat (isi belum menunjukkan hook)", Severity.MEDIUM)))
        )
        assertEquals(
            Verdict.CLEAN,
            VerdictPolicy.decide(listOf(f("Binary bernama mirip hook (isi belum terbukti)", Severity.MEDIUM)))
        )
    }

    /** R3: banyak MEDIUM tidak pernah naik jadi CHEAT, tetapi tetap terhitung sebagai indikasi belum terbukti. */
    @Test
    fun manyMediumStaysCleanButIsCounted() {
        val list = (1..8).map { f("Indikasi lemah $it", Severity.MEDIUM) }
        assertEquals(Verdict.CLEAN, VerdictPolicy.decide(list))
        assertEquals(8, VerdictPolicy.unprovenCount(list))
    }

    /** Bukti isi di luar Play Store (nama paket tidak mirip cheat) harus CHEAT. */
    @Test
    fun sideloadedContentEvidenceIsCheat() {
        val t = "Alat cheat terbukti dari isi APK"
        assertEquals(Verdict.CHEAT, VerdictPolicy.decide(listOf(f(t, Severity.HIGH))))
    }

    @Test
    fun lowAndInfoOnlyIsClean() {
        val list = listOf(
            f("Debugging nirkabel menyala, tidak ada perangkat tersambung", Severity.INFO),
            f("Aplikasi dipasang lewat ADB/sideload dalam 30 hari (2)", Severity.LOW),
            f("Virtual space terpasang", Severity.LOW),
            f("[com.dts.freefiremax] Bukan dari Play Store", Severity.LOW)
        )
        assertEquals(Verdict.CLEAN, VerdictPolicy.decide(list))
    }

    /** Bukti dari isi/sumber: harus CHEAT. */
    @Test
    fun contentBackedHighIsCheat() {
        val titles = listOf(
            "Package cheat terbukti dari isi APK",
            "Library asing berpenanda hook dimuat di proses game",
            "Modul root cheat terbukti dari isi",
            "Proses game di-trace oleh alat cheat",
            "Residual hook terbukti dari isi",
            "Binary hook terbukti dari isi",
            "Frida dimuat di proses game",
            "Menu cheat root terbukti dari isi",
            "Proses lain membuka memori game"
        )
        for (t in titles) assertEquals(t, Verdict.CHEAT, VerdictPolicy.decide(listOf(f(t, Severity.HIGH))))
    }

    /** Satu bukti HIGH di tengah banyak lingkungan custom tetap CHEAT. */
    @Test
    fun realEvidenceSurvivesAmongEnvironmentNoise() {
        val list = listOf(
            f("Mount jejak root", Severity.MEDIUM),
            f("Modul injeksi aktif", Severity.MEDIUM),
            f("Library asing berpenanda hook dimuat di proses game", Severity.HIGH)
        )
        assertEquals(Verdict.CHEAT, VerdictPolicy.decide(list))
    }

    /** Penjaga: judul lingkungan harus terklasifikasi ENV, judul bukti harus EVIDENCE. */
    @Test
    fun titleClassification() {
        val env = listOf(
            "Mode root", "Mode root ditolak", "Mode non-root", "Profil perangkat", "Mount jejak root", "Symbol kernel",
            "Library injeksi masuk ke proses scanner", "Modul injeksi aktif", "Boot state tidak green",
            "ro.debuggable=1", "ro.secure=0", "Direktori root manager (/data/adb)", "Binary root terlihat",
            "Aplikasi manajer root terpasang", "Daftar modul root", "Framework injeksi dimuat di proses game"
        )
        for (t in env) assertEquals(t, Kind.ENV, f(t, Severity.LOW).kind)

        val evidence = listOf(
            "Package cheat terbukti dari isi APK", "Package bernama mirip cheat (isi belum terbukti)",
            "Modul root cheat terbukti dari isi", "Modul root menyebut paket Free Fire",
            "Modul root bernama mirip cheat (isi tidak menyebut Free Fire)", "Cakupan LSPosed menyebut Free Fire",
            "Library asing berpenanda hook dimuat di proses game", "Frida dimuat di proses game",
            "Proses game sedang di-trace", "Port Frida listen", "Perangkat tersambung via ADB nirkabel (1)",
            "Aplikasi mencurigakan SUDAH DIHAPUS", "Korelasi: VPN aktif + app VPN mencurigakan",
            "Menu cheat root terbukti dari isi", "Kemungkinan menu cheat (isi menyebut kelas ESP/aimbot)",
            "App root + overlay menyebut Free Fire (isi belum terbukti cheat)", "App meminta root + overlay",
            "Proses lain membuka memori game", "Modul kernel tanpa berkas di partisi sistem (3)",
            "Modul kernel bernama mirip driver cheat (isi belum terbukti)"
        )
        for (t in evidence) assertEquals(t, Kind.EVIDENCE, f(t, Severity.LOW).kind)
    }
}
