package com.azx.scanner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Severity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Jejak yang tersisa walau aplikasi sudah dihapus / debugging sudah diputus.
 *
 * Tanpa root (jurnal lokal, dimulai sejak scan pertama versi ini):
 *  - aplikasi yang hilang sejak scan terakhir + waktu pasti hapus bila receiver sempat mencatat
 *  - perubahan status USB debugging / debugging nirkabel antar scan
 *  - aplikasi dipasang lewat ADB / sideload dalam 30 hari terakhir
 *
 * Dengan root (riwayat sistem):
 *  - berkas verifikasi ADB di /data/misc/adb (kunci, perangkat yang pernah diizinkan, waktu terakhir)
 *  - log sistem: kapan ADB terakhir tersambung / terputus, kapan paket dihapus (terbatas ukuran buffer log)
 *  - dumpsys usagestats: aplikasi yang pernah dipakai tetapi kini tidak terpasang + waktu terakhir dipakai
 *  - sisa folder data aplikasi yang sudah dihapus, dan file yang pernah didorong ke /data/local/tmp
 */
class TraceHistoryScanner(
    private val context: Context,
    private val rootGranted: Boolean,
    private val su: (String) -> String?
) {
    private val out = mutableListOf<Finding>()
    private val pm = context.packageManager
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    private class Removed(val pkg: String) {
        var label: String? = null
        var whenMs: Long? = null
        var from: Long? = null
        var to: Long? = null
        var lastSeen: Long? = null
        var lastSeenSrc: String = ""
        var wasSuspicious = false
        val sources = linkedSetOf<String>()
        fun bestTime(): Long = whenMs ?: to ?: lastSeen ?: 0L
    }

    private class AdbChange(val label: String, val from: Long, val to: Long, val turnedOff: Boolean)

    private val removed = LinkedHashMap<String, Removed>()
    private val adbChanges = mutableListOf<AdbChange>()

    private fun add(title: String, detail: String, sev: Severity) {
        out += Finding(title, detail, sev)
    }

    fun scan(): List<Finding> {
        val now = System.currentTimeMillis()
        val current = currentSnapshot()
        try { journalStep(now, current) } catch (e: Exception) { }
        try { sideloadStep(now) } catch (e: Exception) { }
        if (rootGranted) {
            try { rootHistoryStep(now) } catch (e: Exception) { }
        }
        reportRemoved()
        reportAdbChanges()
        return out
    }

    // -------------------------------------------------------------------------
    // Snapshot aplikasi pengguna
    // -------------------------------------------------------------------------
    private class AppRow(val pkg: String, val label: String, val install: Long, val installer: String?, val vpn: Boolean, val overlay: Boolean)

    private val rows = mutableListOf<AppRow>()

    private fun currentSnapshot(): Map<String, TraceJournal.Snap> {
        val map = LinkedHashMap<String, TraceJournal.Snap>()
        @Suppress("DEPRECATION")
        val pkgs: List<PackageInfo> = try {
            pm.getInstalledPackages(PackageManager.GET_SERVICES or PackageManager.GET_PERMISSIONS)
        } catch (e: Exception) {
            emptyList()
        }
        for (p in pkgs) {
            if (p.packageName == context.packageName) continue
            val ai = p.applicationInfo ?: continue
            val sys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (sys) continue
            val name = p.packageName
            val label = try { pm.getApplicationLabel(ai).toString() } catch (e: Exception) { name }
            val vpn = p.services?.any { it.permission == "android.permission.BIND_VPN_SERVICE" } == true
            val overlay = p.requestedPermissions?.contains("android.permission.SYSTEM_ALERT_WINDOW") == true
            val installer = installerOf(name)
            rows += AppRow(name, label, p.firstInstallTime, installer, vpn, overlay)

            val nameCheat = isCheatName(name)
            val nonPlay = installer != "com.android.vending"
            val susp = nameCheat || (vpn && nonPlay && name !in CheatSignatures.LEGIT_VPN_PACKAGES) || (vpn && overlay && nonPlay)
            map[name] = TraceJournal.Snap(label, p.firstInstallTime, susp)
        }
        return map
    }

    // -------------------------------------------------------------------------
    // A. Jurnal lokal (non-root)
    // -------------------------------------------------------------------------
    private fun journalStep(now: Long, current: Map<String, TraceJournal.Snap>) {
        val journal = TraceJournal(context)
        val prev = journal.loadSnapshot()
        val lastScan = journal.lastScan()
        val oldEvents = journal.events()
        val newEvents = mutableListOf<TraceJournal.Event>()

        // aplikasi yang ada di scan lalu tetapi kini hilang
        for ((pkg, s) in prev) {
            if (pkg in current) continue
            val covered = oldEvents.any { it.type == "REMOVED" && it.name == pkg && it.time >= lastScan }
            if (!covered) {
                newEvents += TraceJournal.Event("GONE", pkg, s.label, 0L, lastScan, now, s.susp)
            }
        }

        // perubahan status debugging
        val wifi = settingInt("adb_wifi_enabled")
        val usb = settingInt(Settings.Global.ADB_ENABLED)
        val prevAdb = journal.adbState()
        if (prevAdb != null) {
            if (prevAdb.first != wifi) {
                newEvents += TraceJournal.Event(
                    "ADB", "wifi", "Debugging nirkabel: ${onOff(prevAdb.first)} -> ${onOff(wifi)}",
                    0L, lastScan, now, wifi == 0
                )
            }
            if (prevAdb.second != usb) {
                newEvents += TraceJournal.Event(
                    "ADB", "usb", "USB debugging: ${onOff(prevAdb.second)} -> ${onOff(usb)}",
                    0L, lastScan, now, usb == 0
                )
            }
        }

        journal.addEvents(newEvents)
        journal.saveSnapshot(current, now)
        journal.saveAdbState(wifi, usb)

        if (prev.isEmpty() && lastScan == 0L) {
            add(
                "Jurnal jejak dimulai",
                "Mulai scan ini scanner mencatat aplikasi yang dipasang, status debugging, dan penghapusan aplikasi. " +
                    "Penghapusan atau perubahan debugging SETELAH scan ini akan terlihat di scan berikutnya " +
                    "(waktu pasti bila scanner belum di-force-stop).",
                Severity.INFO
            )
        }

        val limit = now - RECENT_MS
        for (e in journal.events()) {
            if (maxOf(e.time, e.to) < limit) continue
            when (e.type) {
                "REMOVED", "GONE" -> {
                    val r = removed.getOrPut(e.name) { Removed(e.name) }
                    r.label = e.label
                    if (e.type == "REMOVED") r.whenMs = e.time else { r.from = e.from; r.to = e.to }
                    r.wasSuspicious = r.wasSuspicious || e.susp
                    r.sources += "jurnal"
                }
                "ADB" -> adbChanges += AdbChange(e.label, e.from, e.to, e.susp)
            }
        }
    }

    private fun onOff(v: Int) = if (v == 1) "menyala" else "mati"

    // -------------------------------------------------------------------------
    // B. Aplikasi dipasang lewat ADB / sideload (non-root)
    // -------------------------------------------------------------------------
    private fun sideloadStep(now: Long) {
        val limit = now - RECENT_MS_30D
        val recent = rows.filter {
            (it.installer == null || it.installer == "com.android.shell") && it.install >= limit
        }.sortedByDescending { it.install }
        if (recent.isEmpty()) return
        val risky = recent.filter { it.vpn || it.overlay || isCheatName(it.pkg) }
        val detail = recent.take(8).joinToString("\n") {
            val tags = listOfNotNull(
                if (it.vpn) "punya VpnService" else null,
                if (it.overlay) "izin overlay" else null
            ).joinToString(", ")
            "- ${it.label} (${it.pkg}) dipasang ${fmt.format(Date(it.install))}" + if (tags.isNotEmpty()) " [$tags]" else ""
        }
        add(
            "Aplikasi dipasang lewat ADB/sideload dalam 30 hari (${recent.size})",
            "Pemasangan lewat ADB/sideload adalah jalur umum cheat, tetapi juga dipakai pengguna biasa.\n$detail",
            if (risky.isNotEmpty()) Severity.LOW else Severity.INFO
        )
    }

    // -------------------------------------------------------------------------
    // C. Riwayat sistem lewat root
    // -------------------------------------------------------------------------
    private fun rootHistoryStep(now: Long) {
        // Dipecah jadi beberapa skrip yang jalan PARALEL (logcat/dumpsys paling lambat). Penanda ## dan
        // urutan gabungan sama persis dengan skrip tunggal sebelumnya, jadi parsing tidak berubah.
        val parts = listOf(
            buildString {
                append("echo '##KEYS'; ls -l --full-time /data/misc/adb 2>/dev/null; ")
                append("echo '##AKEYS'; cat /data/misc/adb/adb_keys 2>/dev/null | sed 's/^[^ ]* *//' | cut -c1-80; ")
                append("echo '##TEMPKEYS'; cat /data/misc/adb/adb_temp_keys.xml 2>/dev/null | grep -o 'lastConnection=\"[0-9]*\"'; ")
                append("echo '##DUMPADB'; dumpsys adb 2>/dev/null | cut -c1-140 | head -n 40; ")
                append("echo '##LOCALTMP'; ls -l --full-time /data/local/tmp 2>/dev/null; ")
                append("echo '##ORPHAN'; for d in /sdcard/Android/data/* /sdcard/Android/obb/*; do [ -d \"\$d\" ] && stat -c '%y|%n' \"\$d\"; done 2>/dev/null")
            },
            "echo '##LOGADB'; logcat -d -v time 2>/dev/null | grep -iE 'adbd|AdbDebuggingManager|AdbWifi|adb_wifi|adbwifi' | tail -n 150",
            "echo '##LOGPKG'; logcat -d -v time 2>/dev/null | grep -iE 'Removing package|package removed|deletePackage|PACKAGE_FULLY_REMOVED|Uninstalling' | tail -n 150",
            "echo '##USAGE'; dumpsys usagestats 2>/dev/null | grep -E 'type=(ACTIVITY_RESUMED|MOVE_TO_FOREGROUND)' | cut -c1-220 | tail -n 3000"
        )
        val pool = java.util.concurrent.Executors.newFixedThreadPool(parts.size)
        val outs: List<String?> = try {
            parts.map { part -> pool.submit(java.util.concurrent.Callable<String?> { su(part) }) }
                .map { f -> try { f.get() } catch (e: Exception) { null } }
        } finally {
            pool.shutdown()
        }
        if (outs.all { it == null }) return
        val text = outs.joinToString("\n") { it ?: "" } + "\n##END"
        val sec = sections(text)

        adbVerificationFiles(sec, now)
        adbLogHistory(sec, now)
        localTmpHistory(sec)
        removedFromSystem(sec, now)
    }

    private val lsLine = Regex("^\\S+\\s+\\d+\\s+(\\S+)\\s+(\\S+)\\s+\\d+\\s+(\\d{4}-\\d{2}-\\d{2})\\s+(\\d{2}:\\d{2}:\\d{2})\\S*\\s+\\S+\\s+(.+)$")

    private fun adbVerificationFiles(sec: Map<String, List<String>>, now: Long) {
        val files = sec["##KEYS"].orEmpty().mapNotNull { l ->
            val m = lsLine.find(l) ?: return@mapNotNull null
            Triple(m.groupValues[5], m.groupValues[3] + " " + m.groupValues[4], m.groupValues[1])
        }
        val hosts = sec["##AKEYS"].orEmpty().map { it.trim() }.filter { it.isNotEmpty() && it.length < 80 }.distinct()
        val temp = sec["##TEMPKEYS"].orEmpty().mapNotNull { Regex("(\\d{10,})").find(it)?.value?.toLongOrNull() }

        if (files.isEmpty() && hosts.isEmpty() && temp.isEmpty()) return
        val sb = StringBuilder()
        if (files.isNotEmpty()) {
            sb.appendLine("Berkas verifikasi ADB (/data/misc/adb), waktu = terakhir diubah:")
            files.take(8).forEach { sb.appendLine("- ${it.first}  ${it.second}") }
        }
        if (hosts.isNotEmpty()) {
            sb.appendLine("Perangkat/komputer yang pernah diizinkan (${hosts.size}): ${hosts.take(6).joinToString(", ")}")
        }
        temp.maxOrNull()?.let { sb.appendLine("Izin sementara, koneksi terakhir: ${fmt.format(Date(it))}") }
        sb.append("Kunci hanya dibaca namanya, isi kunci tidak ditampilkan. Berkas ini bertahan walau debugging sudah diputus.")
        add("Riwayat verifikasi/pairing ADB", sb.toString(), Severity.INFO)
    }

    private val connectRe = Regex("(?i)connect|authoriz|pair|accept|online|transport")
    private val disconnectRe = Regex("(?i)disconnect|closed|offline|removed|lost|unpair|stopp")

    private fun adbLogHistory(sec: Map<String, List<String>>, now: Long) {
        val lines = sec["##LOGADB"].orEmpty().filter { it.length > 15 && it[2] == '-' }
        if (lines.isEmpty()) return
        var lastConnect: Long? = null
        var lastDisconnect: Long? = null
        for (l in lines) {
            val t = parseLogTime(l, now) ?: continue
            val body = l.substring(14)
            if (disconnectRe.containsMatchIn(body)) lastDisconnect = t
            else if (connectRe.containsMatchIn(body)) lastConnect = t
        }
        val first = parseLogTime(lines.first(), now)
        val sb = StringBuilder()
        sb.appendLine("Terakhir tersambung : ${lastConnect?.let { fmt.format(Date(it)) } ?: "tidak tercatat di log"}")
        sb.appendLine("Terakhir terputus   : ${lastDisconnect?.let { fmt.format(Date(it)) } ?: "tidak tercatat di log"}")
        if (first != null) sb.appendLine("Log sistem mencakup sejak ${fmt.format(Date(first))}")
        sb.append("Buffer log terbatas (jam sampai sehari) dan hilang saat HP restart. Waktu tersambung/terputus di sini adalah perkiraan dari teks log.")
        val recentConnect = lastConnect != null && now - lastConnect < 60 * 60 * 1000L
        add(
            "Riwayat koneksi ADB dari log sistem",
            sb.toString(),
            if (recentConnect) Severity.LOW else Severity.INFO
        )
    }

    private val tmpSuspiciousExt = setOf("so", "dex", "apk", "jar", "sh", "bin", "elf")

    private fun localTmpHistory(sec: Map<String, List<String>>) {
        val hits = mutableListOf<Triple<String, String, Severity>>()
        for (l in sec["##LOCALTMP"].orEmpty()) {
            val m = lsLine.find(l) ?: continue
            val name = m.groupValues[5].substringBefore(" ->").trim()
            val owner = m.groupValues[1]
            val time = m.groupValues[3] + " " + m.groupValues[4]
            val lower = name.lowercase()
            val ext = lower.substringAfterLast('.', "")
            val sev = when {
                isCheatName(name) || CheatSignatures.RESIDUAL_TOKENS.any { lower.contains(it) } || lower.contains("frida") -> Severity.HIGH
                ext in tmpSuspiciousExt -> Severity.LOW
                else -> continue
            }
            hits += Triple("$name  ($owner, $time)", name, sev)
        }
        if (hits.isEmpty()) return
        val worst = if (hits.any { it.third == Severity.HIGH }) Severity.HIGH else Severity.LOW
        add(
            "File didorong ke /data/local/tmp (jalur umum cheat via ADB)",
            hits.take(8).joinToString("\n") { "- ${it.first}" } +
                "\nWaktu = kapan file terakhir diubah/didorong. File ini tetap ada walau sesi ADB sudah putus.",
            worst
        )
    }

    private fun removedFromSystem(sec: Map<String, List<String>>, now: Long) {
        // log sistem: "Removing package com.x"
        val pkgRe = Regex("(?i)(?:removing package|package removed|package|pkg)\\W+([a-z][a-z0-9_]*(?:\\.[a-z0-9_]+)+)")
        for (l in sec["##LOGPKG"].orEmpty()) {
            if (l.length < 16) continue
            val t = parseLogTime(l, now)
            for (m in pkgRe.findAll(l.substring(minOf(14, l.length)))) {
                val pkg = m.groupValues[1]
                if (ignorable(pkg) || isInstalled(pkg)) continue
                val r = removed.getOrPut(pkg) { Removed(pkg) }
                if (t != null && (r.lastSeen == null || t > r.lastSeen!!)) { r.lastSeen = t; r.lastSeenSrc = "log sistem" }
                r.sources += "log"
            }
        }

        // usagestats: pernah dipakai, kini tidak terpasang
        val usageRe = Regex("time=\"?(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})\"?.*?package=(\\S+)")
        val usageFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)
        for (l in sec["##USAGE"].orEmpty()) {
            val m = usageRe.find(l) ?: continue
            val pkg = m.groupValues[2]
            if (ignorable(pkg)) continue
            val t = (try { usageFmt.parse(m.groupValues[1])?.time } catch (e: Exception) { null }) ?: continue
            val known = removed[pkg]
            if (known == null && isInstalled(pkg)) continue
            val r = known ?: Removed(pkg).also { removed[pkg] = it }
            if (r.lastSeen == null || t > r.lastSeen!!) { r.lastSeen = t; r.lastSeenSrc = "riwayat pemakaian" }
            r.sources += "usagestats"
        }

        // sisa folder data aplikasi yang sudah dihapus
        for (l in sec["##ORPHAN"].orEmpty()) {
            val parts = l.split('|', limit = 2)
            if (parts.size < 2) continue
            val pkg = parts[1].substringAfterLast('/')
            if (ignorable(pkg) || isInstalled(pkg)) continue
            val t = try { fmt.parse(parts[0].take(19).replace('T', ' '))?.time } catch (e: Exception) { null }
            val r = removed.getOrPut(pkg) { Removed(pkg) }
            if (t != null && (r.lastSeen == null || t > r.lastSeen!!)) { r.lastSeen = t; r.lastSeenSrc = "sisa folder data" }
            r.sources += "sisa data"
        }
    }

    // -------------------------------------------------------------------------
    // Laporan
    // -------------------------------------------------------------------------
    private fun describe(r: Removed): String {
        val parts = ArrayList<String>()
        val w = r.whenMs
        val f = r.from
        val t = r.to
        val ls = r.lastSeen
        if (w != null && w > 0L) parts += "dihapus ${fmt.format(Date(w))} (dicatat langsung)"
        else if (f != null && t != null) parts += "hilang di antara ${fmt.format(Date(f))} dan ${fmt.format(Date(t))}"
        if (ls != null) parts += "jejak terakhir ${fmt.format(Date(ls))} (${r.lastSeenSrc}), kini tidak terpasang"
        parts += "sumber: ${r.sources.joinToString("+")}"
        return "${r.label ?: r.pkg} (${r.pkg})\n    " + parts.joinToString("\n    ")
    }

    private fun severityOf(r: Removed): Severity = when {
        isCheatName(r.pkg) || r.wasSuspicious -> Severity.HIGH
        looksLikeProxyTool(r.pkg) -> Severity.MEDIUM
        else -> Severity.INFO
    }

    private fun reportRemoved() {
        if (removed.isEmpty()) return
        val list = removed.values.sortedByDescending { it.bestTime() }
        val info = mutableListOf<Removed>()
        for (r in list) {
            when (val sev = severityOf(r)) {
                Severity.INFO -> info += r
                else -> add(
                    if (sev == Severity.HIGH) "Aplikasi mencurigakan SUDAH DIHAPUS" else "Aplikasi mirip alat proxy/cheat sudah dihapus",
                    describe(r) + if (r.wasSuspicious) "\nSudah ditandai mencurigakan pada scan sebelumnya." else "",
                    sev
                )
            }
        }
        if (info.isNotEmpty()) {
            add(
                "Aplikasi yang pernah ada tetapi sudah dihapus (${info.size})",
                info.take(8).joinToString("\n") { "- " + describe(it).replace("\n    ", " | ") },
                Severity.INFO
            )
        }
    }

    private fun reportAdbChanges() {
        if (adbChanges.isEmpty()) return
        val suspiciousRemoved = removed.values.filter { severityOf(it) != Severity.INFO }
        val sorted = adbChanges.sortedByDescending { it.to }
        add(
            "Perubahan status debugging",
            sorted.take(6).joinToString("\n") {
                "- ${it.label} (antara ${fmt.format(Date(it.from))} dan ${fmt.format(Date(it.to))})"
            } + "\nTerputusnya debugging tidak punya waktu pasti tanpa root; rentang di atas adalah jarak antar scan.",
            Severity.INFO
        )
        // pola menutup jejak: debugging dimatikan di rentang yang sama dengan penghapusan aplikasi mencurigakan
        for (c in sorted) {
            if (!c.turnedOff) continue
            val overlap = suspiciousRemoved.firstOrNull { r ->
                val a = r.whenMs ?: r.from ?: r.lastSeen ?: return@firstOrNull false
                val b = r.whenMs ?: r.to ?: a
                a <= c.to && b >= c.from
            }
            if (overlap != null) {
                add(
                    "Pola menghapus jejak: debugging dimatikan + aplikasi mencurigakan dihapus",
                    "${c.label} dan ${overlap.pkg} hilang pada rentang waktu yang sama (${fmt.format(Date(c.from))} s/d ${fmt.format(Date(c.to))}).",
                    Severity.MEDIUM
                )
                break
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private fun isCheatName(pkg: String): Boolean {
        val l = pkg.lowercase()
        return CheatSignatures.KNOWN_CHEAT_PACKAGES.contains(pkg) || CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { l.contains(it) }
    }

    private val proxyHints = listOf("proxy", "vpn", "socks", "inject", "cheat", "hack", "bypass", "antiban", "aimlock", "headshot")

    private fun looksLikeProxyTool(pkg: String): Boolean {
        if (pkg in CheatSignatures.LEGIT_VPN_PACKAGES) return false
        val l = pkg.lowercase()
        return proxyHints.any { l.contains(it) }
    }

    private fun ignorable(p: String): Boolean {
        val l = p.lowercase()
        return l == "android" || !l.contains('.') || l == context.packageName ||
            l.startsWith("com.android.") || l.startsWith("android.") || l.startsWith("com.google.android.") ||
            l.startsWith("com.samsung.") || l.startsWith("com.sec.") || l.startsWith("com.miui.") ||
            l.startsWith("com.xiaomi.") || l.startsWith("com.qualcomm") || l.startsWith("com.mediatek") ||
            l.startsWith("com.oppo.") || l.startsWith("com.coloros.") || l.startsWith("com.vivo.") ||
            l.startsWith("com.huawei.") || l.startsWith("com.oneplus.")
    }

    private fun isInstalled(pkg: String): Boolean = try {
        pm.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun installerOf(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    private fun settingInt(name: String): Int = try {
        Settings.Global.getInt(context.contentResolver, name, 0)
    } catch (e: Exception) {
        0
    }

    /** Baris logcat -v time: "MM-DD HH:MM:SS.mmm ..." (tanpa tahun, dilengkapi dengan tahun berjalan). */
    private fun parseLogTime(line: String, now: Long): Long? = try {
        val stamp = line.take(14)
        val f = SimpleDateFormat("yyyy MM-dd HH:mm:ss", Locale.US)
        val year = Calendar.getInstance().get(Calendar.YEAR)
        var t = f.parse("$year $stamp")?.time
        if (t != null && t > now + 86_400_000L) t = f.parse("${year - 1} $stamp")?.time
        t
    } catch (e: Exception) {
        null
    }

    private fun sections(text: String): Map<String, List<String>> {
        val m = LinkedHashMap<String, MutableList<String>>()
        var cur = ""
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.startsWith("##")) {
                cur = l
                m[cur] = mutableListOf()
                continue
            }
            if (cur.isNotEmpty() && l.isNotEmpty()) m[cur]?.add(l)
        }
        return m
    }

    companion object {
        private const val RECENT_MS = 14L * 24 * 60 * 60 * 1000
        private const val RECENT_MS_30D = 30L * 24 * 60 * 60 * 1000
    }
}
