package com.azx.scanner

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.azx.scanner.CheatSignatures.Severity
import com.azx.scanner.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var engine: ScannerEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        engine = ScannerEngine(this)

        setupWelcome()

        binding.btnScan.setOnClickListener { startScan() }
        binding.btnBaseline.setOnClickListener { makeBaseline() }
    }

    /** Layar sambutan bertema AZZHX; hanya tampilan, tidak menyentuh mesin scan. */
    private fun setupWelcome() {
        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            null
        }
        if (!versionName.isNullOrBlank()) {
            binding.tvVersion.text = "Azzhx Anticheat Enterprise Security Suite · Version $versionName"
        }
        binding.btnGetStarted.setOnClickListener {
            binding.btnGetStarted.isEnabled = false
            binding.scannerLayer.alpha = 0f
            binding.scannerLayer.visibility = View.VISIBLE
            binding.scannerLayer.animate().alpha(1f).setDuration(280).start()
            binding.welcomeLayer.animate().alpha(0f).setDuration(220).withEndAction {
                binding.welcomeLayer.visibility = View.GONE
            }.start()
        }
    }

    private fun color(resId: Int): Int = ContextCompat.getColor(this, resId)

    /** Deteksi overlay: Android menandai sentuhan bila jendela kita tertutup jendela lain. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if ((ev.flags and MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0 ||
            (ev.flags and MotionEvent.FLAG_WINDOW_IS_PARTIALLY_OBSCURED) != 0) {
            engine.overlayObscuredSeen = true
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun startScan() {
        binding.btnScan.isEnabled = false
        binding.btnBaseline.isEnabled = false
        binding.tvStatus.text = "SCAN…"
        binding.tvStatus.setTextColor(color(R.color.azx_text_soft))
        binding.progressScan.visibility = View.VISIBLE
        binding.tvCategory.visibility = View.GONE
        binding.tvCategory.text = ""
        binding.tvDetail.text = "Memindai jejak cheat dan memverifikasi isi APK…\n" +
            "Semua modul dijalankan paralel. Jika ada dialog izin root, pilih IZINKAN."

        // Layar tetap menyala selama scan (tanpa izin tambahan); dilepas lagi di finally.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lifecycleScope.launch {
            try {
                val result = engine.runFullScan()
                showResult(result)
            } finally {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                binding.btnScan.isEnabled = true
                binding.btnBaseline.isEnabled = true
            }
        }
    }

    private fun showResult(result: ScannerEngine.ScanResult) {
        binding.progressScan.visibility = View.INVISIBLE
        when (result.verdict) {
            VerdictPolicy.Verdict.CHEAT -> {
                binding.tvStatus.text = "CHEAT"
                binding.tvStatus.setTextColor(color(R.color.azx_verdict_cheat))
            }
            VerdictPolicy.Verdict.CLEAN -> {
                binding.tvStatus.text = if (result.rootGranted) "BERSIH" else "BERSIH (terbatas)"
                binding.tvStatus.setTextColor(color(R.color.azx_verdict_clean))
            }
        }

        // Kategori jenis cheat (hanya tampilan; vonis tetap dari VerdictPolicy).
        val categories = CheatCategory.summarize(result.findings)
        val unproven = VerdictPolicy.unprovenCount(result.findings)
        if (categories.isNotEmpty()) {
            binding.tvCategory.text = "Kategori: " + CheatCategory.oneLine(categories)
            binding.tvCategory.setTextColor(binding.tvStatus.currentTextColor)
            binding.tvCategory.visibility = View.VISIBLE
        } else if (unproven > 0) {
            binding.tvCategory.text = "$unproven indikasi belum terbukti dari isi (tidak mempengaruhi vonis, lihat detail)"
            binding.tvCategory.setTextColor(color(R.color.azx_text_soft))
            binding.tvCategory.visibility = View.VISIBLE
        } else {
            binding.tvCategory.visibility = View.GONE
        }

        // Bukti (berpengaruh ke vonis) dipisah dari kondisi lingkungan perangkat (root/ROM/kernel custom: bukan cheat).
        val issues = result.findings
            .filter { it.severity == Severity.HIGH && it.kind == CheatSignatures.Kind.EVIDENCE }
        val unprovenList = result.findings
            .filter { (it.severity == Severity.MEDIUM || it.severity == Severity.LOW) && it.kind == CheatSignatures.Kind.EVIDENCE }
            .sortedBy { it.severity.ordinal }
        val env = result.findings.filter { it.severity != Severity.INFO && it.kind == CheatSignatures.Kind.ENV }
        val info = result.findings.filter { it.severity == Severity.INFO }

        val rootText = when {
            result.rooted && result.rootGranted -> "Ya (akses diberikan)"
            result.rooted -> "Ya (akses ditolak)"
            else -> "Tidak"
        }
        val sb = StringBuilder()
        sb.appendLine("Waktu   : ${result.timestamp}")
        sb.appendLine("Root    : $rootText")
        sb.appendLine("Cakupan : ${if (result.rootGranted) "PENUH (root)" else "TERBATAS (non-root)"}")
        sb.appendLine("Bukti   : ${issues.size} terverifikasi dari isi")
        sb.appendLine("Kategori: ${if (categories.isEmpty()) "-" else categories.joinToString(", ") { "${it.category.label} ×${it.count}" }}")
        sb.appendLine("Vonis   : ${when (result.verdict) {
            VerdictPolicy.Verdict.CHEAT -> "ada bukti kuat dari isi/sumber"
            VerdictPolicy.Verdict.CLEAN -> if (result.rootGranted) "tidak ada bukti cheat" else "tidak ada bukti cheat pada bagian yang bisa diperiksa tanpa root"
        }}")
        sb.appendLine()

        if (issues.isEmpty()) {
            sb.appendLine("Tidak ada bukti cheat yang terverifikasi dari isi.")
            sb.appendLine()
        } else {
            issues.forEachIndexed { i, f ->
                sb.appendLine("[${i + 1}] BUKTI [${CheatCategory.classify(f).label}] — ${f.title}")
                sb.appendLine("    ${f.detail.replace("\n", "\n    ")}")
                sb.appendLine()
            }
        }

        if (unprovenList.isNotEmpty()) {
            sb.appendLine("— Indikasi belum terbukti dari isi (TIDAK mempengaruhi vonis) —")
            unprovenList.forEach {
                sb.appendLine("• [${it.severity}] ${it.title}")
                if (it.detail.isNotBlank()) sb.appendLine("    ${it.detail.replace("\n", "\n    ")}")
            }
            sb.appendLine()
        }

        if (env.isNotEmpty()) {
            sb.appendLine("— Lingkungan perangkat (BUKAN bukti cheat) —")
            env.forEach {
                sb.appendLine("• [${it.severity}] ${it.title}")
                if (it.detail.isNotBlank()) sb.appendLine("    ${it.detail.replace("\n", "\n    ")}")
            }
            sb.appendLine()
        }

        if (info.isNotEmpty()) {
            sb.appendLine("— Catatan verifikasi (bukan cheat) —")
            info.forEach {
                sb.appendLine("• ${it.title}")
                if (it.detail.isNotBlank()) sb.appendLine("    ${it.detail.replace("\n", "\n    ")}")
            }
        }

        binding.tvDetail.text = sb.toString()
    }

    /**
     * Membuat baseline dari Free Fire yang terpasang dari Play Store.
     * Ditolak otomatis bila FF tidak berasal dari Play Store.
     */
    private fun makeBaseline() {
        binding.btnScan.isEnabled = false
        binding.btnBaseline.isEnabled = false
        binding.tvDetail.text = "Membuat baseline dari Free Fire Play Store…\nBisa memakan 30-90 detik."

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        lifecycleScope.launch {
            val files = ArrayList<File>()
            val errors = ArrayList<String>()
            withContext(Dispatchers.IO) {
                val installed = CheatSignatures.FF_PACKAGES.filter { isInstalled(it) }
                if (installed.isEmpty()) errors += "Free Fire resmi tidak terpasang."
                for (pkg in installed) {
                    try {
                        files += IntegrityScanner.exportBaseline(this@MainActivity, pkg)
                    } catch (e: Exception) {
                        errors += "$pkg: ${e.message}"
                    }
                }
            }

            val sb = StringBuilder()
            if (files.isNotEmpty()) {
                sb.appendLine("Baseline dibuat:")
                files.forEach { sb.appendLine("• ${it.name} (${it.length() / 1024} KB)") }
                sb.appendLine()
                sb.appendLine("Kirim file ini ke repo: taruh di app/src/main/assets/baselines/ lalu build ulang,")
                sb.appendLine("supaya semua HP bisa membandingkan FF mereka dengan FF Play Store versi tersebut.")
            }
            errors.forEach { sb.appendLine("✗ $it") }
            binding.tvDetail.text = sb.toString()

            if (files.isNotEmpty()) shareFiles(files)
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            binding.btnScan.isEnabled = true
            binding.btnBaseline.isEnabled = true
        }
    }

    private fun shareFiles(files: List<File>) {
        try {
            val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
            }
            intent.type = "application/json"
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Bagikan baseline"))
        } catch (e: Exception) {
            binding.tvDetail.append("\nGagal membuka menu bagikan: ${e.message}")
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }
}
