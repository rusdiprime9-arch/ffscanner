package com.azx.scanner

import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Kind
import com.azx.scanner.CheatSignatures.Severity

/**
 * Mengelompokkan temuan menjadi KATEGORI jenis cheat untuk ditampilkan di kotak vonis.
 * Murni tampilan: TIDAK mempengaruhi vonis (itu tetap hanya di VerdictPolicy).
 * Hanya temuan EVIDENCE bersaverity HIGH (bukti terverifikasi dari isi) yang dihitung, sama seperti dasar vonis.
 */
object CheatCategory {

    enum class Category(val label: String) {
        PROXY_VPN("Cheat via Proxy/VPN"),
        VIRTUAL("Virtual space / clone"),
        AUTOMATION("Macro / auto-click"),
        ROOT_DAEMON("Daemon / driver root cheat"),
        MENU("Menu cheat (ESP/aimbot/overlay)"),
        INJECTION("Injeksi / hook ke proses game"),
        MEMORY("Akses / ubah memori game"),
        APK_MOD("Modifikasi file atau APK game"),
        DEBUG_ADB("Jalur ADB / Shizuku / debugging"),
        APP("Aplikasi cheat terpasang"),
        OTHER("Indikasi lain")
    }

    class Entry(val category: Category, val severity: Severity, val count: Int)

    private val rules: List<Pair<Category, List<String>>> = listOf(
        Category.PROXY_VPN to listOf("proxy", "vpn", "ip tunnel"),
        Category.VIRTUAL to listOf("container", "virtual space", "multi-user"),
        Category.AUTOMATION to listOf("accessibility", "auto-click", "macro"),
        Category.ROOT_DAEMON to listOf("daemon", "proses root", "modul kernel", "driver"),
        Category.MENU to listOf("menu cheat", "kelas bernama mirip cheat"),
        Category.INJECTION to listOf(
            "hook", "frida", "memfd", "lib dihapus", "lib ekstrak", "lib inti", "injeksi", "lsposed",
            "modul root", "modul ", "library", "dimuat di proses game", "rwx", "anon executable", "port "
        ),
        Category.MEMORY to listOf("memori", "di-trace", "gameguardian"),
        Category.APK_MOD to listOf(
            "dimodifikasi", "di-rename", "tambahan:", "hilang:", "sertifikat berbeda", "debuggable", "test-only",
            "kunci debug", "dex tersembunyi", "menyamar", ".so palsu", "entry ganda", "nama entry",
            "nama paket free fire tidak resmi", "banyak penanda tangan", "perbedaan kritis", "luckypatcher"
        ),
        Category.DEBUG_ADB to listOf("adb", "shizuku", "usb debugging"),
        Category.APP to listOf("package", "app ", "aplikasi")
    )

    fun classify(f: Finding): Category {
        val t = f.title.lowercase()
        for ((cat, keys) in rules) if (keys.any { t.contains(it) }) return cat
        return Category.OTHER
    }

    /** Kategori dari bukti terverifikasi (HIGH), dengan jumlah temuan per kategori. */
    fun summarize(findings: List<Finding>): List<Entry> {
        val relevant = findings.filter { it.kind == Kind.EVIDENCE && it.severity == Severity.HIGH }
        return relevant.groupBy { classify(it) }
            .map { (cat, list) -> Entry(cat, list.minOf { it.severity }, list.size) }
            .sortedWith(compareBy<Entry> { it.severity.ordinal }.thenBy { it.category.ordinal })
    }

    /** Ringkas satu baris, mis. "Cheat via Proxy/VPN • Injeksi / hook ke proses game". */
    fun oneLine(entries: List<Entry>): String = entries.joinToString(" • ") { it.category.label }
}
