package com.azx.scanner

import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Kind
import com.azx.scanner.CheatSignatures.Severity

/**
 * Satu-satunya tempat vonis ditentukan (murni Kotlin, bisa diuji di JVM tanpa Android).
 *
 * Vonis hanya DUA: CHEAT atau CLEAN (bersih).
 *  R1. Temuan kind=ENV (root, ROM/kernel custom, bootloader, framework injeksi umum) TIDAK PERNAH mempengaruhi vonis,
 *      seberapa pun severity-nya.
 *  R2. CHEAT hanya bila ada temuan EVIDENCE bersaverity HIGH. HIGH hanya boleh dibuat dari bukti isi/sumber
 *      (lihat ContentValidator), TIDAK PERNAH dari nama file/paket/folder.
 *  R3. MEDIUM/LOW/INFO tidak mempengaruhi vonis, sebanyak apa pun. MEDIUM tetap ditampilkan sebagai
 *      "indikasi belum terbukti" (lihat [unprovenCount]) supaya tidak ada yang tersembunyi, tanpa menuduh.
 */
object VerdictPolicy {

    enum class Verdict { CHEAT, CLEAN }

    fun decide(findings: List<Finding>): Verdict =
        if (findings.any { it.kind == Kind.EVIDENCE && it.severity == Severity.HIGH }) Verdict.CHEAT else Verdict.CLEAN

    /** Jumlah indikasi MEDIUM (bukan lingkungan) yang belum terbukti dari isi. Tidak mempengaruhi vonis. */
    fun unprovenCount(findings: List<Finding>): Int =
        findings.count { it.kind == Kind.EVIDENCE && it.severity == Severity.MEDIUM }
}
