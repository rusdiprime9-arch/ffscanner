package com.azx.scanner

import java.io.File
import java.util.zip.ZipFile

/**
 * Validasi berdasarkan ISI, bukan nama. Nama paket/library hanya dipakai untuk memilih apa yang
 * diperiksa; vonis berat (HIGH) hanya boleh dari isi yang benar-benar menunjukkan alat cheat.
 */
object ContentValidator {

    /** Penanda framework hook inline/native yang hampir tidak ada di library sah. */
    val HOOK_MARKERS = listOf(
        "MSHookFunction", "MSHookMessageEx", "DobbyHook", "xhook_register", "shadowhook_hook",
        "And64InlineHook", "SandHook", "HookZz", "frida-gadget", "gum_interceptor_attach"
    )

    /** Regex untuk grep -E lewat shell (root). */
    val HOOK_REGEX = HOOK_MARKERS.joinToString("|")
    const val FF_REGEX = "com\\.dts\\.freefire|com\\.garena\\.game\\.kg"

    /**
     * Nama kelas yang hampir hanya dipakai menu cheat. Dicari sebagai NAMA KELAS di dalam dex (descriptor
     * `Lpaket/NamaKelas;`), bukan sebagai potongan teks bebas. "AntiBan" sengaja TIDAK ada di sini:
     * itu istilah SDK iklan (Bigo Ads, dll.) dan banyak library sah, bukan penanda cheat Free Fire.
     */
    val CHEAT_CLASS_TOKENS = listOf(
        "ESPView", "ESPMenu", "ESPDraw", "Aimbot", "AimBot", "WallHack", "Wallhack", "NoRecoil", "SpeedHack",
        "HackerFloat", "AutoHeadshot", "SilentAim", "MagicBullet",
        // jenis cheat yang paling sering dilaporkan di Free Fire: auto aim, teleport, antena, terbang, hantu
        "AutoAim", "AntennaHack", "TeleportHack", "FlyHack", "GhostHack", "ForceHeadshot"
    )

    /** Paket SDK/library pihak ketiga yang umum: kelas di dalamnya tidak dihitung sebagai menu cheat. */
    val SDK_PACKAGE_PREFIXES = listOf(
        "Lcom/google/", "Lcom/facebook/", "Lcom/unity3d/", "Lcom/applovin/", "Lcom/ironsource/", "Lcom/vungle/",
        "Lcom/bytedance/", "Lcom/pangle/", "Lcom/mbridge/", "Lcom/mintegral/", "Lcom/chartboost/", "Lcom/inmobi/",
        "Lcom/fyber/", "Lcom/adcolony/", "Lcom/startapp/", "Lcom/yandex/", "Lcom/smaato/", "Lcom/amazon/",
        "Lio/bidmachine/", "Lsg/bigo/", "Lcom/bigo/", "Lcom/oset", "Lcom/squareup/", "Lokhttp3/", "Lokio/",
        "Lkotlin/", "Lkotlinx/", "Landroidx/", "Landroid/", "Lorg/", "Lretrofit2/", "Lcom/bumptech/", "Lcom/airbnb/"
    )

    /**
     * Penanda loader "daemon" root: app mengunduh lalu menjalankan biner native (daemon/driver) sendiri.
     * Dicari di dex (isi). Satu penanda saja tidak cukup; butuh minimal 2 yang berbeda.
     */
    val DAEMON_LOADER_MARKERS = listOf(
        "nativeLaunchDaemon", "downloadDaemonWithProgress", "nativeIsDaemonRunning",
        "nativeGetDaemonFilename", "checkDaemonAndProceed"
    )

    class MenuEvidence(val tokens: List<String>, val mentionsFf: Boolean, val daemonLoader: Boolean = false)

    // Byte pencarian dihitung SEKALI (sebelumnya dibuat ulang untuk setiap entry di setiap APK).
    internal val KNOWN_N by lazy { CheatSignatures.KNOWN_CHEAT_STRINGS.map { it.toByteArray(Charsets.UTF_8) to it.toByteArray(Charsets.UTF_16LE) } }
    internal val PACKER_N by lazy { CheatSignatures.PACKER_MARKERS.map { it to it.toByteArray() } }
    internal val TUNNEL_N by lazy { CheatSignatures.TUNNEL_NATIVE_MARKERS.map { it to it.toByteArray() } }
    internal val HOOK_N by lazy { HOOK_MARKERS.map { it to it.toByteArray() } }
    internal val DAEMON_N by lazy { DAEMON_LOADER_MARKERS.map { it to it.toByteArray() } }
    internal val FFPKG_N by lazy { CheatSignatures.FF_PACKAGES.map { it.toByteArray() } }

    /**
     * Cari BANYAK penanda sekaligus dalam SATU lintasan byte (tabel byte-pertama), bukan satu lintasan per penanda.
     * Hasilnya sama persis dengan memanggil [indexOf] untuk tiap penanda; hanya jauh lebih cepat pada dex/.so besar.
     */
    class MultiNeedle(private val needles: List<ByteArray>) {
        private val byFirst: Array<IntArray?> = arrayOfNulls<IntArray>(256).also { arr ->
            val tmp = HashMap<Int, MutableList<Int>>()
            needles.forEachIndexed { i, n ->
                if (n.isNotEmpty()) tmp.getOrPut(n[0].toInt() and 0xFF) { mutableListOf() }.add(i)
            }
            for ((k, v) in tmp) arr[k] = v.toIntArray()
        }

        fun scan(hay: ByteArray): BooleanArray {
            val found = BooleanArray(needles.size)
            var remaining = needles.count { it.isNotEmpty() }
            val n = hay.size
            var i = 0
            while (i < n && remaining > 0) {
                val cand = byFirst[hay[i].toInt() and 0xFF]
                if (cand != null) {
                    for (idx in cand) {
                        if (found[idx]) continue
                        val nd = needles[idx]
                        if (i + nd.size > n) continue
                        var j = 1
                        while (j < nd.size && hay[i + j] == nd[j]) j++
                        if (j == nd.size) { found[idx] = true; remaining-- }
                    }
                }
                i++
            }
            return found
        }
    }

    /** Semua penanda bukti APK digabung jadi satu pencari; indeks per kelompok disimpan untuk menafsirkan hasil. */
    private class EvidenceIndex {
        val all = ArrayList<ByteArray>()
        val knownIdx = ArrayList<Int>()
        val packerIdx = ArrayList<Pair<String, Int>>()
        val hookIdx = ArrayList<Pair<String, Int>>()
        val tunnelIdx = ArrayList<Pair<String, Int>>()
        val ffIdx = ArrayList<Int>()

        init {
            for ((u8, u16) in KNOWN_N) {
                knownIdx.add(all.size); all.add(u8)
                knownIdx.add(all.size); all.add(u16)
            }
            for ((m, b) in PACKER_N) { packerIdx.add(Pair(m, all.size)); all.add(b) }
            for ((h, b) in HOOK_N) { hookIdx.add(Pair(h, all.size)); all.add(b) }
            for ((m, b) in TUNNEL_N) { tunnelIdx.add(Pair(m, all.size)); all.add(b) }
            for (b in FFPKG_N) { ffIdx.add(all.size); all.add(b) }
        }

        val search = MultiNeedle(all)
    }

    private val EV by lazy { EvidenceIndex() }

    private fun isNameByte(b: Byte): Boolean {
        val c = b.toInt() and 0xFF
        return c in 'a'.code..'z'.code || c in 'A'.code..'Z'.code || c in '0'.code..'9'.code ||
            c == '_'.code || c == '$'.code || c == '/'.code || c == '-'.code
    }

    /**
     * Cari token sebagai nama kelas dari paket aplikasi itu sendiri (bukan SDK). Mengembalikan true bila
     * ada descriptor `L.../Token...;` dengan token berada di AWAL nama sederhana kelas.
     */
    private fun hasOwnClassToken(b: ByteArray, token: String): Boolean {
        val t = token.toByteArray()
        var from = 0
        while (true) {
            val i = indexOf(b, t, from)
            if (i < 0) return false
            from = i + 1
            // token harus di awal nama sederhana kelas: didahului '/' atau '$'
            if (i == 0) continue
            val before = b[i - 1].toInt().toChar()
            if (before != '/' && before != '$') continue
            // maju sampai ';' (descriptor kelas harus berakhir ';')
            var en = i + t.size
            while (en < b.size && isNameByte(b[en])) en++
            if (en >= b.size || b[en].toInt().toChar() != ';') continue
            // mundur ke awal nama; awal descriptor sebenarnya adalah 'L' yang byte panjang (uleb128) tepat di depannya
            // sama dengan panjang string (menghindari salah potong bila byte panjang kebetulan huruf)
            var lo = i - 1
            while (lo > 0 && isNameByte(b[lo - 1])) lo--
            var descStart = -1
            for (p in lo until i) {
                if (b[p].toInt().toChar() != 'L') continue
                val len = en - p + 1
                val ok = if (len < 128) p >= 1 && (b[p - 1].toInt() and 0xFF) == len
                else p >= 2 && (b[p - 2].toInt() and 0xFF) == ((len and 0x7F) or 0x80) && (b[p - 1].toInt() and 0xFF) == (len shr 7)
                if (ok) { descStart = p; break }
            }
            if (descStart < 0) continue
            val desc = String(b, descStart, en - descStart + 1, Charsets.ISO_8859_1)
            if (SDK_PACKAGE_PREFIXES.any { desc.startsWith(it) }) continue
            return true
        }
    }

    /** Bedah dex: kelas menu cheat (ESP/aimbot/dll) dan apakah isinya benar-benar menyebut paket Free Fire. */
    fun menuEvidence(path: String?): MenuEvidence {
        if (path == null) return MenuEvidence(emptyList(), false)
        val tokens = linkedSetOf<String>()
        val loader = linkedSetOf<String>()
        var ff = false
        try {
            ZipFile(path).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val n = e.name
                    if (e.isDirectory || !(n.startsWith("classes") && n.endsWith(".dex")) || e.size !in 1..24_000_000) continue
                    val b = z.getInputStream(e).use { it.readBytes() }
                    for (t in CHEAT_CLASS_TOKENS) if (t !in tokens && hasOwnClassToken(b, t)) tokens += t
                    for ((m, mb) in DAEMON_N) if (m !in loader && indexOf(b, mb) >= 0) loader += m
                    // Hanya nama paket resmi Free Fire; kata "freefire" bebas terlalu umum (iklan, teks, dll.)
                    if (!ff) for (pb in FFPKG_N) if (indexOf(b, pb) >= 0) { ff = true; break }
                }
            }
        } catch (e: Exception) {
        }
        return MenuEvidence(tokens.toList(), ff, loader.size >= 2)
    }

    class ApkEvidence(
        val known: Boolean,
        val packer: List<String>,
        val tunnel: List<String>,
        val hook: List<String>,
        val targetsFf: Boolean
    ) {
        /** Bukti kuat = isi APK sendiri menunjukkan alat cheat. */
        val strong: Boolean get() = known || packer.isNotEmpty() || tunnel.isNotEmpty() || hook.isNotEmpty()
    }

    /** Cari penanda hook di isi file (maks [maxBytes] pertama). Mengembalikan penanda yang ditemukan. */
    fun fileHookMarkers(f: File, maxBytes: Long = 12L * 1024 * 1024): List<String> {
        val found = linkedSetOf<String>()
        try {
            if (!f.isFile || !f.canRead()) return emptyList()
            val pats = HOOK_MARKERS.map { it to it.toByteArray(Charsets.US_ASCII) }
            val keep = pats.maxOf { it.second.size } - 1
            val buf = ByteArray(256 * 1024)
            var carry = ByteArray(0)
            var total = 0L
            f.inputStream().use { input ->
                while (total < maxBytes) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    total += n
                    val window = if (carry.isEmpty()) buf.copyOf(n) else carry + buf.copyOf(n)
                    for ((name, p) in pats) if (indexOf(window, p) >= 0) found += name
                    carry = if (window.size > keep) window.copyOfRange(window.size - keep, window.size) else window
                }
            }
        } catch (e: Exception) {
        }
        return found.toList()
    }

    /** Bedah isi APK: string sampel cheat, packer, tunnel, penanda hook, dan apakah menyebut paket Free Fire. */
    fun apkEvidence(path: String?): ApkEvidence {
        if (path == null) return ApkEvidence(false, emptyList(), emptyList(), emptyList(), false)
        var known = false
        var targets = false
        val packer = linkedSetOf<String>()
        val tunnel = linkedSetOf<String>()
        val hook = linkedSetOf<String>()
        try {
            ZipFile(path).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.isDirectory) continue
                    val n = e.name
                    val isDex = n.startsWith("classes") && n.endsWith(".dex") && e.size in 1..12_000_000
                    val isSo = n.startsWith("lib/") && n.endsWith(".so") && e.size in 1..8_000_000
                    val isManifest = n == "AndroidManifest.xml" && e.size in 1..2_000_000
                    if (!isDex && !isSo && !isManifest) continue
                    val b = z.getInputStream(e).use { it.readBytes() }
                    val hit = EV.search.scan(b)
                    if (!known) known = EV.knownIdx.any { hit[it] }
                    if (isDex || isSo) {
                        for ((m, i) in EV.packerIdx) if (hit[i]) packer += m
                        for ((h, i) in EV.hookIdx) if (hit[i]) hook += h
                    }
                    if (isSo) for ((m, i) in EV.tunnelIdx) if (hit[i]) tunnel += m
                    if (isDex && !targets) targets = EV.ffIdx.any { hit[it] }
                }
            }
        } catch (e: Exception) {
        }
        return ApkEvidence(known, packer.toList(), tunnel.toList(), hook.toList(), targets)
    }

    fun indexOf(hay: ByteArray, needle: ByteArray, start: Int = 0): Int {
        if (needle.isEmpty() || hay.size < needle.size) return -1
        val first = needle[0]
        val last = hay.size - needle.size
        var i = start
        while (i <= last) {
            if (hay[i] == first) {
                var j = 1
                while (j < needle.size && hay[i + j] == needle[j]) j++
                if (j == needle.size) return i
            }
            i++
        }
        return -1
    }
}
