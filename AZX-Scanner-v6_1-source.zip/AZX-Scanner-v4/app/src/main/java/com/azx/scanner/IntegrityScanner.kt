package com.azx.scanner

/*
 * IntegrityScanner - verifikasi integritas Free Fire.
 *
 *  1. Sumber install (Play Store / toko lain / sideload)          -> non-root
 *  2. Sertifikat penanda tangan (+ kunci debug)                   -> non-root
 *  3. Isi APK + split di-hash berdasarkan ISI (bukan nama file)   -> non-root
 *     - ELF menyamar, .so palsu, DEX tersembunyi, entry ganda
 *     - perbandingan dengan baseline Play Store (hash, rename, hilang, tambahan)
 *  4. Lib hasil ekstrak vs isi APK                                -> non-root bila terbaca
 *  5. Memori game (/proc/PID/maps)                                -> root
 *  6. ELF/DEX menyamar di folder data game                        -> root / Android <= 10
 */

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.zip.ZipFile

object IntegrityScanner {

    enum class Level { INFO, LOW, WARN, CRITICAL }
    data class Item(val level: Level, val title: String, val detail: String)

    /** Opsional: URL folder baseline (raw GitHub), contoh
     *  "https://raw.githubusercontent.com/rusdiprime9-arch/ffscanner/main/baselines/"
     *  Kosongkan untuk menonaktifkan unduhan. */
    private const val REMOTE_BASELINE_URL = ""

    private const val PLAY_STORE = "com.android.vending"
    private const val MAX_LINES = 15

    private val IL2CPP_MARKERS = listOf("il2cpp_init", "il2cpp_runtime_invoke")
    private val DEX_NAME = Regex("classes\\d*\\.dex")

    // ---------------------------------------------------------------- API

    fun scan(ctx: Context, root: Boolean): List<Item> {
        val items = ArrayList<Item>()
        val candidates = findCandidates(ctx)
        if (candidates.isEmpty()) {
            items += Item(Level.INFO, "Free Fire tidak ditemukan", "Tidak ada aplikasi Free Fire terpasang, verifikasi integritas dilewati.")
            return items
        }
        for (pi in candidates) {
            try {
                items += scanPackage(ctx, pi, root)
            } catch (e: Exception) {
                items += Item(Level.INFO, "[${pi.packageName}] Verifikasi gagal", e.message ?: e.javaClass.simpleName)
            }
        }
        return items
    }

    /**
     * Buat baseline dari FF hasil install bersih Play Store (versi sama).
     * Ditolak bila FF tidak terpasang dari Play Store, supaya FF mod tidak bisa jadi acuan.
     */
    fun exportBaseline(ctx: Context, pkg: String): File {
        val pm = ctx.packageManager
        val pi = pm.getPackageInfo(pkg, 0)
        val ai = pi.applicationInfo ?: throw IllegalStateException("applicationInfo kosong")
        val installer = installerOf(pm, pkg)
        if (installer != PLAY_STORE)
            throw IllegalStateException("$pkg tidak terpasang dari Play Store (installer: ${installer ?: "tidak ada"}). Baseline hanya boleh dari instalasi Play Store.")
        if (ai.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0)
            throw IllegalStateException("$pkg berstatus debuggable, bukan build resmi.")
        val agg = aggregate(apkPaths(ai).flatMap { scanApk(it, true) })
        val files = JSONObject()
        agg.values.sortedBy { it.name }.forEach { files.put(it.name, it.shaKey) }
        val certs = JSONArray()
        certHashes(pm, pkg).forEach { certs.put(it) }
        val json = JSONObject()
            .put("package", pkg)
            .put("versionName", pi.versionName ?: "")
            .put("versionCode", versionCode(pi))
            .put("abi", Build.SUPPORTED_ABIS.firstOrNull() ?: "")
            .put("installer", installer)
            .put("certSha256", certs)
            .put("files", files)
        val dir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val out = File(dir, "baseline_${pkg}_${versionCode(pi)}.json")
        out.writeText(json.toString(1))
        return out
    }

    // ---------------------------------------------------------------- per paket

    private fun scanPackage(ctx: Context, pi: PackageInfo, root: Boolean): List<Item> {
        val items = ArrayList<Item>()
        val pm = ctx.packageManager
        val pkg = pi.packageName
        val ai = pi.applicationInfo ?: return listOf(Item(Level.INFO, "[$pkg]", "applicationInfo tidak tersedia"))
        val tag = "[$pkg]"

        // 1. installer
        val installer = installerOf(pm, pkg)
        when {
            installer == PLAY_STORE -> items += Item(
                Level.INFO, "$tag Installer: Play Store",
                "Field ini bisa dipalsukan oleh root, karena itu tetap diverifikasi lewat sertifikat dan hash isi APK."
            )
            installer != null && installer in CheatSignatures.ALT_STORES -> items += Item(
                Level.LOW, "$tag Bukan dari Play Store", "Dipasang dari toko lain: $installer. Sumber saja bukan bukti cheat; dinilai dari sertifikat dan hash isi APK."
            )
            installer == null -> items += Item(
                Level.LOW, "$tag Bukan dari Play Store",
                "Tidak ada installer tercatat (sideload / ADB). Sumber saja bukan bukti cheat; dinilai dari sertifikat dan hash isi APK (butuh baseline)."
            )
            else -> items += Item(
                Level.LOW, "$tag Bukan dari Play Store",
                "Dipasang oleh: $installer. Sumber saja bukan bukti cheat; dinilai dari sertifikat dan hash isi APK (butuh baseline)."
            )
        }
        if (pkg !in CheatSignatures.FF_PACKAGES)
            items += Item(Level.WARN, "$tag Nama paket Free Fire tidak resmi", "Kemungkinan clone/mod dengan paket berbeda.")
        if (ai.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0)
            items += Item(Level.CRITICAL, "$tag APK debuggable", "Build resmi Play Store tidak debuggable.")
        if (ai.flags and ApplicationInfo.FLAG_TEST_ONLY != 0)
            items += Item(Level.CRITICAL, "$tag APK test-only", "Build resmi tidak memakai flag test-only.")

        // 2. sertifikat
        val certs = certHashes(pm, pkg)
        items += Item(Level.INFO, "$tag Sertifikat SHA-256", certs.joinToString("\n").ifEmpty { "tidak terbaca" })
        certSubjects(pm, pkg).forEach { s ->
            if (s.contains("Android Debug", true))
                items += Item(Level.CRITICAL, "$tag Ditandatangani kunci debug", s)
        }
        if (certs.size > 1) items += Item(Level.WARN, "$tag Banyak penanda tangan", "${certs.size} sertifikat")

        // 3. isi APK
        val vc = versionCode(pi)
        val baseline = loadBaseline(ctx, pkg, vc)
        val full = baseline != null
        val entries = ArrayList<EntryInfo>()
        for (p in apkPaths(ai)) {
            try {
                entries += scanApk(p, full)
            } catch (e: Exception) {
                items += Item(Level.INFO, "$tag Gagal membaca ${File(p).name}", e.message ?: e.javaClass.simpleName)
            }
        }
        if (entries.isEmpty()) return items
        items += structuralChecks(tag, entries)
        val agg = aggregate(entries)

        if (baseline == null) {
            items += Item(
                Level.INFO, "$tag Baseline Play Store belum ada",
                "Versi $vc belum punya baseline, perbandingan hash tidak dijalankan. " +
                    "Buat dengan tombol BUAT BASELINE pada HP berisi FF Play Store yang bersih."
            )
        } else {
            val bCerts = baseline.optJSONArray("certSha256")
            if (bCerts != null && bCerts.length() > 0) {
                val expected = (0 until bCerts.length()).map { bCerts.getString(it) }.toSet()
                if (certs.none { it in expected })
                    items += Item(Level.CRITICAL, "$tag Sertifikat BERBEDA dari Play Store", "Ditemukan: ${certs.joinToString()}")
                else items += Item(Level.INFO, "$tag Sertifikat cocok dengan baseline", "")
            }
            items += compareBaseline(tag, baseline, agg)
        }

        // 4. lib hasil ekstrak
        items += verifyExtractedLibs(tag, ai.nativeLibraryDir, agg, root)

        // 5. memori
        if (root) items += scanLiveMaps(tag, pkg)
        else items += Item(Level.INFO, "$tag Memori game tidak dipindai", "Tidak dapat diverifikasi tanpa root (Android memblokir /proc milik aplikasi lain).")

        // 6. folder data
        items += scanDataDirs(tag, pkg, root)
        return items
    }

    // ---------------------------------------------------------------- kandidat

    @SuppressLint("QueryPermissionsNeeded")
    @Suppress("DEPRECATION")
    private fun findCandidates(ctx: Context): List<PackageInfo> {
        val pm = ctx.packageManager
        return pm.getInstalledPackages(0).filter { pi ->
            val name = pi.packageName.lowercase()
            if (name == ctx.packageName.lowercase()) return@filter false
            val label = pi.applicationInfo?.let { pm.getApplicationLabel(it).toString().lowercase() } ?: ""
            name in CheatSignatures.FF_PACKAGES || name.contains("freefire") || name.startsWith("com.dts.") ||
                label.contains("free fire") || label.contains("freefire")
        }
    }

    // ---------------------------------------------------------------- installer & sertifikat

    @Suppress("DEPRECATION")
    private fun installerOf(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else pm.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun signatures(pm: PackageManager, pkg: String): Array<Signature> = try {
        if (Build.VERSION.SDK_INT >= 28) {
            val pi = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
            pi.signingInfo?.apkContentsSigners ?: emptyArray()
        } else {
            pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES).signatures ?: emptyArray()
        }
    } catch (e: Exception) {
        emptyArray()
    }

    private fun certHashes(pm: PackageManager, pkg: String): List<String> =
        signatures(pm, pkg).map { hex(MessageDigest.getInstance("SHA-256").digest(it.toByteArray())) }

    private fun certSubjects(pm: PackageManager, pkg: String): List<String> =
        signatures(pm, pkg).mapNotNull {
            try {
                val cf = CertificateFactory.getInstance("X.509")
                (cf.generateCertificate(it.toByteArray().inputStream()) as X509Certificate).subjectX500Principal.name
            } catch (e: Exception) {
                null
            }
        }

    @Suppress("DEPRECATION")
    private fun versionCode(pi: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()

    // ---------------------------------------------------------------- isi APK

    private class EntryInfo(
        val name: String, val sha: String, val size: Long,
        val isElf: Boolean, val isDex: Boolean, val il2cpp: Boolean, val apk: String
    )

    private class Agg(val name: String, val shaKey: String, val critical: Boolean)

    private val INSPECT_BUF = ThreadLocal.withInitial { ByteArray(256 * 1024) }
    private val IL2CPP_PATS by lazy { IL2CPP_MARKERS.map { it.toByteArray(Charsets.US_ASCII) } }

    private class Inspect(val sha: String, val size: Long, val isElf: Boolean, val isDex: Boolean, val il2cpp: Boolean)

    private fun apkPaths(ai: ApplicationInfo): List<String> =
        listOfNotNull(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())

    private fun isCritical(n: String): Boolean =
        n.startsWith("lib/") || n.endsWith("global-metadata.dat") ||
            n.startsWith("assets/bin/Data/Managed/") || DEX_NAME.matches(n)

    /** full=true: hash semua entry. full=false: hash hanya entry kritis, sisanya cukup diintip 8 byte. */
    private fun scanApk(path: String, full: Boolean): List<EntryInfo> {
        val apkName = File(path).name
        return ZipFile(path).use { zf ->
            val list = zf.entries().toList().filter { !it.isDirectory }
            val workers = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
            val pool = Executors.newFixedThreadPool(workers)
            try {
                // Entry di-hash paralel (ZipFile aman untuk banyak stream bersamaan); urutan hasil tetap.
                val futures = list.map { e ->
                    pool.submit(Callable<EntryInfo> {
                        val readAll = full || isCritical(e.name) || e.name.endsWith(".so")
                        val r = zf.getInputStream(e).use { inspect(it, readAll) }
                        EntryInfo(e.name, r.sha, r.size, r.isElf, r.isDex, r.il2cpp, apkName)
                    })
                }
                futures.map { it.get() }
            } finally {
                pool.shutdown()
            }
        }
    }

    private fun inspect(input: InputStream, readAll: Boolean): Inspect {
        val md = MessageDigest.getInstance("SHA-256")
        val pats = IL2CPP_PATS
        val maxLen = pats.maxOf { it.size }
        val buf = INSPECT_BUF.get()!!
        var head = ByteArray(0)
        var total = 0L
        var elf = false
        var dex = false
        var decided = false
        var found = false
        var carry = ByteArray(0)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            if (n == 0) continue
            total += n
            if (head.size < 8) head += buf.copyOf(minOf(n, 8 - head.size))
            if (!decided && head.size >= 4) {
                elf = head[0] == 0x7F.toByte() && head[1] == 0x45.toByte() && head[2] == 0x4C.toByte() && head[3] == 0x46.toByte()
                dex = head[0] == 0x64.toByte() && head[1] == 0x65.toByte() && head[2] == 0x78.toByte() && head[3] == 0x0A.toByte()
                decided = true
            }
            if (!readAll) {
                if (decided) break else continue
            }
            md.update(buf, 0, n)
            if (elf && !found) {
                val window = carry + buf.copyOf(n)
                if (pats.any { indexOf(window, it) >= 0 }) found = true
                carry = if (window.size >= maxLen - 1) window.copyOfRange(window.size - (maxLen - 1), window.size) else window
            }
        }
        return Inspect(if (readAll) hex(md.digest()) else "", total, elf, dex, found)
    }

    private fun indexOf(h: ByteArray, p: ByteArray): Int {
        if (p.isEmpty() || h.size < p.size) return -1
        outer@ for (i in 0..h.size - p.size) {
            if (h[i] != p[0]) continue
            for (j in 1 until p.size) if (h[i + j] != p[j]) continue@outer
            return i
        }
        return -1
    }

    private fun aggregate(list: List<EntryInfo>): Map<String, Agg> =
        list.groupBy { it.name }.mapValues { (n, v) ->
            Agg(n, v.map { it.sha }.sorted().joinToString(","), isCritical(n))
        }

    // ---------------------------------------------------------------- cek struktural

    private fun structuralChecks(tag: String, entries: List<EntryInfo>): List<Item> {
        val items = ArrayList<Item>()

        entries.groupBy { it.apk to it.name }.filter { it.value.size > 1 }.forEach { (k, _) ->
            items += Item(Level.CRITICAL, "$tag Entry ganda di ${k.first}", k.second)
        }
        entries.filter { it.name.contains("..") || it.name.startsWith("/") }.forEach {
            items += Item(Level.CRITICAL, "$tag Nama entry mencurigakan", it.name)
        }
        entries.filter { it.isElf && !it.name.endsWith(".so") }.forEach {
            items += Item(Level.CRITICAL, "$tag ELF menyamar", "${it.name} (${it.apk}) berisi binary ELF tetapi bukan .so")
        }
        entries.filter { it.name.endsWith(".so") && !it.isElf }.forEach {
            items += Item(Level.CRITICAL, "$tag .so palsu", "${it.name} (${it.apk}) bukan ELF valid")
        }
        entries.filter { it.isDex && !DEX_NAME.matches(it.name) }.forEach {
            items += Item(Level.CRITICAL, "$tag DEX tersembunyi", "${it.name} (${it.apk})")
        }

        // libunity.so ikut memuat nama fungsi il2cpp_*, jadi hanya libil2cpp.so dan libunity.so yang dianggap wajar
        val named = entries.filter { it.name.endsWith("/libil2cpp.so") }
        val unusual = entries.filter {
            it.il2cpp && it.isElf && it.name.endsWith(".so") &&
                !it.name.endsWith("/libil2cpp.so") && !it.name.endsWith("/libunity.so")
        }
        if (named.isEmpty() && unusual.isEmpty()) {
            items += Item(
                Level.WARN, "$tag libil2cpp.so tidak ditemukan",
                "Tidak ada libil2cpp.so di APK/split. Lib mungkin dihapus atau dipindah."
            )
        }
        named.forEach {
            items += Item(Level.INFO, "$tag libil2cpp.so", "${it.name} (${it.apk}) SHA-256 ${it.sha} ukuran ${it.size}")
        }
        unusual.forEach {
            items += Item(Level.WARN, "$tag Lib bermuatan il2cpp dengan nama lain", "${it.name} (${it.apk}) SHA-256 ${it.sha}")
        }
        entries.filter { it.name.endsWith("/libunity.so") }.forEach {
            items += Item(Level.INFO, "$tag libunity.so", "${it.name} (${it.apk}) SHA-256 ${it.sha}")
        }
        return items
    }

    // ---------------------------------------------------------------- baseline

    private fun compareBaseline(tag: String, base: JSONObject, actual: Map<String, Agg>): List<Item> {
        val items = ArrayList<Item>()
        val files = base.getJSONObject("files")
        val baseMap = HashMap<String, String>()
        files.keys().forEach { baseMap[it] = files.getString(it) }

        // baseline dari ABI lain -> lib/ tidak dibandingkan
        val abiNow = Build.SUPPORTED_ABIS.firstOrNull() ?: ""
        val abiBase = base.optString("abi", "")
        var skipLibs = false
        if (abiBase.isNotEmpty() && abiBase != abiNow) {
            skipLibs = true
            items += Item(Level.INFO, "$tag Baseline dari ABI $abiBase (HP ini $abiNow)", "Perbandingan lib/ dilewati. Buat baseline di HP dengan ABI sama untuk cakupan penuh.")
        }
        fun skip(n: String) = skipLibs && n.startsWith("lib/")

        val modified = actual.values.filter { !skip(it.name) && baseMap[it.name] != null && baseMap[it.name] != it.shaKey }
        var missing = baseMap.keys.filter { it !in actual && !skip(it) }
        var added = actual.values.filter { it.name !in baseMap && !skip(it.name) }

        val renamed = ArrayList<Pair<String, String>>()
        for (a in added.toList()) {
            val b = missing.firstOrNull { baseMap[it] == a.shaKey }
            if (b != null) {
                renamed += b to a.name
                missing = missing - b
                added = added - a
            }
        }

        val critical = ArrayList<Item>()
        modified.filter { it.critical }.forEach { critical += Item(Level.CRITICAL, "$tag DIMODIFIKASI: ${it.name}", "Hash berbeda dari baseline Play Store.") }
        renamed.forEach { (from, to) -> critical += Item(Level.CRITICAL, "$tag DI-RENAME", "$from  ->  $to (isi identik)") }
        missing.filter { isCritical(it) }.forEach { critical += Item(Level.CRITICAL, "$tag HILANG: $it", "Ada di baseline, tidak ada di APK.") }
        added.filter { it.critical }.forEach { critical += Item(Level.CRITICAL, "$tag TAMBAHAN: ${it.name}", "Tidak ada di baseline.") }
        items += critical.take(MAX_LINES)
        if (critical.size > MAX_LINES) items += Item(Level.CRITICAL, "$tag ...dan ${critical.size - MAX_LINES} perbedaan kritis lain", "")

        // file non-kritis (resource/bahasa/density) beda antar HP -> hanya informasi
        val minor = modified.count { !it.critical } + missing.count { !isCritical(it) } + added.count { !it.critical }
        if (minor > 0) items += Item(Level.LOW, "$tag $minor file non-kritis berbeda dari baseline", "Resource/bahasa/density bisa berbeda antar HP. Tidak dihitung sebagai cheat.")

        if (critical.isEmpty()) items += Item(Level.INFO, "$tag File kritis identik dengan baseline Play Store", "libil2cpp, libunity, metadata, dex: ${actual.values.count { it.critical }} entry dicek.")
        return items
    }

    private fun loadBaseline(ctx: Context, pkg: String, vc: Long): JSONObject? {
        val name = "baseline_${pkg}_$vc.json"
        val dirs = listOfNotNull(File(ctx.filesDir, "baselines"), ctx.getExternalFilesDir(null))
        for (d in dirs) {
            val f = File(d, name)
            if (f.isFile) try { return JSONObject(f.readText()) } catch (e: Exception) {}
        }
        try {
            ctx.assets.open("baselines/$name").use { return JSONObject(it.bufferedReader().readText()) }
        } catch (e: Exception) {}
        if (REMOTE_BASELINE_URL.isNotEmpty()) try {
            val c = URL(REMOTE_BASELINE_URL + name).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 15000
            if (c.responseCode == 200) {
                val text = c.inputStream.bufferedReader().readText()
                val dir = File(ctx.filesDir, "baselines")
                dir.mkdirs()
                File(dir, name).writeText(text)
                return JSONObject(text)
            }
        } catch (e: Exception) {}
        return null
    }

    // ---------------------------------------------------------------- lib hasil ekstrak

    private fun verifyExtractedLibs(tag: String, dir: String?, agg: Map<String, Agg>, root: Boolean): List<Item> {
        val items = ArrayList<Item>()
        if (dir == null) return items
        val files = File(dir).listFiles()?.filter { it.isFile }
        if (files == null) {
            items += Item(Level.INFO, "$tag Lib ekstrak tidak terbaca", "Game memakai lib langsung dari APK, atau folder tidak dapat diakses.")
            return items
        }
        var ok = 0
        for (f in files) {
            val sha = try {
                f.inputStream().use { inspect(it, true).sha }
            } catch (e: Exception) {
                if (root) rootShell("sha256sum '${f.absolutePath}'")?.trim()?.split(" ")?.firstOrNull() else null
            }
            if (sha.isNullOrEmpty()) continue
            val matches = agg.values.filter { it.name.startsWith("lib/") && it.name.endsWith("/" + f.name) }
            when {
                matches.isEmpty() -> items += Item(Level.CRITICAL, "$tag Lib ekstrak tidak ada di APK", "${f.name} ($sha)")
                matches.none { m -> m.shaKey.split(",").contains(sha) } ->
                    items += Item(Level.CRITICAL, "$tag Lib ekstrak DIGANTI", "${f.name} berbeda dari yang ada di APK (SHA-256 $sha)")
                else -> ok++
            }
        }
        if (ok > 0) items += Item(Level.INFO, "$tag Lib ekstrak cocok dengan APK", "$ok file")
        return items
    }

    // ---------------------------------------------------------------- memori (root)

    private fun scanLiveMaps(tag: String, pkg: String): List<Item> {
        val items = ArrayList<Item>()
        val pid = rootShell("pidof $pkg")?.trim()?.split(Regex("\\s+"))?.firstOrNull()?.toIntOrNull()
        if (pid == null) {
            items += Item(Level.INFO, "$tag Game tidak berjalan", "Jalankan game lalu scan lagi agar memori ikut diperiksa.")
            return items
        }
        val maps = rootShell("cat /proc/$pid/maps")
        if (maps.isNullOrBlank()) {
            items += Item(Level.INFO, "$tag /proc/$pid/maps tidak terbaca", "")
            return items
        }
        val okPrefix = listOf(
            "/system/", "/vendor/", "/apex/", "/product/", "/system_ext/", "/odm/", "/system_dlkm/",
            "/data/app/", "/data/app-lib/", "/data/dalvik-cache/", "/dev/", "/memfd:jit", "/memfd:doublemapper"
        )
        val ownData = listOf("/data/data/$pkg/", "/data/user/0/$pkg/", "/data/user_de/0/$pkg/")
        var rwxAnon = 0
        for (line in maps.lineSequence()) {
            if (line.isBlank()) continue
            val parts = line.trim().split(Regex("\\s+"), limit = 6)
            val perms = parts.getOrNull(1) ?: continue
            val path = parts.getOrNull(5)?.trim().orEmpty()
            if (path.contains("(deleted)") && path.contains(".so"))
                items += Item(Level.CRITICAL, "$tag Lib dihapus tapi masih termuat", path)
            if (path.startsWith("/memfd:") && !path.startsWith("/memfd:jit") && !path.startsWith("/memfd:doublemapper"))
                items += Item(Level.CRITICAL, "$tag Lib dimuat dari memfd (injeksi)", path)
            if (path.contains(".so") && !path.startsWith("/memfd:") && okPrefix.none { path.startsWith(it) }) {
                val own = ownData.any { path.startsWith(it) }
                items += Item(
                    if (own) Level.WARN else Level.CRITICAL,
                    if (own) "$tag Lib dimuat dari folder data game" else "$tag Lib dimuat dari lokasi tidak lazim",
                    path
                )
            }
            val core = path.endsWith("/libil2cpp.so") || path.endsWith("/libunity.so") || path.endsWith("/libmain.so")
            if (core && path.startsWith("/data/app/") && !path.contains("/$pkg-"))
                items += Item(Level.CRITICAL, "$tag Lib inti berasal dari paket lain", path)
            if (perms.startsWith("rwx") && (path.isEmpty() || path.startsWith("[anon:")) && !path.contains("jit") && !path.contains("dalvik"))
                rwxAnon++
        }
        if (rwxAnon > 0) items += Item(Level.WARN, "$tag Region memori rwx anonim", "$rwxAnon region (kemungkinan kode injeksi)")
        items += Item(Level.INFO, "$tag Memori diperiksa", "PID $pid")
        return items.distinctBy { it.title + it.detail }
    }

    // ---------------------------------------------------------------- folder data

    private fun scanDataDirs(tag: String, pkg: String, root: Boolean): List<Item> {
        val items = ArrayList<Item>()
        val lines = ArrayList<String>()
        if (root) {
            val script =
                "for d in /data/data/$pkg /sdcard/Android/data/$pkg /sdcard/Android/obb/$pkg; do " +
                    "[ -d \"\$d\" ] && find \"\$d\" -type f -size +2k 2>/dev/null; done | while read f; do " +
                    "h=\$(head -c 4 \"\$f\" | od -An -tx1 | tr -d ' \\n'); " +
                    "case \"\$h\" in 7f454c46) echo \"ELF \$f\";; 6465780a) echo \"DEX \$f\";; esac; done"
            val out = rootShell(script, 90)
            if (out == null) items += Item(Level.INFO, "$tag Folder data tidak terbaca", "Perintah root gagal atau waktu habis.")
            else out.lines().filter { it.isNotBlank() }.forEach { lines += it }
        } else {
            val base = File("/sdcard/Android/data/$pkg")
            if (!base.isDirectory || base.listFiles() == null) {
                items += Item(Level.INFO, "$tag Folder data game tidak dapat diverifikasi", "Android 11+ memblokir Android/data tanpa root. Ini bukan indikasi cheat.")
                return items
            }
            base.walkTopDown().filter { it.isFile && it.length() > 2048 }.take(20000).forEach { f ->
                try {
                    val h = ByteArray(4)
                    f.inputStream().use { it.read(h) }
                    if (h[0] == 0x7F.toByte() && h[1] == 0x45.toByte() && h[2] == 0x4C.toByte() && h[3] == 0x46.toByte()) lines += "ELF ${f.absolutePath}"
                    if (h[0] == 0x64.toByte() && h[1] == 0x65.toByte() && h[2] == 0x78.toByte() && h[3] == 0x0A.toByte()) lines += "DEX ${f.absolutePath}"
                } catch (e: Exception) {}
            }
        }
        var disguised = 0
        var plain = 0
        for (l in lines) {
            val kind = l.substringBefore(' ')
            val path = l.substringAfter(' ')
            val lower = path.lowercase()
            val normal = (kind == "ELF" && (lower.endsWith(".so") || lower.endsWith(".odex") || lower.endsWith(".oat"))) ||
                (kind == "DEX" && lower.endsWith(".dex"))
            if (normal) {
                plain++
            } else {
                disguised++
                if (disguised <= MAX_LINES) items += Item(Level.CRITICAL, "$tag $kind menyamar di folder data", path)
            }
        }
        if (disguised > MAX_LINES) items += Item(Level.CRITICAL, "$tag ...dan ${disguised - MAX_LINES} binary menyamar lain", "")
        if (plain > 0) items += Item(Level.LOW, "$tag $plain binary bernama wajar di folder data", "Umumnya lib dari Play Core/splitcompat. Tidak dihitung sebagai cheat.")
        if (lines.isEmpty()) items += Item(Level.INFO, "$tag Folder data bersih dari binary menyamar", "")
        return items
    }

    // ---------------------------------------------------------------- util

    private fun rootShell(cmd: String, timeoutSec: Long = 25): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val dog = Thread {
            try { Thread.sleep(timeoutSec * 1000) } catch (e: InterruptedException) { return@Thread }
            p.destroy()
        }
        dog.isDaemon = true
        dog.start()
        val text = try { p.inputStream.bufferedReader().readText() } catch (e: Exception) { "" }
        val code = try { p.waitFor() } catch (e: InterruptedException) { -1 }
        dog.interrupt()
        if (code != 0 && text.isBlank()) null else text
    } catch (e: Exception) {
        null
    }

    private fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
}
