package com.azx.scanner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Menerima ACTION_PACKAGE_FULLY_REMOVED dari sistem dan mencatat WAKTU PASTI aplikasi dihapus,
 * lengkap dengan penanda apakah aplikasi itu sudah dicurigai di scan sebelumnya.
 * Hanya aktif setelah scanner pernah dibuka sekali dan tidak sedang di-force-stop.
 */
class PackageRemovedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_PACKAGE_FULLY_REMOVED) return
        if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
        val pkg = intent.data?.schemeSpecificPart ?: return
        try {
            val journal = TraceJournal(context)
            val snap = journal.snapshotEntry(pkg)
            val now = System.currentTimeMillis()
            journal.addEvents(
                listOf(
                    TraceJournal.Event("REMOVED", pkg, snap?.label ?: pkg, now, now, now, snap?.susp ?: false)
                )
            )
        } catch (e: Exception) {
        }
    }
}
