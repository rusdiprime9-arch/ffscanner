package com.azx.scanner

import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Kind
import com.azx.scanner.CheatSignatures.Severity

/**
 * Satu-satunya tempat vonis ditentukan (murni Kotlin, bisa diuji di JVM tanpa Android).
 *
 * Aturan anti salah deteksi:
 *  R1. Temuan kind=ENV (root, ROM/kernel custom, bootloader, framework injeksi umum) TIDAK PERNAH mempengaruhi vonis,
 *      seberapa pun severity-nya.
 *  R2. CHEAT hanya bila ada temuan EVIDENCE bersaverity HIGH. HIGH hanya boleh dibuat dari bukti isi/sumber
 *      (lihat ContentValidator), bukan dari nama.
 *  R3. Jumlah MEDIUM, sebanyak apa pun, tidak pernah naik menjadi CHEAT. Paling tinggi PERLU DIPERIKSA.
 *  R4. LOW dan INFO tidak mempengaruhi vonis.
 */
object VerdictPolicy {

    enum class Verdict { CHEAT, SUSPECT, CLEAN }

    fun decide(findings: List<Finding>): Verdict {
        val evidence = findings.filter { it.kind == Kind.EVIDENCE }
        return when {
            evidence.any { it.severity == Severity.HIGH } -> Verdict.CHEAT
            evidence.any { it.severity == Severity.MEDIUM } -> Verdict.SUSPECT
            else -> Verdict.CLEAN
        }
    }
}
