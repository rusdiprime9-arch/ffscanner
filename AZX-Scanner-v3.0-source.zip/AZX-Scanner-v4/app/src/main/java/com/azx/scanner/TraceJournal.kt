package com.azx.scanner

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Jurnal lokal (tanpa root) untuk jejak yang hilang dari sistem begitu terjadi:
 *  - snapshot daftar aplikasi pengguna pada tiap scan -> aplikasi yang hilang di scan berikutnya ketahuan
 *  - event penghapusan aplikasi yang diterima langsung dari sistem (PackageRemovedReceiver)
 *  - perubahan status USB debugging / debugging nirkabel antar scan
 * Disimpan di SharedPreferences milik scanner sendiri. Event disimpan 30 hari.
 */
class TraceJournal(context: Context) {

    class Snap(val label: String, val install: Long, val susp: Boolean)

    /** type: REMOVED (waktu pasti), GONE (hilang di antara dua scan), ADB (perubahan status debugging). */
    class Event(
        val type: String,
        val name: String,
        val label: String,
        val time: Long,
        val from: Long,
        val to: Long,
        val susp: Boolean
    )

    private val sp = context.applicationContext.getSharedPreferences("azx_journal", Context.MODE_PRIVATE)

    fun loadSnapshot(): Map<String, Snap> = synchronized(LOCK) {
        val res = LinkedHashMap<String, Snap>()
        try {
            val o = JSONObject(sp.getString("snap", "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                val s = o.getJSONObject(k)
                res[k] = Snap(s.optString("l", k), s.optLong("i", 0L), s.optBoolean("s", false))
            }
        } catch (e: Exception) {
        }
        res
    }

    fun snapshotEntry(pkg: String): Snap? = loadSnapshot()[pkg]

    fun saveSnapshot(map: Map<String, Snap>, scanTime: Long) = synchronized(LOCK) {
        val o = JSONObject()
        for ((k, v) in map) {
            o.put(k, JSONObject().put("l", v.label).put("i", v.install).put("s", v.susp))
        }
        sp.edit().putString("snap", o.toString()).putLong("lastScan", scanTime).commit()
        Unit
    }

    fun lastScan(): Long = sp.getLong("lastScan", 0L)

    fun events(): List<Event> = synchronized(LOCK) { readEvents() }

    fun addEvents(list: List<Event>) = synchronized(LOCK) {
        if (list.isEmpty()) return@synchronized
        val all = ArrayList<Event>(readEvents())
        all += list
        val limit = System.currentTimeMillis() - RETENTION_MS
        val kept = all.filter { maxOf(it.time, it.to) >= limit }
            .sortedBy { maxOf(it.time, it.to) }
            .takeLast(200)
        val arr = JSONArray()
        for (e in kept) {
            arr.put(
                JSONObject().put("t", e.type).put("n", e.name).put("l", e.label)
                    .put("w", e.time).put("f", e.from).put("e", e.to).put("s", e.susp)
            )
        }
        sp.edit().putString("events", arr.toString()).commit()
        Unit
    }

    /** Status debugging pada scan terakhir: (nirkabel, usb), atau null bila belum pernah dicatat. */
    fun adbState(): Pair<Int, Int>? {
        if (!sp.contains("adbWifi")) return null
        return Pair(sp.getInt("adbWifi", 0), sp.getInt("adbUsb", 0))
    }

    fun saveAdbState(wifi: Int, usb: Int) {
        sp.edit().putInt("adbWifi", wifi).putInt("adbUsb", usb).commit()
    }

    private fun readEvents(): List<Event> {
        val res = ArrayList<Event>()
        try {
            val arr = JSONArray(sp.getString("events", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                res += Event(
                    o.optString("t"), o.optString("n"), o.optString("l"),
                    o.optLong("w", 0L), o.optLong("f", 0L), o.optLong("e", 0L), o.optBoolean("s", false)
                )
            }
        } catch (e: Exception) {
        }
        return res
    }

    companion object {
        private val LOCK = Any()
        private const val RETENTION_MS = 30L * 24 * 60 * 60 * 1000
    }
}
