package com.azx.scanner

import android.content.Intent
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.azx.scanner.CheatSignatures.Severity
import com.azx.scanner.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var engine: ScannerEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        engine = ScannerEngine(this)

        setupWelcome()

        binding.btnScan.setOnClickListener { startScan() }
        binding.btnBaseline.setOnClickListener { makeBaseline() }
    }

    /** Layar sambutan bertema AZZHX; hanya tampilan, tidak menyentuh mesin scan. */
    private fun setupWelcome() {
        val versionName = try {
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            null
        }
        if (!versionName.isNullOrBlank()) {
            binding.tvVersion.text = "Azzhx Anticheat Enterprise Security Suite · Version $versionName"
        }
        binding.btnGetStarted.setOnClickListener {
            binding.btnGetStarted.isEnabled = false
            binding.scannerLayer.alpha = 0f
            binding.scannerLayer.visibility = View.VISIBLE
            binding.scannerLayer.animate().alpha(1f).setDuration(280).start()
            binding.welcomeLayer.animate().alpha(0f).setDuration(220).withEndAction {
                binding.welcomeLayer.visibility = View.GONE
            }.start()
        }
    }

    private fun color(resId: Int): Int = ContextCompat.getColor(this, resId)

    /** Deteksi overlay: Android menandai sentuhan bila jendela kita tertutup jendela lain. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if ((ev.flags and MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0 ||
            (ev.flags and MotionEvent.FLAG_WINDOW_IS_PARTIALLY_OBSCURED) != 0) {
            engine.overlayObscuredSeen = true
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun startScan() {
        binding.btnScan.isEnabled = false
        binding.btnBaseline.isEnabled = false
        binding.tvStatus.text = "SCAN…"
        binding.tvStatus.setTextColor(color(R.color.azx_text_soft))
        binding.progressScan.visibility = View.VISIBLE
        binding.tvDetail.text = "Memindai jejak cheat dan memverifikasi isi APK…\n" +
            "Semua modul dijalankan paralel. Jika ada dialog izin root, pilih IZINKAN."

        lifecycleScope.launch {
            val result = engine.runFullScan()
            showResult(result)
            binding.btnScan.isEnabled = true
            binding.btnBaseline.isEnabled = true
        }
    }

    private fun showResult(result: ScannerEngine.ScanResult) {
        binding.progressScan.visibility = View.INVISIBLE
        when (result.verdict) {
            VerdictPolicy.Verdict.CHEAT -> {
                binding.tvStatus.text = "CHEAT"
                binding.tvStatus.setTextColor(color(R.color.azx_verdict_cheat))
            }
            VerdictPolicy.Verdict.SUSPECT -> {
                binding.tvStatus.text = "PERLU DIPERIKSA"
                binding.tvStatus.setTextColor(color(R.color.azx_verdict_suspect))
            }
            VerdictPolicy.Verdict.CLEAN -> {
                binding.tvStatus.text = if (result.rootGranted) "BERSIH" else "BERSIH (terbatas)"
                binding.tvStatus.setTextColor(color(R.color.azx_verdict_clean))
            }
        }

        // Bukti (berpengaruh ke vonis) dipisah dari kondisi lingkungan perangkat (root/ROM/kernel custom: bukan cheat).
        val issues = result.findings
            .filter { it.severity != Severity.INFO && it.kind == CheatSignatures.Kind.EVIDENCE }
            .sortedBy { it.severity.ordinal }
        val env = result.findings.filter { it.severity != Severity.INFO && it.kind == CheatSignatures.Kind.ENV }
        val info = result.findings.filter { it.severity == Severity.INFO }

        val rootText = when {
            result.rooted && result.rootGranted -> "root (diizinkan)"
            result.rooted -> "root (ditolak)"
            else -> "non-root"
        }
        fun short(d: String, max: Int = 150): String {
            val t = d.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(3).joinToString(" · ")
            return if (t.length > max) t.take(max - 1) + "…" else t
        }
        val proven = issues.filter { it.severity == Severity.HIGH }
        val maybe = issues.filter { it.severity == Severity.MEDIUM }
        val notes = issues.filter { it.severity == Severity.LOW } + env

        val sb = StringBuilder()
        sb.appendLine("${result.timestamp} · $rootText · cakupan ${if (result.rootGranted) "penuh" else "terbatas"}")
        sb.appendLine()
        when (result.verdict) {
            VerdictPolicy.Verdict.CHEAT -> {
                sb.appendLine("CHEAT. Terbukti dari isi/sumber:")
                proven.take(6).forEach { sb.appendLine("• ${it.title}"); sb.appendLine("    ${short(it.detail)}") }
                if (proven.size > 6) sb.appendLine("• dan ${proven.size - 6} bukti lain")
                if (maybe.isNotEmpty()) {
                    sb.appendLine()
                    sb.appendLine("Belum terbukti (perlu cek):")
                    maybe.take(4).forEach { sb.appendLine("• ${it.title}") }
                }
            }
            VerdictPolicy.Verdict.SUSPECT -> {
                sb.appendLine("PERLU DIPERIKSA. Ada indikasi, belum ada bukti cukup untuk menyebut cheat:")
                maybe.take(6).forEach { sb.appendLine("• ${it.title}"); sb.appendLine("    ${short(it.detail)}") }
                if (maybe.size > 6) sb.appendLine("• dan ${maybe.size - 6} indikasi lain")
            }
            VerdictPolicy.Verdict.CLEAN -> {
                sb.appendLine(
                    if (result.rootGranted) "BERSIH. Tidak ada bukti cheat."
                    else "BERSIH pada bagian yang bisa diperiksa tanpa root. Memori game, data/ dan kernel tidak bisa diverifikasi tanpa root."
                )
            }
        }

        if (notes.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("Catatan (bukan bukti cheat):")
            notes.take(8).forEach { sb.appendLine("• ${it.title}") }
            if (notes.size > 8) sb.appendLine("• dan ${notes.size - 8} catatan lain")
        }
        if (info.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("Tidak dapat diverifikasi / info:")
            info.take(6).forEach { sb.appendLine("• ${it.title}") }
            if (info.size > 6) sb.appendLine("• dan ${info.size - 6} info lain")
        }

        binding.tvDetail.text = sb.toString()
    }

    /**
     * Membuat baseline dari Free Fire yang terpasang dari Play Store.
     * Ditolak otomatis bila FF tidak berasal dari Play Store.
     */
    private fun makeBaseline() {
        binding.btnScan.isEnabled = false
        binding.btnBaseline.isEnabled = false
        binding.tvDetail.text = "Membuat baseline dari Free Fire Play Store…\nBisa memakan 30-90 detik."

        lifecycleScope.launch {
            val files = ArrayList<File>()
            val errors = ArrayList<String>()
            withContext(Dispatchers.IO) {
                val installed = CheatSignatures.FF_PACKAGES.filter { isInstalled(it) }
                if (installed.isEmpty()) errors += "Free Fire resmi tidak terpasang."
                for (pkg in installed) {
                    try {
                        files += IntegrityScanner.exportBaseline(this@MainActivity, pkg)
                    } catch (e: Exception) {
                        errors += "$pkg: ${e.message}"
                    }
                }
            }

            val sb = StringBuilder()
            if (files.isNotEmpty()) {
                sb.appendLine("Baseline dibuat:")
                files.forEach { sb.appendLine("• ${it.name} (${it.length() / 1024} KB)") }
                sb.appendLine()
                sb.appendLine("Kirim file ini ke repo: taruh di app/src/main/assets/baselines/ lalu build ulang,")
                sb.appendLine("supaya semua HP bisa membandingkan FF mereka dengan FF Play Store versi tersebut.")
            }
            errors.forEach { sb.appendLine("✗ $it") }
            binding.tvDetail.text = sb.toString()

            if (files.isNotEmpty()) shareFiles(files)
            binding.btnScan.isEnabled = true
            binding.btnBaseline.isEnabled = true
        }
    }

    private fun shareFiles(files: List<File>) {
        try {
            val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
            }
            intent.type = "application/json"
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Bagikan baseline"))
        } catch (e: Exception) {
            binding.tvDetail.append("\nGagal membuka menu bagikan: ${e.message}")
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }
}
