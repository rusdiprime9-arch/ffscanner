package com.azx.scanner

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.provider.Settings
import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Severity
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

/**
 * Deteksi ADB yang BENAR-BENAR dipakai, bukan sekadar pengaturannya menyala.
 *
 * Prinsip:
 *  - Debugging nirkabel / USB debugging yang hanya menyala = INFO / LOW. BUKAN cheat.
 *  - Yang dicari: ada perangkat TERSAMBUNG, dan apakah ada bukti data game diubah lewat ADB.
 *  - Severity naik bertahap:
 *      menyala saja                              -> INFO
 *      perangkat tersambung                      -> LOW
 *      tersambung + Free Fire sedang berjalan    -> MEDIUM
 *      ADB lokal di HP sendiri (pola Shizuku)    -> MEDIUM
 *      tersambung + bukti data game diubah       -> HIGH
 *      sisa file kiriman shell tanpa sesi aktif  -> MEDIUM
 *
 * Non-root: Android menyembunyikan soket/proses milik sistem, jadi koneksi nirkabel tidak bisa
 * dipastikan. Itu dilaporkan sebagai "tidak dapat diverifikasi" (INFO), bukan cheat.
 * Root: soket adbd, proses anak adbd, proses shell, dan file di data game dibaca lewat su.
 */
class AdbSessionScanner(
    private val context: Context,
    private val rootGranted: Boolean,
    private val su: (String) -> String?
) {
    private val out = mutableListOf<Finding>()

    private fun add(title: String, detail: String, sev: Severity) {
        out += Finding(title, detail, sev)
    }

    private val mutatingCmd = Regex("\\b(cp|mv|rm|dd|sed|tar|unzip|chmod|chown|cat|tee|echo|sqlite3|run-as|pm clear)\\b")

    private class Peer(val remote: String, val remotePort: Int, val loopback: Boolean)

    private class RootView(
        val peers: List<Peer>,
        val sessions: List<String>,
        val shellTouchesGame: List<String>,
        val ffRunning: Boolean,
        val shellOwnedFiles: List<String>,
        val recentFiles: List<String>
    )

    fun scan(): List<Finding> {
        val wifiOn = settingInt("adb_wifi_enabled") == 1
        val usbAdbOn = settingInt(Settings.Global.ADB_ENABLED) == 1
        val tcpPort = prop("service.adb.tcp.port").toIntOrNull()?.takeIf { it > 0 }
        val tlsPort = prop("service.adb.tls.port").toIntOrNull()?.takeIf { it > 0 }
        val usbConnected = usbAdbConnected()

        if (!wifiOn && !usbAdbOn && tcpPort == null) return out

        val rv = if (rootGranted) readRootView() else null

        // ---------------- tanpa root ----------------
        if (rv == null) {
            if (usbConnected == true) {
                add("USB debugging tersambung ke perangkat", "Kabel USB terhubung dengan mode ADB aktif. Umum dipakai sah, hanya informasi.", Severity.LOW)
            } else if (usbAdbOn) {
                add("USB debugging aktif", "Developer options menyala, tidak ada perangkat USB tersambung. Hanya informasi.", Severity.INFO)
            }
            if (wifiOn || tcpPort != null) {
                val ports = listOfNotNull(tlsPort?.let { "TLS $it" }, tcpPort?.let { "TCP $it" }).joinToString()
                add(
                    "Debugging nirkabel menyala (koneksi tidak dapat diverifikasi)",
                    "Pengaturan menyala${if (ports.isNotEmpty()) " ($ports)" else ""}, tetapi tanpa root Android menyembunyikan daftar perangkat " +
                        "yang tersambung. Menyala saja BUKAN cheat. Gunakan root untuk memeriksa perangkat tersambung dan perubahan data game.",
                    Severity.INFO
                )
            }
            val owned = nonRootShellOwnedFiles()
            if (owned.isNotEmpty()) {
                add(
                    "File di data game dimiliki shell (kiriman ADB)",
                    "File di folder game berpemilik shell/ADB, bukan app game:\n" + owned.take(5).joinToString("\n"),
                    Severity.MEDIUM
                )
            }
            return out
        }

        // ---------------- dengan root ----------------
        val wirelessPeers = rv.peers.filter { !it.loopback }
        val localPeers = rv.peers.filter { it.loopback }
        val usbLive = usbConnected == true
        val connected = wirelessPeers.isNotEmpty() || localPeers.isNotEmpty() || usbLive
        // Bukti KUAT = sesi shell menyentuh data game / file berpemilik shell di folder game.
        // File berubah saat game mati bisa saja update/unduhan resmi, jadi hanya menaikkan ke MEDIUM.
        val evidence = rv.shellTouchesGame.isNotEmpty() || rv.shellOwnedFiles.isNotEmpty()
        val changedWhileStopped = !rv.ffRunning && rv.recentFiles.isNotEmpty()

        if (usbAdbOn && !usbLive && !connected) {
            add("USB debugging aktif", "Developer options menyala, tidak ada perangkat tersambung. Hanya informasi.", Severity.INFO)
        }
        if ((wifiOn || tcpPort != null) && !connected) {
            add(
                "Debugging nirkabel menyala, tidak ada perangkat tersambung",
                "Diperiksa lewat root: tidak ada koneksi aktif ke adbd. Menyala saja BUKAN cheat.",
                Severity.INFO
            )
        }

        if (wirelessPeers.isNotEmpty()) {
            val list = wirelessPeers.joinToString("\n") { "- ${it.remote}:${it.remotePort}" }
            val sev = when {
                evidence -> Severity.HIGH
                rv.ffRunning || changedWhileStopped -> Severity.MEDIUM
                else -> Severity.LOW
            }
            add("Perangkat tersambung via ADB nirkabel (${wirelessPeers.size})", list + sessionNote(rv, evidence), sev)
        }
        if (localPeers.isNotEmpty()) {
            add(
                "ADB tersambung dari HP ini sendiri",
                "Koneksi ADB berasal dari localhost (aplikasi di HP yang sama memakai ADB nirkabel). " +
                    "Ini pola start Shizuku/LADB yang dipakai alat inject.${sessionNote(rv, evidence)}",
                if (evidence) Severity.HIGH else Severity.MEDIUM
            )
        }
        if (usbLive) {
            add(
                "USB debugging tersambung ke perangkat",
                "Kabel USB terhubung dengan mode ADB aktif.${sessionNote(rv, evidence)}",
                if (evidence) Severity.HIGH else if (rv.ffRunning || changedWhileStopped) Severity.MEDIUM else Severity.LOW
            )
        }

        if (rv.shellTouchesGame.isNotEmpty()) {
            add(
                "Sesi shell ADB menyentuh data game",
                rv.shellTouchesGame.take(5).joinToString("\n") { "- ${it.take(160)}" },
                if (connected) Severity.HIGH else Severity.MEDIUM
            )
        }
        if (rv.shellOwnedFiles.isNotEmpty()) {
            add(
                "File di data game dimiliki shell (kiriman ADB)",
                "File di folder game berpemilik shell/ADB, bukan app game:\n" + rv.shellOwnedFiles.take(5).joinToString("\n"),
                if (connected) Severity.HIGH else Severity.MEDIUM
            )
        }
        if (connected && changedWhileStopped && rv.shellOwnedFiles.isEmpty()) {
            add(
                "Data game berubah saat game tidak berjalan",
                "${rv.recentFiles.size} file di folder game diubah dalam 20 menit terakhir padahal Free Fire tidak aktif, " +
                    "dan ada perangkat ADB tersambung. Bisa update/unduhan resmi; belum terbukti diubah lewat ADB:\n" +
                    rv.recentFiles.take(5).joinToString("\n"),
                Severity.MEDIUM
            )
        }
        return out
    }

    private fun sessionNote(rv: RootView, evidence: Boolean): String {
        val sb = StringBuilder()
        if (rv.sessions.isNotEmpty()) sb.append("\nSesi shell aktif: ").append(rv.sessions.take(3).joinToString(" | ") { it.take(60) })
        sb.append(if (rv.ffRunning) "\nFree Fire sedang berjalan." else "\nFree Fire tidak sedang berjalan.")
        if (evidence) sb.append("\nAda bukti data game diubah lewat ADB.")
        return sb.toString()
    }

    // -------------------------------------------------------------------------
    // Root: satu panggilan su untuk semua data, dipisah penanda ##
    // -------------------------------------------------------------------------
    private fun readRootView(): RootView {
        val installed = CheatSignatures.FF_PACKAGES.filter { isInstalled(it) }
        val dirs = installed.flatMap {
            listOf("/data/data/$it", "/sdcard/Android/data/$it", "/sdcard/Android/obb/$it")
        }.joinToString(" ") { "'$it'" }
        val names = CheatSignatures.FF_PACKAGES.joinToString(" ")

        val script = buildString {
            append("echo '##SS'; (ss -tanp 2>/dev/null || netstat -tanp 2>/dev/null) | grep -i adbd; ")
            append("echo '##ADBD'; pidof adbd 2>/dev/null; ")
            append("echo '##PS'; ps -A -o USER,PID,PPID,ARGS 2>/dev/null; ")
            append("echo '##FF'; pidof $names 2>/dev/null; ")
            if (dirs.isNotEmpty()) {
                append("echo '##SHELLFILES'; find $dirs -type f -user 2000 2>/dev/null | head -n 20; ")
                append("echo '##RECENT'; find $dirs -type f -mmin -20 2>/dev/null | head -n 30; ")
            }
            append("echo '##END'")
        }
        val text = su(script) ?: ""
        val sec = sections(text)

        // koneksi ESTABLISHED milik adbd
        val peers = ArrayList<Peer>()
        val addr = Regex("^\\[?[0-9a-fA-F:.%]+\\]?:\\d+$")
        for (line in sec["##SS"].orEmpty()) {
            if (!line.contains("ESTAB", ignoreCase = true)) continue
            val tokens = line.split(Regex("\\s+")).filter { addr.matches(it) }
            if (tokens.size < 2) continue
            val remoteTok = tokens[1]
            val port = remoteTok.substringAfterLast(':').toIntOrNull() ?: 0
            val host = remoteTok.substringBeforeLast(':').trim('[', ']')
            val loop = host == "::1" || host.startsWith("127.") || host.startsWith("::ffff:127.")
            peers += Peer(host, port, loop)
        }

        // proses: sesi anak adbd dan proses shell yang menyebut data game
        val adbdPids = sec["##ADBD"].orEmpty().flatMap { it.split(Regex("\\s+")) }.mapNotNull { it.toIntOrNull() }.toSet()
        val sessions = ArrayList<String>()
        val touches = ArrayList<String>()
        for (line in sec["##PS"].orEmpty()) {
            val p = line.split(Regex("\\s+"), limit = 4)
            if (p.size < 4) continue
            val user = p[0]
            val pid = p[1].toIntOrNull() ?: continue
            val ppid = p[2].toIntOrNull() ?: continue
            val args = p[3]
            if (pid in adbdPids) continue
            if (args.startsWith("ps ") || args.contains("ps -A")) continue
            val isShellUser = user == "shell" || user == "2000"
            if (ppid in adbdPids) sessions += args
            val mentionsPkg = CheatSignatures.FF_PACKAGES.any { args.contains(it) }
            val mentionsData = args.contains("/Android/data/") || args.contains("/Android/obb/") ||
                args.contains("/data/data/") || args.contains("/data/user/")
            val mutating = mutatingCmd.containsMatchIn(args)
            // Sekadar menjalankan game (am start) bukan mengubah data; yang dihitung: menyentuh jalur data atau perintah ubah file bersama paket game
            if ((isShellUser || ppid in adbdPids) && (mentionsData || (mentionsPkg && mutating))) touches += "$user $args"
        }

        val ffRunning = sec["##FF"].orEmpty().flatMap { it.split(Regex("\\s+")) }.any { it.toIntOrNull() != null }

        return RootView(
            peers = peers,
            sessions = sessions,
            shellTouchesGame = touches,
            ffRunning = ffRunning,
            // su menggabung stderr ke stdout: hanya baris yang benar-benar path file yang dipakai
            shellOwnedFiles = sec["##SHELLFILES"].orEmpty().filter { it.startsWith("/") && !it.contains(": ") },
            recentFiles = sec["##RECENT"].orEmpty().filter { it.startsWith("/") && !it.contains(": ") }
        )
    }

    private fun sections(text: String): Map<String, List<String>> {
        val m = LinkedHashMap<String, MutableList<String>>()
        var cur = ""
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.startsWith("##")) {
                cur = l
                m[cur] = mutableListOf()
                continue
            }
            if (cur.isNotEmpty() && l.isNotEmpty()) m[cur]?.add(l)
        }
        return m
    }

    // -------------------------------------------------------------------------
    // Non-root (best effort)
    // -------------------------------------------------------------------------

    /** Status USB dari broadcast sticky sistem; dapat dibaca tanpa izin khusus. */
    private fun usbAdbConnected(): Boolean? = try {
        val i: Intent? = context.registerReceiver(null, IntentFilter("android.hardware.usb.action.USB_STATE"))
        if (i == null) null else i.getBooleanExtra("connected", false) && i.getBooleanExtra("adb", false)
    } catch (e: Exception) {
        null
    }

    /** Android <= 10 (atau akses diberikan): cari file di folder game yang pemiliknya shell (uid 2000). */
    private fun nonRootShellOwnedFiles(): List<String> {
        val found = ArrayList<String>()
        for (pkg in CheatSignatures.FF_PACKAGES) {
            for (base in listOf("/sdcard/Android/data/$pkg", "/sdcard/Android/obb/$pkg")) {
                val dir = File(base)
                if (!dir.isDirectory || dir.listFiles() == null) continue
                try {
                    var n = 0
                    for (f in dir.walkTopDown()) {
                        if (!f.isFile) continue
                        if (++n > 3000) break
                        val uid = try { android.system.Os.stat(f.absolutePath).st_uid } catch (e: Exception) { -1 }
                        if (uid == 2000) found += f.absolutePath
                        if (found.size >= 20) return found
                    }
                } catch (e: Exception) {
                }
            }
        }
        return found
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private fun settingInt(name: String): Int = try {
        Settings.Global.getInt(context.contentResolver, name, 0)
    } catch (e: Exception) {
        0
    }

    private fun prop(name: String): String = runCmd("getprop $name").trim()

    private fun runCmd(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        val text = BufferedReader(InputStreamReader(p.inputStream)).readText()
        p.waitFor()
        text
    } catch (e: Exception) {
        ""
    }

    private fun isInstalled(pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }
}
