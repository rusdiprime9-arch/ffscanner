package com.azx.scanner

import java.io.File
import java.util.zip.ZipFile

/**
 * Validasi berdasarkan ISI, bukan nama. Nama paket/library hanya dipakai untuk memilih apa yang
 * diperiksa; vonis berat (HIGH) hanya boleh dari isi yang benar-benar menunjukkan alat cheat.
 */
object ContentValidator {

    /** Penanda framework hook inline/native yang hampir tidak ada di library sah. */
    val HOOK_MARKERS = listOf(
        "MSHookFunction", "MSHookMessageEx", "DobbyHook", "xhook_register", "shadowhook_hook",
        "And64InlineHook", "SandHook", "HookZz", "frida-gadget", "gum_interceptor_attach"
    )

    /** Regex untuk grep -E lewat shell (root). */
    val HOOK_REGEX = HOOK_MARKERS.joinToString("|")
    const val FF_REGEX = "com\\.dts\\.freefire|com\\.garena\\.game\\.kg"

    /** Nama kelas yang hampir hanya dipakai menu cheat. Dicari DI DALAM dex (isi), bukan nama paket. */
    val CHEAT_CLASS_TOKENS = listOf(
        "ESPView", "Aimbot", "AimBot", "WallHack", "Wallhack", "NoRecoil", "SpeedHack",
        "HackerFloat", "AutoHeadshot", "AntiBan", "SilentAim", "MagicBullet"
    )

    class MenuEvidence(val tokens: List<String>, val mentionsFf: Boolean)

    /** Bedah dex: kelas menu cheat (ESP/aimbot/dll) dan apakah isinya menyebut Free Fire. */
    fun menuEvidence(path: String?): MenuEvidence {
        if (path == null) return MenuEvidence(emptyList(), false)
        val tokens = linkedSetOf<String>()
        var ff = false
        try {
            ZipFile(path).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val n = e.name
                    if (e.isDirectory || !(n.startsWith("classes") && n.endsWith(".dex")) || e.size !in 1..24_000_000) continue
                    val b = z.getInputStream(e).use { it.readBytes() }
                    for (t in CHEAT_CLASS_TOKENS) if (indexOf(b, t.toByteArray()) >= 0) tokens += t
                    if (indexOf(b, "freefire".toByteArray()) >= 0 || indexOf(b, "com.garena.game.kg".toByteArray()) >= 0) ff = true
                }
            }
        } catch (e: Exception) {
        }
        return MenuEvidence(tokens.toList(), ff)
    }

    class ApkEvidence(
        val known: Boolean,
        val packer: List<String>,
        val tunnel: List<String>,
        val hook: List<String>,
        val targetsFf: Boolean
    ) {
        /** Bukti kuat = isi APK sendiri menunjukkan alat cheat. */
        val strong: Boolean get() = known || packer.isNotEmpty() || tunnel.isNotEmpty() || hook.isNotEmpty()
    }

    /** Cari penanda hook di isi file (maks [maxBytes] pertama). Mengembalikan penanda yang ditemukan. */
    fun fileHookMarkers(f: File, maxBytes: Long = 12L * 1024 * 1024): List<String> {
        val found = linkedSetOf<String>()
        try {
            if (!f.isFile || !f.canRead()) return emptyList()
            val pats = HOOK_MARKERS.map { it to it.toByteArray(Charsets.US_ASCII) }
            val keep = pats.maxOf { it.second.size } - 1
            val buf = ByteArray(256 * 1024)
            var carry = ByteArray(0)
            var total = 0L
            f.inputStream().use { input ->
                while (total < maxBytes) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n == 0) continue
                    total += n
                    val window = if (carry.isEmpty()) buf.copyOf(n) else carry + buf.copyOf(n)
                    for ((name, p) in pats) if (indexOf(window, p) >= 0) found += name
                    carry = if (window.size > keep) window.copyOfRange(window.size - keep, window.size) else window
                }
            }
        } catch (e: Exception) {
        }
        return found.toList()
    }

    /** Bedah isi APK: string sampel cheat, packer, tunnel, penanda hook, dan apakah menyebut paket Free Fire. */
    fun apkEvidence(path: String?): ApkEvidence {
        if (path == null) return ApkEvidence(false, emptyList(), emptyList(), emptyList(), false)
        var known = false
        var targets = false
        val packer = linkedSetOf<String>()
        val tunnel = linkedSetOf<String>()
        val hook = linkedSetOf<String>()
        try {
            ZipFile(path).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    if (e.isDirectory) continue
                    val n = e.name
                    val isDex = n.startsWith("classes") && n.endsWith(".dex") && e.size in 1..12_000_000
                    val isSo = n.startsWith("lib/") && n.endsWith(".so") && e.size in 1..8_000_000
                    val isManifest = n == "AndroidManifest.xml" && e.size in 1..2_000_000
                    if (!isDex && !isSo && !isManifest) continue
                    val b = z.getInputStream(e).use { it.readBytes() }
                    for (k in CheatSignatures.KNOWN_CHEAT_STRINGS) {
                        if (indexOf(b, k.toByteArray(Charsets.UTF_8)) >= 0 || indexOf(b, k.toByteArray(Charsets.UTF_16LE)) >= 0) known = true
                    }
                    if (isDex || isSo) {
                        for (m in CheatSignatures.PACKER_MARKERS) if (indexOf(b, m.toByteArray()) >= 0) packer += m
                        for (h in HOOK_MARKERS) if (indexOf(b, h.toByteArray()) >= 0) hook += h
                    }
                    if (isSo) for (m in CheatSignatures.TUNNEL_NATIVE_MARKERS) if (indexOf(b, m.toByteArray()) >= 0) tunnel += m
                    if (isDex) for (p in CheatSignatures.FF_PACKAGES) if (indexOf(b, p.toByteArray()) >= 0) targets = true
                }
            }
        } catch (e: Exception) {
        }
        return ApkEvidence(known, packer.toList(), tunnel.toList(), hook.toList(), targets)
    }

    fun indexOf(hay: ByteArray, needle: ByteArray): Int {
        if (needle.isEmpty() || hay.size < needle.size) return -1
        val first = needle[0]
        val last = hay.size - needle.size
        var i = 0
        while (i <= last) {
            if (hay[i] == first) {
                var j = 1
                while (j < needle.size && hay[i + j] == needle[j]) j++
                if (j == needle.size) return i
            }
            i++
        }
        return -1
    }
}
