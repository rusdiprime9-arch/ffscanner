# AZX Scanner v5.0

Free Fire Trace Engine: deteksi jejak cheat + verifikasi integritas Free Fire terhadap versi Play Store.

## Prinsip root / non-root
- **Non-root:** hal yang memang tidak bisa dibuka tanpa root (`/data/adb`, `/data/data`, `Android/data`, memori game, `kallsyms`) dilaporkan sebagai **"tidak dapat diverifikasi"** (catatan INFO), **bukan cheat**.
- **Root (akses su diberikan):** semua itu dibaca lewat `su` dan diperiksa penuh.
- Root, VPN, bootloader unlocked, USB debugging = **LOW** (informasi). Status **CHEAT** hanya bila ada bukti nyata (HIGH) atau minimal 3 indikasi MEDIUM.

## Yang dicek
| Modul | Non-root | Root |
|-------|:-------:|:----:|
| Sumber install FF (Play Store / toko lain / sideload) | ✓ | ✓ |
| Sertifikat penanda tangan, kunci debug, debuggable | ✓ | ✓ |
| Isi APK + split di-hash (libil2cpp.so, libunity.so, global-metadata.dat, dex) | ✓ | ✓ |
| ELF menyamar (bukan .so), .so palsu, DEX tersembunyi, entry ganda | ✓ | ✓ |
| Perbandingan dengan baseline Play Store (hash, rename, hilang, tambahan) | ✓ | ✓ |
| Lib hasil ekstrak vs isi APK | ✓ (bila terbaca) | ✓ |
| Jejak root yang terlihat dari mount & library di proses scanner | ✓ | ✓ |
| Memori game `/proc/PID/maps` (lib dari lokasi aneh, memfd, deleted, rwx, hook) | – | ✓ |
| Folder data game (ELF/DEX menyamar, residual hook/inject/drip) | Android <= 10 | ✓ |
| Modul Magisk/KernelSU di `/data/adb/modules`, simbol kernel | – | ✓ |
| Package, container/virtual space, accessibility, Shizuku, ADB, port | ✓ | ✓ |

## Baseline (perbandingan dengan FF Play Store)
Baseline = daftar hash isi FF Play Store untuk satu versi.
1. Di HP yang FF-nya dari **Play Store** dan bersih, buka app, tekan **BUAT BASELINE**.
   (Ditolak otomatis bila FF tidak terpasang dari Play Store.)
2. Bagikan file `baseline_<paket>_<versionCode>.json` ke komputer.
3. Taruh di `app/src/main/assets/baselines/`, commit, build ulang. Satu file per versi FF dan per ABI (arm64/armv7).
4. (Opsional) isi `REMOTE_BASELINE_URL` di `IntegrityScanner.kt` agar baseline diunduh dari repo.

Tanpa baseline, scanner tetap memeriksa installer, sertifikat, dan anomali struktural, tetapi perbandingan hash tidak berjalan.

## Build
Letakkan zip ini di repo; workflow GitHub Actions `Build APK` seperti biasa. Lokal: `./gradlew assembleRelease`.

## Catatan
- Tidak ada pemindai yang kebal. Mod yang hanya mengubah memori saat game berjalan hanya terlihat sebagian lewat root.
- Field installer bisa dipalsukan root, karena itu verifikasi utama memakai sertifikat dan hash isi APK.
