package com.azx.scanner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Severity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Prinsip v5:
 *  - Yang TIDAK BISA dibuka tanpa root (/data/adb, /data/data, Android/data, memori game, kallsyms)
 *    dilaporkan sebagai INFO "tidak dapat diverifikasi", BUKAN cheat.
 *  - Dengan root (akses su diberikan) semua itu dibaca lewat su dan dicek penuh.
 *  - Keberadaan root/VPN/boot unlocked saja = LOW (informasi). CHEAT hanya bila ada bukti nyata
 *    (HIGH) atau minimal 3 indikasi MEDIUM.
 */
class ScannerEngine(private val context: Context) {

    private val findings = mutableListOf<Finding>()
    private var isRooted = false
    private var rootGranted = false

    suspend fun runFullScan(): ScanResult = withContext(Dispatchers.IO) {
        findings.clear()
        isRooted = checkRoot()
        rootGranted = false
        if (isRooted) {
            rootGranted = suCmd("id", 30_000L)?.contains("uid=0") == true
        }

        when {
            rootGranted -> add("Mode root", "Akses su diberikan: /data/adb, data game, memori game, dan kallsyms dibaca lewat root.", Severity.INFO)
            isRooted -> add(
                "Mode root ditolak",
                "Root terdeteksi tetapi akses su tidak diberikan. Izinkan di Magisk/KernelSU/APatch lalu scan ulang agar pemeriksaan penuh.",
                Severity.INFO
            )
            else -> add(
                "Mode non-root",
                "/data/adb, /data/data, Android/data, memori game, dan kallsyms tidak bisa dibuka tanpa root. Item itu ditandai 'tidak dapat diverifikasi' dan BUKAN dianggap cheat.",
                Severity.INFO
            )
        }

        step("Package") { scanPackages() }
        step("Filesystem") { scanFilesystem() }
        step("Proc/maps") { scanProcMapsAndMemory() }
        step("Network") { scanNetworkAndVpn() }
        step("Virtual space") { scanVirtualSpaces() }
        step("Kernel") { scanKernelResiduals() }
        step("Accessibility") { scanAccessibility() }
        step("Shizuku/ADB") { scanShizukuAndAdb() }
        step("Data FF") { scanFreeFireResiduals() }
        step("Integritas FF") {
            IntegrityScanner.scan(context, rootGranted).forEach { findings += toFinding(it) }
        }

        val high = findings.count { it.severity == Severity.HIGH }
        val med = findings.count { it.severity == Severity.MEDIUM }
        val isCheat = high > 0 || med >= 3

        ScanResult(
            isCheat = isCheat,
            findings = findings.toList(),
            rooted = isRooted,
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
            rootGranted = rootGranted
        )
    }

    // -------------------------------------------------------------------------
    // 1. Package scan
    // -------------------------------------------------------------------------
    private fun scanPackages() {
        val pm = context.packageManager
        @Suppress("DEPRECATION")
        val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)

        for (pkg in packages) {
            if (pkg.packageName == context.packageName) continue
            val name = pkg.packageName.lowercase()
            for (kw in CheatSignatures.CHEAT_PACKAGE_KEYWORDS) {
                if (name.contains(kw)) {
                    add("Package mencurigakan", "${pkg.packageName} (keyword: $kw)", Severity.HIGH)
                }
            }
            for (kw in CheatSignatures.AMBIGUOUS_PACKAGE_KEYWORDS) {
                if (name.contains(kw) && CheatSignatures.CHEAT_PACKAGE_KEYWORDS.none { name.contains(it) }) {
                    add("Package perlu diperiksa", "${pkg.packageName} (keyword: $kw, bisa aplikasi sah)", Severity.LOW)
                }
            }
            if (CheatSignatures.ROOT_MANAGER_PACKAGES.contains(name)) {
                add("Aplikasi manajer root terpasang", pkg.packageName, Severity.LOW)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 2. Filesystem residual
    // -------------------------------------------------------------------------
    private fun scanFilesystem() {
        val paths = listOf("/data/local/tmp", "/sbin", "/system/xbin", "/system/bin")
        val rootHits = mutableListOf<String>()
        val hookHits = mutableListOf<String>()

        for (base in paths) {
            val dir = File(base)
            if (!dir.exists() || !dir.canRead()) continue
            dir.walkTopDown().maxDepth(3).forEach { f ->
                val n = f.name.lowercase()
                if (n.contains("inject") || n.contains("hook") || n.contains("frida")) {
                    hookHits += f.absolutePath
                } else if (n.contains("magisk") || n.contains("kernelsu") || n == "ksud" ||
                    n.contains("zygisk") || n.contains("riru") || n.contains("supersu") || n.contains("daemonsu")
                ) {
                    rootHits += f.absolutePath
                }
            }
        }
        hookHits.take(10).forEach { add("Binary residual", it, Severity.HIGH) }
        if (rootHits.isNotEmpty()) {
            add("Binary root terlihat", rootHits.take(5).joinToString("\n"), Severity.LOW)
        }

        // /data/adb: hanya terbaca lewat root
        if (rootGranted) {
            val top = suCmd("ls -1 /data/adb 2>/dev/null")?.lines()?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
            if (top.isNotEmpty()) {
                add("Direktori root manager (/data/adb)", top.joinToString(", "), Severity.LOW)
            }
            val modules = suCmd("ls -1 /data/adb/modules 2>/dev/null")?.lines()?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
            for (m in modules) {
                val ml = m.lowercase()
                if (CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { ml.contains(it) } ||
                    CheatSignatures.RESIDUAL_TOKENS.any { ml.contains(it) }
                ) {
                    add("Modul root mencurigakan", "/data/adb/modules/$m", Severity.HIGH)
                } else if (ml.contains("zygisk") || ml.contains("lsposed") || ml.contains("riru") || ml.contains("xposed")) {
                    add("Modul injeksi aktif", "/data/adb/modules/$m", Severity.MEDIUM)
                }
            }
            if (modules.isNotEmpty()) {
                add("Daftar modul root", modules.joinToString(", "), Severity.INFO)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 3. /proc maps + memory indicators
    // -------------------------------------------------------------------------
    private fun scanProcMapsAndMemory() {
        val ffPids = linkedSetOf<Int>()

        File("/proc").listFiles()?.forEach { dir ->
            val pid = dir.name.toIntOrNull() ?: return@forEach
            val cmdline = readFile(File(dir, "cmdline"))?.replace('\u0000', ' ') ?: return@forEach
            if (CheatSignatures.FF_PACKAGES.any { cmdline.contains(it) }) ffPids += pid
        }
        if (rootGranted) {
            for (pkg in CheatSignatures.FF_PACKAGES) {
                suCmd("pidof $pkg 2>/dev/null")?.trim()?.split(Regex("\\s+"))
                    ?.mapNotNull { it.toIntOrNull() }?.forEach { ffPids += it }
            }
        }

        if (ffPids.isEmpty()) {
            add(
                if (rootGranted) "Free Fire tidak sedang berjalan" else "Memori game tidak dapat diverifikasi",
                if (rootGranted) "Jalankan Free Fire lalu scan lagi agar memori diperiksa."
                else "Tanpa root Android menyembunyikan proses & memori aplikasi lain. Bukan indikasi cheat.",
                Severity.INFO
            )
            return
        }

        for (pid in ffPids) {
            val status = readPriv("/proc/$pid/status")
            val tracer = status?.lines()?.find { it.startsWith("TracerPid:") }
                ?.substringAfter(":")?.trim()?.toIntOrNull() ?: 0
            if (tracer > 0) {
                add("Proses di-trace", "PID $pid TracerPid=$tracer (indikasi memory attach)", Severity.HIGH)
            }

            val maps = readPriv("/proc/$pid/maps")
            if (maps.isNullOrBlank()) {
                add("Maps PID $pid tidak terbaca", "Tidak dapat diverifikasi.", Severity.INFO)
                continue
            }
            val hit = linkedSetOf<String>()
            var anon = 0
            for (line in maps.lineSequence()) {
                val parts = line.trim().split(Regex("\\s+"), limit = 6)
                if (parts.size < 2) continue
                val path = parts.getOrNull(5)?.trim().orEmpty()
                if (path.isNotEmpty()) {
                    for (sig in CheatSignatures.MAPS_STRINGS) {
                        if (mapsPathMatches(path, sig)) hit += "$sig -> $path"
                    }
                }
                // anon executable besar (pure memory inject); region ART/JIT tidak dihitung
                if (parts[1].startsWith("r-x") && path.startsWith("[anon:") &&
                    !path.contains("dalvik") && !path.contains("jit")
                ) {
                    val range = parts[0].split("-")
                    if (range.size == 2) {
                        val start = range[0].toLongOrNull(16) ?: 0L
                        val end = range[1].toLongOrNull(16) ?: 0L
                        if (end - start > 0x100000) anon++
                    }
                }
            }
            hit.take(10).forEach { add("String hook di maps", "PID $pid: $it", Severity.HIGH) }
            if (anon > 0) add("Anon executable besar", "PID $pid: $anon region > 1 MB", Severity.MEDIUM)
        }
    }

    private fun mapsPathMatches(path: String, sig: String): Boolean {
        val name = path.substringAfterLast('/').lowercase()
        val s = sig.lowercase()
        return if (s.length <= 3) name.split(Regex("[^a-z0-9]+")).any { it == s } else name.contains(s)
    }

    // -------------------------------------------------------------------------
    // 4. Network / VPN / local ports
    // -------------------------------------------------------------------------
    private fun scanNetworkAndVpn() {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var vpn = false
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) vpn = true
        }
        if (vpn) add("VPN aktif", "Ada interface VPN. VPN umum dipakai sah, hanya informasi.", Severity.LOW)

        val netstat = if (rootGranted) suCmd("ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null") ?: ""
        else runCmd("ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null")
        if (netstat.isBlank()) return
        fun listening(port: Int) = Regex(":$port(\\s|$)", RegexOption.MULTILINE).containsMatchIn(netstat)
        for (p in CheatSignatures.HIGH_PORTS) if (listening(p)) add("Port Frida listen", "Port $p (frida-server)", Severity.HIGH)
        for (p in CheatSignatures.MEDIUM_PORTS) if (listening(p)) add("Port mencurigakan", "Port $p sedang listen", Severity.MEDIUM)
        for (p in CheatSignatures.LOW_PORTS) if (listening(p)) add("Port umum developer", "Port $p sedang listen", Severity.LOW)
    }

    // -------------------------------------------------------------------------
    // 5. Virtual space / multi-user
    // -------------------------------------------------------------------------
    private fun scanVirtualSpaces() {
        // Apakah scanner ini sendiri berjalan di dalam container?
        val own = context.filesDir.absolutePath
        val expected = Regex("^/data/(data|user/\\d+)/${Regex.escape(context.packageName)}/files$")
        if (!expected.matches(own)) {
            val sev = if (own.contains("virtual", true) || !own.startsWith("/data/")) Severity.HIGH else Severity.MEDIUM
            add("Scanner berjalan di dalam container", "Path data: $own (bukan path normal Android)", sev)
        }

        val users = runCmd("pm list users 2>/dev/null")
        if (users.lines().count { it.contains("UserInfo{") } > 1) {
            add("Multi-user terdeteksi", "Ada profil pengguna tambahan (work profile/secure folder/virtual space).", Severity.LOW)
        }

        val pm = context.packageManager
        for (c in CheatSignatures.CONTAINER_PACKAGES_HIGH + CheatSignatures.CONTAINER_PACKAGES_MEDIUM) {
            try {
                pm.getPackageInfo(c, 0)
                val sev = if (c in CheatSignatures.CONTAINER_PACKAGES_HIGH) Severity.HIGH else Severity.MEDIUM
                add("Virtual space terpasang", c, sev)
            } catch (e: Exception) {
            }
        }
    }

    // -------------------------------------------------------------------------
    // 6. Kernel / root residual
    // -------------------------------------------------------------------------
    private fun scanKernelResiduals() {
        // properti (bisa dibaca tanpa root)
        val boot = runCmd("getprop ro.boot.verifiedbootstate").trim()
        if (boot.isNotEmpty() && boot != "green") {
            add("Boot state tidak green", "ro.boot.verifiedbootstate = $boot (bootloader unlocked/modifikasi)", Severity.LOW)
        }
        if (runCmd("getprop ro.debuggable").trim() == "1") {
            add("ro.debuggable=1", "Device dalam mode debug", Severity.LOW)
        }
        if (runCmd("getprop ro.secure").trim() == "0") {
            add("ro.secure=0", "Build non-secure (adb root)", Severity.LOW)
        }

        // jejak root yang bisa dilihat TANPA root: mount dan library di proses scanner sendiri
        val mounts = readFile(File("/proc/self/mountinfo"))
        if (mounts != null) {
            val m = mounts.lineSequence().filter {
                val l = it.lowercase()
                l.contains("magisk") || l.contains("/data/adb/modules") || l.contains("kernelsu") || l.contains(" ksu ") || l.contains("apatch")
            }.take(3).toList()
            if (m.isNotEmpty()) add("Mount jejak root", m.joinToString("\n") { it.take(120) }, Severity.MEDIUM)
        }
        val selfMaps = readFile(File("/proc/self/maps"))
        if (selfMaps != null) {
            val tokens = listOf("zygisk", "riru", "lsposed", "xposed", "frida", "substrate")
            val found = tokens.filter { t ->
                selfMaps.lineSequence().any { line ->
                    val p = line.trim().split(Regex("\\s+"), limit = 6).getOrNull(5).orEmpty()
                    p.isNotEmpty() && p.substringAfterLast('/').lowercase().contains(t)
                }
            }
            if (found.isNotEmpty()) {
                add("Library injeksi masuk ke proses scanner", found.joinToString(", "), Severity.MEDIUM)
            }
        }

        // kallsyms: kernel modern memblokir non-root -> tidak dapat diverifikasi
        var kall = readFile(File("/proc/kallsyms"))
        if (kall.isNullOrBlank() && rootGranted) kall = suCmd("cat /proc/kallsyms 2>/dev/null")
        if (kall.isNullOrBlank()) {
            add("kallsyms tidak dapat diverifikasi", "Kernel memblokir pembacaan simbol. Bukan indikasi cheat.", Severity.INFO)
            return
        }
        val hit = linkedSetOf<String>()
        for (line in kall.lineSequence()) {
            val parts = line.split(' ')
            if (parts.size < 3) continue
            val sym = parts[2].lowercase()
            for (ind in CheatSignatures.ROOT_INDICATORS) {
                val match = if (ind == "ksu") Regex("(^|_)ksu(_|$)").containsMatchIn(sym) else sym.contains(ind)
                if (match) hit += ind
            }
            if (hit.size == CheatSignatures.ROOT_INDICATORS.size) break
        }
        hit.forEach { add("Symbol kernel", "kallsyms mengandung simbol \"$it\"", Severity.MEDIUM) }
    }

    // -------------------------------------------------------------------------
    // 7. Accessibility (script / auto aim)
    // -------------------------------------------------------------------------
    private fun scanAccessibility() {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? android.view.accessibility.AccessibilityManager
            ?: return
        val enabled = am.getEnabledAccessibilityServiceList(
            android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        for (svc in enabled) {
            val si = svc.resolveInfo.serviceInfo
            val pkg = si.packageName.lowercase()
            if (si.applicationInfo != null && si.applicationInfo!!.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            if (CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { pkg.contains(it) }) {
                add("Accessibility mencurigakan", pkg, Severity.HIGH)
            } else if (pkg.contains("autoclick") || pkg.contains("clicker") || pkg.contains("macro")) {
                add("Accessibility auto-click/macro", pkg, Severity.MEDIUM)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 8. Shizuku / wireless ADB
    // -------------------------------------------------------------------------
    private fun scanShizukuAndAdb() {
        val processes = runCmd("ps -A 2>/dev/null || ps 2>/dev/null")
        if (processes.contains("shizuku_server") || processes.contains("shizuku")) {
            add("Shizuku aktif", "shizuku_server berjalan (bisa dipakai inject)", Severity.HIGH)
        }
        if (File("/data/local/tmp/shizuku_starter").exists() || File("/data/local/tmp/shizuku").exists()) {
            add("Shizuku residual file", "/data/local/tmp/shizuku*", Severity.MEDIUM)
        }

        val adb = runCmd("getprop service.adb.tcp.port").trim()
        if (adb.isNotEmpty() && adb != "-1" && adb != "0") {
            add("ADB TCP aktif", "service.adb.tcp.port = $adb", Severity.MEDIUM)
        }
        try {
            val cr = context.contentResolver
            if (Settings.Global.getInt(cr, "adb_wifi_enabled", 0) == 1) {
                add("Wireless debugging aktif", "Pengaturan Debugging nirkabel menyala.", Severity.MEDIUM)
            }
            if (Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1) {
                add("USB debugging aktif", "Developer options menyala. Umum dipakai sah, hanya informasi.", Severity.LOW)
            }
        } catch (e: Exception) {
        }
    }

    // -------------------------------------------------------------------------
    // 9. Data Free Fire (root, atau Android <= 10)
    // -------------------------------------------------------------------------
    private fun scanFreeFireResiduals() {
        val installed = CheatSignatures.FF_PACKAGES.filter { isInstalled(it) }
        if (installed.isEmpty()) return

        for (pkg in installed) {
            val dirs = listOf("/data/data/$pkg", "/sdcard/Android/data/$pkg", "/sdcard/Android/obb/$pkg")
            val files: List<String>? = if (rootGranted) {
                val q = dirs.joinToString(" ") { "'$it'" }
                suCmd("find $q -type f 2>/dev/null | head -n 20000", 60_000L)?.lines()?.filter { it.isNotBlank() }
            } else {
                val base = File("/sdcard/Android/data/$pkg")
                if (base.isDirectory && base.listFiles() != null)
                    base.walkTopDown().filter { it.isFile }.take(20000).map { it.absolutePath }.toList()
                else null
            }

            if (files == null) {
                add(
                    "Data $pkg tidak dapat diverifikasi",
                    "Android 11+ memblokir /data/data dan Android/data tanpa root. Bukan indikasi cheat.",
                    Severity.INFO
                )
                continue
            }

            var minor = 0
            var hits = 0
            for (path in files) {
                val n = path.substringAfterLast('/').lowercase()
                if (CheatSignatures.RESIDUAL_TOKENS.any { n.contains(it) }) {
                    hits++
                    if (hits <= 10) add("Residual di data FF", path, Severity.HIGH)
                } else if (n.endsWith(".bak") || n.endsWith(".old") || n.endsWith(".tmp")) {
                    minor++
                }
            }
            if (minor > 0) add("File sementara/cadangan di data FF", "$pkg: $minor file .bak/.old/.tmp (umum, hanya informasi)", Severity.LOW)
            add("Data $pkg diperiksa", "${files.size} file", Severity.INFO)
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private fun add(title: String, detail: String, sev: Severity) {
        findings += Finding(title, detail, sev)
    }

    private fun step(name: String, block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            add("Modul $name gagal", e.message ?: e.javaClass.simpleName, Severity.INFO)
        }
    }

    private fun toFinding(i: IntegrityScanner.Item): Finding = Finding(
        i.title, i.detail,
        when (i.level) {
            IntegrityScanner.Level.CRITICAL -> Severity.HIGH
            IntegrityScanner.Level.WARN -> Severity.MEDIUM
            IntegrityScanner.Level.LOW -> Severity.LOW
            IntegrityScanner.Level.INFO -> Severity.INFO
        }
    )

    private fun isInstalled(pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun checkRoot(): Boolean {
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/data/local/su", "/data/local/bin/su"
        )
        if (paths.any { File(it).exists() }) return true
        if (CheatSignatures.ROOT_MANAGER_PACKAGES.any { isInstalled(it) }) return true
        return runCmd("which su 2>/dev/null").isNotBlank()
    }

    private fun readFile(f: File): String? {
        return try {
            if (f.exists() && f.canRead()) f.readText() else null
        } catch (e: Exception) {
            null
        }
    }

    /** Baca file; bila tidak bisa dan root diberikan, baca lewat su. */
    private fun readPriv(path: String): String? {
        val direct = readFile(File(path))
        if (!direct.isNullOrBlank()) return direct
        return if (rootGranted) suCmd("cat '$path' 2>/dev/null") else null
    }

    private fun runCmd(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out = BufferedReader(InputStreamReader(p.inputStream)).readText()
            p.waitFor()
            out
        } catch (e: Exception) {
            ""
        }
    }

    /** Jalankan perintah sebagai root (memunculkan dialog izin Magisk/KernelSU/APatch pada pemakaian pertama). */
    private fun suCmd(cmd: String, timeoutMs: Long = 25_000L): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val dog = Thread {
            try { Thread.sleep(timeoutMs) } catch (e: InterruptedException) { return@Thread }
            p.destroy()
        }
        dog.isDaemon = true
        dog.start()
        val text = try { p.inputStream.bufferedReader().readText() } catch (e: Exception) { "" }
        val code = try { p.waitFor() } catch (e: InterruptedException) { -1 }
        dog.interrupt()
        if (code != 0 && text.isBlank()) null else text
    } catch (e: Exception) {
        null
    }

    data class ScanResult(
        val isCheat: Boolean,
        val findings: List<Finding>,
        val rooted: Boolean,
        val timestamp: String,
        val rootGranted: Boolean = false
    )
}
