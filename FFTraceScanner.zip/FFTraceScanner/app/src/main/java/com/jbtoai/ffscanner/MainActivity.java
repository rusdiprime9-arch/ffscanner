package com.jbtoai.ffscanner;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * FF Maximal Trace Scanner
 * Root = INFO only (bukan cheat)
 * Hanya alat cheat sungguhan yang masuk peringatan
 * Soft warning: teks saja, tanpa suara / popup
 */
public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private Button btnScan;
    private final StringBuilder log = new StringBuilder();
    private boolean hasRoot = false;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicInteger threatCount = new AtomicInteger(0);
    private final Map<String, List<String>> threatsByType = new LinkedHashMap<>();

    // Hanya paket yang benar-benar alat cheat / injector / memory editor
    private static final String[] CHEAT_ONLY_PKGS = {
            "com.gameguardian",
            "com.luckypatcher",
            "bin.mt.plus",
            "com.dts.freefireth.mod",
            "com.dts.freefiremax.mod"
    };

    // Path yang jelas cheat / injector (bukan root manager)
    private static final String[] CHEAT_PATHS = {
            "/data/local/tmp/frida-server",
            "/data/local/tmp/re.frida.server",
            "/data/local/tmp/fs",
            "/data/local/tmp/gg"
    };

    // Path root — hanya INFO, tidak di-flag sebagai cheat
    private static final String[] ROOT_INFO_PATHS = {
            "/data/adb/magisk", "/data/adb/modules", "/data/adb/ksu", "/data/adb/ap",
            "/sbin/.magisk", "/dev/.magisk",
            "/system/xbin/su", "/system/bin/su", "/sbin/su",
            "/data/local/su", "/system/app/Superuser.apk",
            "/system/etc/init/magisk"
    };

    private static final String[] FF_PKGS = {
            "com.dts.freefireth", "com.dts.freefiremax"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tvResult = findViewById(R.id.tvResult);
        btnScan = findViewById(R.id.btnScan);
        btnScan.setOnClickListener(v -> startScan());
    }

    private void startScan() {
        btnScan.setEnabled(false);
        log.setLength(0);
        threatCount.set(0);
        threatsByType.clear();
        append("=== FF Maximal Trace Scanner ===\n");
        append("Catatan: Root / Magisk / KernelSU = INFO saja, BUKAN cheat.\n");
        executor.execute(() -> {
            try {
                checkRoot();
                scanPackages();
                scanFilesystem();
                scanProcMapsMounts();
                scanKernelSelinuxProp();
                scanFfApkIntegrity();
                scanProcesses();
                scanHiddenBinaries();
                append("\n=== SCAN COMPLETE ===\n");

                if (threatCount.get() > 0) {
                    StringBuilder warn = new StringBuilder();
                    warn.append("\n");
                    warn.append("========================================\n");
                    warn.append("  PERINGATAN: JEJAK CHEAT TERDETEKSI\n");
                    warn.append("========================================\n");
                    warn.append("Total: ").append(threatCount.get()).append(" temuan\n");
                    warn.append("(Root tidak dihitung sebagai cheat)\n\n");
                    warn.append("Jenis yang kemungkinan dipakai:\n");
                    for (Map.Entry<String, List<String>> e : threatsByType.entrySet()) {
                        warn.append("\n[").append(e.getKey()).append("] (").append(e.getValue().size()).append(")\n");
                        for (String item : e.getValue()) {
                            warn.append("  - ").append(item).append("\n");
                        }
                    }
                    warn.append("\nRisiko: ban akun ACE / device ban\n");
                    warn.append("========================================\n\n");
                    log.insert(0, warn.toString());
                } else {
                    log.insert(0, "\n[OK] Tidak ada jejak cheat terdeteksi.\n"
                            + "(Root / Magisk / KernelSU tidak dihitung sebagai cheat)\n\n");
                }

                append("ACE primary: modified base.apk hash + re-signed cert\n");
                append("Secondary: .text vs disk, extra .so, mount/SELinux side-channel\n");
            } catch (Exception e) {
                append("[ERR] " + e.getMessage() + "\n");
            }
            runOnUiThread(() -> {
                tvResult.setText(log.toString());
                btnScan.setEnabled(true);
            });
        });
    }

    /** Hanya untuk jejak cheat sungguhan */
    private void flagThreat(String type, String detail) {
        threatCount.incrementAndGet();
        if (!threatsByType.containsKey(type)) {
            threatsByType.put(type, new ArrayList<>());
        }
        threatsByType.get(type).add(detail);
        append("[!] [" + type + "] " + detail + "\n");
    }

    /** Root / info — tidak masuk hitungan ancaman */
    private void infoOnly(String msg) {
        append("[i] " + msg + "\n");
    }

    private void append(String s) {
        log.append(s);
        runOnUiThread(() -> tvResult.setText(log.toString()));
    }

    // ========== 1. ROOT CHECK (INFO ONLY) ==========
    private void checkRoot() {
        append("\n--- ROOT STATUS (info, bukan cheat) ---\n");
        hasRoot = false;
        String[] suPaths = {"/system/xbin/su", "/system/bin/su", "/sbin/su", "/data/local/su"};
        for (String p : suPaths) {
            if (new File(p).exists()) {
                hasRoot = true;
                infoOnly("su binary: " + p);
            }
        }
        String out = exec("su -c id");
        if (out != null && out.contains("uid=0")) {
            hasRoot = true;
            infoOnly("su -c id → " + out.trim());
        }
        if (hasRoot) append("[+] Root mode — deep scan aktif (root tetap bukan cheat)\n");
        else append("[-] Non-root mode — scan terbatas namespace app\n");
    }

    // ========== 2. PACKAGE SCAN ==========
    private void scanPackages() {
        append("\n--- 1. PACKAGE SCAN ---\n");
        PackageManager pm = getPackageManager();
        List<PackageInfo> pkgs;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                pkgs = pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0));
            } else {
                pkgs = pm.getInstalledPackages(0);
            }
        } catch (Exception e) {
            append("[!] Package list restricted: " + e.getMessage() + "\n");
            return;
        }
        for (PackageInfo pi : pkgs) {
            String pkg = pi.packageName;
            String lower = pkg.toLowerCase();

            // Root managers → INFO saja
            if (lower.contains("magisk") || lower.contains("kernelsu") || lower.contains("apatch")
                    || pkg.contains("com.topjohnwu.magisk") || pkg.contains("io.github.huskydg.magisk")
                    || pkg.contains("me.weishu.kernelsu") || pkg.contains("me.bmax.apatch")) {
                infoOnly("ROOT_MANAGER (bukan cheat): " + pkg);
                continue;
            }

            // Hook framework bisa dipakai cheat → flag
            if (lower.contains("lsposed") || lower.contains("xposed") || lower.contains("edxposed")
                    || pkg.contains("org.lsposed.manager")) {
                flagThreat("HOOK_FRAMEWORK", pkg);
                continue;
            }

            // Memory editor → cheat
            if (lower.contains("gameguardian") || pkg.contains("com.gameguardian")
                    || lower.contains("luckypatcher") || pkg.contains("com.luckypatcher")) {
                flagThreat("MEMORY_EDITOR", pkg);
                continue;
            }

            // Mod menu / headshot APK → cheat
            if (lower.matches(".*(modmenu|headshot|aimbot|wallhack|esp|autoaim|freefire.*mod|ff.*hack|garena.*mod).*")
                    || pkg.contains("com.dts.freefireth.mod") || pkg.contains("com.dts.freefiremax.mod")) {
                flagThreat("MOD_MENU_APK", pkg);
                continue;
            }

            // daftar cheat-only lain
            for (String c : CHEAT_ONLY_PKGS) {
                if (pkg.contains(c)) {
                    flagThreat("SUSPICIOUS_PKG", pkg);
                    break;
                }
            }
        }
        append("[*] Total packages scanned: " + pkgs.size() + "\n");
    }

    // ========== 3. FILESYSTEM ==========
    private void scanFilesystem() {
        append("\n--- 2. FILESYSTEM TRACE ---\n");

        // Root paths → info only
        for (String p : ROOT_INFO_PATHS) {
            boolean exists;
            if (hasRoot) {
                String r = exec("su -c \"[ -e '" + p + "' ] && echo YES || echo NO\"");
                exists = r != null && r.contains("YES");
            } else {
                exists = new File(p).exists();
            }
            if (exists) {
                infoOnly("ROOT_TRACE (bukan cheat): " + p);
            }
        }

        // Cheat paths → flag
        for (String p : CHEAT_PATHS) {
            boolean exists;
            if (hasRoot) {
                String r = exec("su -c \"[ -e '" + p + "' ] && echo YES || echo NO\"");
                exists = r != null && r.contains("YES");
            } else {
                exists = new File(p).exists();
            }
            if (exists) {
                String type = p.contains("frida") || p.contains("re.frida") ? "FRIDA_INJECTOR" : "MEMORY_EDITOR";
                flagThreat(type, "path: " + p);
            }
        }

        if (hasRoot) {
            append("\n[*] Deep find (hanya file cheat / injector)...\n");
            // Frida / GG / Dobby / injector — flag
            String deepCheat = exec("su -c \"find /data/adb /data/local/tmp /data/misc -type f \\( -name '*frida*' -o -name '*dobby*' -o -name '*substrate*' -o -name '*gg*' -o -name '*gameguardian*' -o -name '*libgadget*' -o -name '*libhook*' \\) 2>/dev/null | head -40\"");
            if (deepCheat != null && !deepCheat.isEmpty()) {
                for (String line : deepCheat.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String l = line.toLowerCase();
                    String type = "HIDDEN_FILE";
                    if (l.contains("frida") || l.contains("libgadget")) type = "FRIDA_INJECTOR";
                    else if (l.contains("dobby") || l.contains("substrate")) type = "HOOK_FRAMEWORK";
                    else if (l.contains("gg") || l.contains("gameguardian")) type = "MEMORY_EDITOR";
                    flagThreat(type, "deep: " + line.trim());
                }
            }

            // Magisk / zygisk / lsposed module dirs → root/hook info
            // LSPosed module yang aktif bisa cheat → flag LSPosed saja
            String mods = exec("su -c \"find /data/adb/modules -type d 2>/dev/null\"");
            if (mods != null && !mods.isEmpty()) {
                for (String m : mods.split("\n")) {
                    String t = m.trim();
                    if (t.isEmpty() || t.endsWith("/modules")) continue;
                    String lower = t.toLowerCase();
                    if (lower.contains("lsposed") || lower.contains("xposed") || lower.contains("edxposed")) {
                        flagThreat("HOOK_FRAMEWORK", "module: " + t);
                    } else if (lower.contains("frida") || lower.contains("dobby") || lower.contains("hide") && lower.contains("cheat")) {
                        flagThreat("HOOK_FRAMEWORK", "module: " + t);
                    } else {
                        // module biasa / shamiko / zygisk → info
                        infoOnly("MODULE (bukan cheat otomatis): " + t);
                    }
                }
            }
        }
    }

    // ========== 4. /proc MAPS + MOUNTS ==========
    private void scanProcMapsMounts() {
        append("\n--- 3. /proc MAPS + MOUNT ---\n");
        if (hasRoot) {
            append("[*] /proc/*/maps (hanya injector / hook)...\n");
            // Jangan flag magisk/zygisk murni — hanya frida/dobby/gadget/hook
            String maps = exec("su -c \"grep -rE 'frida|dobby|lsposed|xposed|substrate|libgadget|libhook|libinject|gameguardian' /proc/*/maps 2>/dev/null | head -30\"");
            if (maps != null && !maps.isEmpty()) {
                for (String line : maps.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String l = line.toLowerCase();
                    // skip pure magisk/zygisk lines if any slipped
                    if (l.contains("magisk") && !l.contains("frida") && !l.contains("dobby") && !l.contains("gadget")) {
                        infoOnly("maps root (bukan cheat): " + line.trim());
                        continue;
                    }
                    String type = "INJECTION_MAPS";
                    if (l.contains("frida") || l.contains("libgadget")) type = "FRIDA_INJECTOR";
                    else if (l.contains("dobby") || l.contains("lsposed") || l.contains("xposed") || l.contains("substrate")) type = "HOOK_FRAMEWORK";
                    else if (l.contains("gameguardian")) type = "MEMORY_EDITOR";
                    flagThreat(type, "maps: " + line.trim());
                }
            } else append("[-] no cheat injection strings in maps\n");

            // Mount magisk/zygisk → info only (hide root, bukan cheat)
            append("\n[*] Mount namespace (root hide = info)...\n");
            String m1 = exec("su -c \"cat /proc/1/mountinfo 2>/dev/null | grep -E 'magisk|zygisk|overlay|tmpfs.*adb' | head -10\"");
            if (m1 != null && !m1.isEmpty()) {
                for (String line : m1.split("\n")) {
                    if (!line.trim().isEmpty()) infoOnly("MOUNT (root hide, bukan cheat): " + line.trim());
                }
            }

            append("\n[*] Process artifacts...\n");
            String tmp = exec("su -c \"ls -la /data/local/tmp 2>/dev/null | grep -E 'frida|re\\.|gg|gameguardian'\"");
            if (tmp != null && !tmp.isEmpty()) {
                for (String line : tmp.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String type = line.toLowerCase().contains("frida") ? "FRIDA_INJECTOR" : "MEMORY_EDITOR";
                    flagThreat(type, "tmp: " + line.trim());
                }
            }
            // Process: flag hanya cheat, magiskd/zygisk = info
            String ps = exec("su -c \"ps -A 2>/dev/null | grep -iE 'frida|gg|gameguardian|lsposed|magiskd|zygisk|dobby'\"");
            if (ps != null && !ps.isEmpty()) {
                for (String line : ps.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String l = line.toLowerCase();
                    if (l.contains("magisk") || l.contains("zygisk") || l.contains("magiskd")) {
                        infoOnly("PROC root (bukan cheat): " + line.trim());
                    } else if (l.contains("frida")) {
                        flagThreat("FRIDA_INJECTOR", "proc: " + line.trim());
                    } else if (l.contains("gg") || l.contains("gameguardian")) {
                        flagThreat("MEMORY_EDITOR", "proc: " + line.trim());
                    } else if (l.contains("lsposed") || l.contains("dobby")) {
                        flagThreat("HOOK_FRAMEWORK", "proc: " + line.trim());
                    }
                }
            }
        } else {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/self/maps")));
                String line;
                boolean hit = false;
                while ((line = br.readLine()) != null) {
                    String l = line.toLowerCase();
                    if (l.contains("frida") || l.contains("dobby") || l.contains("libgadget")
                            || l.contains("lsposed") || l.contains("gameguardian")) {
                        String type = l.contains("frida") || l.contains("gadget") ? "FRIDA_INJECTOR"
                                : l.contains("gameguardian") ? "MEMORY_EDITOR" : "HOOK_FRAMEWORK";
                        flagThreat(type, "self maps: " + line);
                        hit = true;
                    }
                }
                br.close();
                if (!hit) append("[-] no cheat injection in self maps\n");
            } catch (Exception e) {
                append("[!] maps read fail: " + e.getMessage() + "\n");
            }
        }
    }

    // ========== 5. KERNEL / SELINUX / PROP ==========
    private void scanKernelSelinuxProp() {
        append("\n--- 4. KERNEL / SELINUX / PROP (root status = info) ---\n");
        append("Kernel: " + System.getProperty("os.version") + "\n");
        String ver = readFile("/proc/version");
        if (ver != null) append(ver.trim() + "\n");

        String[] props = {
                "ro.build.tags", "ro.boot.verifiedbootstate",
                "ro.boot.flash.locked", "ro.boot.vbmeta.device_state",
                "ro.secure", "ro.debuggable"
        };
        for (String p : props) {
            String v = getProp(p);
            append(p + " = " + (v != null ? v : "?") + "\n");
            // unlocked boot / test-keys / debuggable → INFO saja (bisa root, bukan cheat)
            if ("ro.build.tags".equals(p) && v != null && v.contains("test-keys")) {
                infoOnly("PROP test-keys (bukan cheat)");
            }
            if ("ro.debuggable".equals(p) && "1".equals(v)) {
                infoOnly("PROP ro.debuggable=1 (bukan cheat)");
            }
            if ("ro.boot.verifiedbootstate".equals(p) && v != null && !v.contains("green")) {
                infoOnly("PROP verifiedbootstate=" + v + " (bukan cheat)");
            }
        }

        if (hasRoot) {
            append("\n[*] Kernel modules...\n");
            String lsmod = exec("su -c \"lsmod 2>/dev/null | grep -iE 'magisk|ksu|apatch|zygisk|hide|hideproc|syscall|hook|dobby|frida'\"");
            if (lsmod != null && !lsmod.isEmpty()) {
                for (String line : lsmod.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String l = line.toLowerCase();
                    if (l.contains("frida") || l.contains("dobby") || l.contains("hook") && !l.contains("magisk")) {
                        flagThreat("KERNEL_MODULE", line.trim());
                    } else {
                        infoOnly("KERNEL (root, bukan cheat): " + line.trim());
                    }
                }
            } else append("[-] none matched\n");

            append("\n[*] SELinux context...\n");
            String se = exec("su -c \"ps -AZ 2>/dev/null | grep -E 'magisk|zygisk|ksu|apatch|su|frida|lsposed' | head -15\"");
            if (se != null && !se.isEmpty()) {
                for (String line : se.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String l = line.toLowerCase();
                    if (l.contains("frida") || l.contains("lsposed")) {
                        flagThreat("SELINUX_CTX", line.trim());
                    } else {
                        infoOnly("SELINUX root (bukan cheat): " + line.trim());
                    }
                }
            }
        }
    }

    // ========== 6. FF APK INTEGRITY ==========
    private void scanFfApkIntegrity() {
        append("\n--- 5. FREE FIRE APK INTEGRITY (ACE primary) ---\n");
        PackageManager pm = getPackageManager();
        for (String pkg : FF_PKGS) {
            try {
                ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
                String apkPath = ai.sourceDir;
                append("Found " + pkg + " → " + apkPath + "\n");
                File f = new File(apkPath);
                if (f.exists()) {
                    append("Size: " + f.length() + " bytes\n");
                    String md5 = md5File(f);
                    if (md5 != null) append("MD5: " + md5 + "\n");
                    PackageInfo pi = pm.getPackageInfo(pkg, 0);
                    append("versionCode=" + pi.versionCode + " versionName=" + pi.versionName + "\n");
                }
                if (hasRoot) {
                    String ls = exec("su -c \"ls -la /data/app/*" + pkg + "* 2>/dev/null\"");
                    if (ls != null && !ls.isEmpty()) append(ls + "\n");
                }
            } catch (PackageManager.NameNotFoundException e) {
                append("[-] " + pkg + " not installed\n");
            } catch (Exception e) {
                append("[!] " + pkg + " error: " + e.getMessage() + "\n");
            }
        }
    }

    // ========== 7. PROCESS ==========
    private void scanProcesses() {
        append("\n--- 6. PROCESS TRACE ---\n");
        if (hasRoot) {
            String ps = exec("su -c \"ps -A -o PID,USER,NAME,ARGS 2>/dev/null | grep -iE 'frida|gg|gameguardian|cheat|hack|modmenu|injector|dobby|lsposed|xposed|riru|substrate'\"");
            if (ps != null && !ps.isEmpty()) {
                for (String line : ps.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String l = line.toLowerCase();
                    // skip pure root daemons
                    if ((l.contains("magisk") || l.contains("zygisk")) && !l.contains("frida") && !l.contains("dobby")) {
                        infoOnly("PROC root: " + line.trim());
                        continue;
                    }
                    String type = "SUSPICIOUS_PROCESS";
                    if (l.contains("frida")) type = "FRIDA_INJECTOR";
                    else if (l.contains("gg") || l.contains("gameguardian")) type = "MEMORY_EDITOR";
                    else if (l.contains("dobby") || l.contains("lsposed") || l.contains("xposed") || l.contains("riru") || l.contains("substrate")) type = "HOOK_FRAMEWORK";
                    else if (l.contains("modmenu") || l.contains("cheat") || l.contains("hack") || l.contains("injector")) type = "MOD_MENU_APK";
                    flagThreat(type, "proc: " + line.trim());
                }
            } else append("[-] no matching cheat processes\n");
        } else {
            append("[-] process deep scan requires root\n");
        }
    }

    // ========== 8. HIDDEN BINARY ==========
    private void scanHiddenBinaries() {
        append("\n--- 7. HIDDEN / RENAMED BINARY (cheat only) ---\n");
        if (hasRoot) {
            append("[*] Scan ELF untuk string cheat / injector...\n");
            String cmd = "su -c \"find /data/local/tmp /data/adb /dev /system/xbin /sbin -type f -executable 2>/dev/null | while read f; do " +
                    "strings \\\"$f\\\" 2>/dev/null | grep -qiE 'frida|libdobby|LSPosed|GameGuardian|libgadget|libhook' && echo \\\"$f\\\"; " +
                    "done | head -20\"";
            String hit = exec(cmd);
            if (hit != null && !hit.isEmpty()) {
                for (String line : hit.split("\n")) {
                    if (line.trim().isEmpty()) continue;
                    String l = line.toLowerCase();
                    // skip pure magisk binaries
                    if (l.contains("magisk") && !l.contains("frida") && !l.contains("dobby") && !l.contains("gadget")) {
                        infoOnly("ELF root (bukan cheat): " + line.trim());
                        continue;
                    }
                    String type = "HIDDEN_BINARY";
                    if (l.contains("frida") || l.contains("gadget")) type = "FRIDA_INJECTOR";
                    else if (l.contains("dobby") || l.contains("lsposed")) type = "HOOK_FRAMEWORK";
                    else if (l.contains("gameguardian") || l.contains("gg")) type = "MEMORY_EDITOR";
                    flagThreat(type, "elf: " + line.trim());
                }
            } else append("[-] no cheat string hits\n");
        } else {
            append("[-] hidden binary scan requires root\n");
        }
    }

    // ========== HELPERS ==========
    private String exec(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
            br.close();
            p.waitFor();
            return sb.toString().trim();
        } catch (Exception e) {
            return null;
        }
    }

    private String getProp(String key) {
        return exec("getprop " + key);
    }

    private String readFile(String path) {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(path)));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }

    private String md5File(File f) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            FileInputStream fis = new FileInputStream(f);
            byte[] buf = new byte[8192];
            int n;
            while ((n = fis.read(buf)) > 0) md.update(buf, 0, n);
            fis.close();
            byte[] dig = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : dig) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
}
