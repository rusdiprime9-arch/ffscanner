# keep all for scanner
-keep class com.jbtoai.ffscanner.** { *; }
