package com.azx.scanner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.provider.Settings
import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Severity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

/**
 * Prinsip v5:
 *  - Yang TIDAK BISA dibuka tanpa root (/data/adb, /data/data, Android/data, memori game, kallsyms)
 *    dilaporkan sebagai INFO "tidak dapat diverifikasi", BUKAN cheat.
 *  - Dengan root (akses su diberikan) semua itu dibaca lewat su dan dicek penuh.
 *  - Keberadaan root/VPN/boot unlocked saja = LOW (informasi). CHEAT hanya bila ada bukti nyata
 *    (HIGH) atau minimal 3 indikasi MEDIUM.
 */
class ScannerEngine(private val context: Context) {

    private val findings: MutableList<Finding> = Collections.synchronizedList(mutableListOf<Finding>())

    /** Tiap modul menulis ke buffer miliknya sendiri (aman untuk jalan paralel), digabung berurutan setelah selesai. */
    private val sink = ThreadLocal<MutableList<Finding>>()
    private var isRooted = false
    private var rootGranted = false

    /** Diisi MainActivity bila selama app dipakai ada jendela lain (overlay) di atas scanner. */
    var overlayObscuredSeen = false

    suspend fun runFullScan(): ScanResult = withContext(Dispatchers.IO) {
        findings.clear()
        isRooted = checkRoot()
        rootGranted = false
        if (isRooted) {
            rootGranted = suCmd("id", 30_000L)?.contains("uid=0") == true
        }

        when {
            rootGranted -> add("Mode root", "Akses su diberikan: /data/adb, data game, memori game, dan kallsyms dibaca lewat root.", Severity.INFO)
            isRooted -> add(
                "Mode root ditolak",
                "Root terdeteksi tetapi akses su tidak diberikan. Izinkan di Magisk/KernelSU/APatch lalu scan ulang agar pemeriksaan penuh.",
                Severity.INFO
            )
            else -> add(
                "Mode non-root",
                "/data/adb, /data/data, Android/data, memori game, dan kallsyms tidak bisa dibuka tanpa root. Item itu ditandai 'tidak dapat diverifikasi' dan BUKAN dianggap cheat.",
                Severity.INFO
            )
        }

        // Semua modul independen dijalankan PARALEL; hasilnya digabung sesuai urutan semula.
        val steps: List<Pair<String, () -> Unit>> = listOf(
            "Profil perangkat" to { scanEnvironmentProfile() },
            "Package" to { scanPackages() },
            "Filesystem" to { scanFilesystem() },
            "Proc/maps" to { scanProcMapsAndMemory() },
            "Network" to { scanNetworkAndVpn() },
            "Proxy/VPN" to {
                ProxyVpnScanner(context, rootGranted, overlayObscuredSeen) { suCmd(it) }.scan()
                    .forEach { add(it.title, it.detail, it.severity) }
            },
            "Virtual space" to { scanVirtualSpaces() },
            "Kernel" to { scanKernelResiduals() },
            "Daemon root" to { scanRootDaemons() },
            "Accessibility" to { scanAccessibility() },
            "Shizuku/ADB" to { scanShizukuAndAdb() },
            "Data FF" to { scanFreeFireResiduals() },
            "Jejak & riwayat" to {
                TraceHistoryScanner(context, rootGranted) { suCmd(it, 45_000L) }.scan()
                    .forEach { add(it.title, it.detail, it.severity) }
            },
            "Integritas FF" to {
                IntegrityScanner.scan(context, rootGranted).forEach {
                    val f = toFinding(it)
                    add(f.title, f.detail, f.severity)
                }
            }
        )
        val results = steps.map { (name, block) -> async { runStep(name, block) } }.awaitAll()
        results.forEach { r -> synchronized(findings) { findings += r } }

        val snapshot = synchronized(findings) { findings.toList() }
        // Vonis ditentukan di satu tempat (VerdictPolicy) agar aturan anti salah deteksi bisa diuji.
        val verdict = VerdictPolicy.decide(snapshot)

        ScanResult(
            isCheat = verdict == VerdictPolicy.Verdict.CHEAT,
            verdict = verdict,
            findings = snapshot,
            rooted = isRooted,
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()),
            rootGranted = rootGranted
        )
    }

    // -------------------------------------------------------------------------
    // 1. Package scan
    // -------------------------------------------------------------------------
    private fun scanPackages() {
        val pm = context.packageManager
        @Suppress("DEPRECATION")
        val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA or PackageManager.GET_PERMISSIONS)

        val noteSideloadOverlay = mutableListOf<String>()
        for (pkg in packages) {
            if (pkg.packageName == context.packageName) continue
            val name = pkg.packageName.lowercase()
            val kwHit = CheatSignatures.CHEAT_PACKAGE_KEYWORDS.firstOrNull { name.contains(it) }
            if (kwHit != null) {
                // Nama hanya memilih apa yang diperiksa. Vonis berat butuh bukti dari ISI APK.
                val ev = ContentValidator.apkEvidence(pkg.applicationInfo?.sourceDir)
                val proof = ArrayList<String>()
                if (ev.known) proof += "string sampel cheat di isi APK"
                if (ev.packer.isNotEmpty()) proof += "packer/shell: ${ev.packer.joinToString()}"
                if (ev.tunnel.isNotEmpty()) proof += "native tunnel: ${ev.tunnel.joinToString()}"
                if (ev.hook.isNotEmpty()) proof += "penanda hook: ${ev.hook.joinToString()}"
                if (proof.isNotEmpty()) {
                    add("Package cheat terbukti dari isi APK", "${pkg.packageName}\nBukti isi: ${proof.joinToString("; ")}", Severity.HIGH)
                } else {
                    add(
                        "Package bernama mirip cheat (isi belum terbukti)",
                        "${pkg.packageName} (keyword: $kwHit). Isi APK tidak menunjukkan alat cheat; nama saja tidak cukup sebagai bukti." +
                            if (ev.targetsFf) "\nIsi APK menyebut paket Free Fire." else "",
                        Severity.MEDIUM
                    )
                }
            }
            // Profil "menu cheat root": izin root + overlay + isi dex. Bukan dari nama paket.
            val ai0 = pkg.applicationInfo
            val sysApp = ai0 != null && (ai0.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai0.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (!sysApp && kwHit == null) {
                val perms = pkg.requestedPermissions?.toSet() ?: emptySet()
                val wantsRoot = "android.permission.ACCESS_SUPERUSER" in perms
                val overlay = "android.permission.SYSTEM_ALERT_WINDOW" in perms
                val nonPlay = installerOf(pkg.packageName) != "com.android.vending"
                // Overlay dan "bukan dari Play Store" BUKAN bukti cheat: banyak aplikasi sah memakainya
                // (pemutar video, APK bajakan yang dibutuhkan, dll). Keduanya hanya catatan pendukung.
                if (wantsRoot || (overlay && nonPlay)) {
                    val me = ContentValidator.menuEvidence(ai0?.sourceDir)
                    val label = try { ai0?.let { pm.getApplicationLabel(it).toString() } ?: pkg.packageName } catch (e: Exception) { pkg.packageName }
                    val facts = listOfNotNull(
                        if (wantsRoot) "meminta izin root" else null,
                        if (overlay) "izin overlay (menu melayang)" else null,
                        if (me.tokens.isNotEmpty()) "kelas di dex: ${me.tokens.joinToString()}" else null,
                        if (me.daemonLoader) "pola loader daemon native di dex" else null,
                        if (me.mentionsFf) "isi menyebut paket Free Fire" else null,
                        if (nonPlay) "bukan dari Play Store" else null
                    ).joinToString("; ")
                    when {
                        // app root yang mengunduh lalu menjalankan daemon/driver native sendiri (loader), terbukti dari isi dex
                        me.daemonLoader && wantsRoot ->
                            add("Loader daemon root terbukti dari isi", "$label (${pkg.packageName})\n$facts\nIsi dex memuat pola unduh + jalankan daemon native (driver/daemon cheat).", Severity.HIGH)
                        // bukti inti: kelas menu cheat milik app sendiri + root + overlay
                        me.tokens.isNotEmpty() && wantsRoot && overlay ->
                            add("Menu cheat root terbukti dari isi", "$label (${pkg.packageName})\n$facts", Severity.HIGH)
                        // kelas menu cheat + (menyebut paket FF atau minta root)
                        me.tokens.isNotEmpty() && (me.mentionsFf || wantsRoot) ->
                            add("Kemungkinan menu cheat (isi menyebut kelas ESP/aimbot)", "$label (${pkg.packageName})\n$facts", Severity.MEDIUM)
                        // kelas bernama mirip cheat tapi tidak ada kaitan ke Free Fire/root: hanya catatan
                        me.tokens.isNotEmpty() ->
                            add("Kelas bernama mirip cheat (tidak terkait Free Fire)", "$label (${pkg.packageName})\n$facts. Nama kelas saja bukan bukti.", Severity.LOW)
                        wantsRoot && overlay && me.mentionsFf ->
                            add("App root + overlay menyebut Free Fire (isi belum terbukti cheat)", "$label (${pkg.packageName})\n$facts", Severity.MEDIUM)
                        wantsRoot && overlay ->
                            add("App meminta root + overlay", "$label (${pkg.packageName})\n$facts. Banyak alat sah memakai kombinasi ini.", Severity.LOW)
                        // overlay + non-Play saja (mis. aplikasi bajakan/sideload yang sah): catatan, bukan temuan
                        else -> noteSideloadOverlay += label
                    }
                }
            }
            for (kw in CheatSignatures.AMBIGUOUS_PACKAGE_KEYWORDS) {
                if (name.contains(kw) && CheatSignatures.CHEAT_PACKAGE_KEYWORDS.none { name.contains(it) }) {
                    add("Package perlu diperiksa", "${pkg.packageName} (keyword: $kw, bisa aplikasi sah)", Severity.LOW)
                }
            }
            if (CheatSignatures.ROOT_MANAGER_PACKAGES.contains(name)) {
                add("Aplikasi manajer root terpasang", pkg.packageName, Severity.LOW)
            }
        }
        if (noteSideloadOverlay.isNotEmpty()) {
            add(
                "Catatan: app overlay di luar Play Store (bukan bukti)",
                noteSideloadOverlay.take(12).joinToString(", ") + ". Isinya tidak menunjukkan alat cheat; overlay dan sumber non-Play Store saja tidak dianggap cheat.",
                Severity.INFO
            )
        }
    }

    // -------------------------------------------------------------------------
    // 2. Filesystem residual
    // -------------------------------------------------------------------------
    private fun scanFilesystem() {
        val paths = listOf("/data/local/tmp", "/sbin", "/system/xbin", "/system/bin")
        val rootHits = mutableListOf<String>()
        val hookHits = mutableListOf<String>()

        for (base in paths) {
            val dir = File(base)
            if (!dir.exists() || !dir.canRead()) continue
            dir.walkTopDown().maxDepth(3).forEach { f ->
                val n = f.name.lowercase()
                if (n.contains("inject") || n.contains("hook") || n.contains("frida")) {
                    hookHits += f.absolutePath
                } else if (n.contains("magisk") || n.contains("kernelsu") || n == "ksud" ||
                    n.contains("zygisk") || n.contains("riru") || n.contains("supersu") || n.contains("daemonsu")
                ) {
                    rootHits += f.absolutePath
                }
            }
        }
        if (hookHits.isNotEmpty()) {
            val marks = markersFor(hookHits.take(10))
            hookHits.take(10).forEach { path ->
                val m = marks[path].orEmpty()
                if (m.isNotEmpty()) add("Binary hook terbukti dari isi", "$path\nPenanda: ${m.joinToString()}", Severity.HIGH)
                else add("Binary bernama mirip hook (isi belum terbukti)", "$path\nNama saja tidak cukup; isi tidak menunjukkan framework hook atau tidak terbaca.", Severity.MEDIUM)
            }
        }
        if (rootHits.isNotEmpty()) {
            add("Binary root terlihat", rootHits.take(5).joinToString("\n"), Severity.LOW)
        }

        // /data/adb: hanya terbaca lewat root
        if (rootGranted) {
            val top = suCmd("ls -1 /data/adb 2>/dev/null")?.lines()?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
            if (top.isNotEmpty()) {
                add("Direktori root manager (/data/adb)", top.joinToString(", "), Severity.LOW)
            }
            val modules = suCmd("ls -1 /data/adb/modules 2>/dev/null")?.lines()?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
            if (modules.isNotEmpty()) {
                // Cari dari ISI modul: file mana yang menyebut paket Free Fire / memuat penanda hook.
                fun modulesMatching(regex: String): Set<String> =
                    (suCmd("grep -a -rl -E '$regex' /data/adb/modules 2>/dev/null | head -n 60", 60_000L) ?: "")
                        .lines().map { it.trim() }.filter { it.startsWith("/data/adb/modules/") }
                        .map { it.removePrefix("/data/adb/modules/").substringBefore('/') }.toSet()
                val ffMods = modulesMatching(ContentValidator.FF_REGEX)
                val hookMods = modulesMatching(ContentValidator.HOOK_REGEX)
                for (m in modules) {
                    val ml = m.lowercase()
                    val nameSus = CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { ml.contains(it) } ||
                        CheatSignatures.RESIDUAL_TOKENS.any { ml.contains(it) }
                    val refsFf = m in ffMods
                    val hasHook = m in hookMods
                    val injection = ml.contains("zygisk") || ml.contains("lsposed") || ml.contains("riru") || ml.contains("xposed")
                    when {
                        hasHook && (refsFf || nameSus) ->
                            add("Modul root cheat terbukti dari isi", "/data/adb/modules/$m\nMenyebut Free Fire/nama cheat dan memuat penanda hook.", Severity.HIGH)
                        refsFf ->
                            add("Modul root menyebut paket Free Fire", "/data/adb/modules/$m\nIsi modul menyebut paket Free Fire. Bisa modul performa/pengatur game, bisa juga mod: periksa isinya.", Severity.MEDIUM)
                        nameSus ->
                            add("Modul root bernama mirip cheat (isi tidak menyebut Free Fire)", "/data/adb/modules/$m", Severity.LOW)
                        injection ->
                            add("Modul injeksi aktif", "/data/adb/modules/$m. Framework umum di perangkat root; belum ada bukti menargetkan Free Fire.", Severity.LOW)
                    }
                }
            }
            val lsp = suCmd("grep -a -c -E '${ContentValidator.FF_REGEX}' /data/adb/lspd/config/modules_config.db 2>/dev/null")
                ?.trim()?.lines()?.lastOrNull()?.toIntOrNull() ?: 0
            if (lsp > 0) {
                add("Cakupan LSPosed menyebut Free Fire", "Ada modul Xposed yang cakupannya mencakup paket Free Fire. Bisa modul sah, bisa mod: periksa di LSPosed.", Severity.MEDIUM)
            }
            if (modules.isNotEmpty()) {
                add("Daftar modul root", modules.joinToString(", "), Severity.INFO)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 3. /proc maps + memory indicators
    // -------------------------------------------------------------------------
    private fun scanProcMapsAndMemory() {
        val ffPids = linkedSetOf<Int>()

        File("/proc").listFiles()?.forEach { dir ->
            val pid = dir.name.toIntOrNull() ?: return@forEach
            val cmdline = readFile(File(dir, "cmdline"))?.replace('\u0000', ' ') ?: return@forEach
            if (CheatSignatures.FF_PACKAGES.any { cmdline.contains(it) }) ffPids += pid
        }
        if (rootGranted) {
            for (pkg in CheatSignatures.FF_PACKAGES) {
                suCmd("pidof $pkg 2>/dev/null")?.trim()?.split(Regex("\\s+"))
                    ?.mapNotNull { it.toIntOrNull() }?.forEach { ffPids += it }
            }
        }

        if (ffPids.isEmpty()) {
            add(
                if (rootGranted) "Free Fire tidak sedang berjalan" else "Memori game tidak dapat diverifikasi",
                if (rootGranted) "Jalankan Free Fire lalu scan lagi agar memori diperiksa."
                else "Tanpa root Android menyembunyikan proses & memori aplikasi lain. Bukan indikasi cheat.",
                Severity.INFO
            )
            return
        }

        // Root: proses lain yang membuka /proc/<pid game>/mem atau maps = akses memori game dari luar (perilaku, bukan nama)
        if (rootGranted) {
            for (ff in ffPids) {
                val openers = (suCmd(
                    "for d in /proc/[0-9]*; do ls -l \$d/fd 2>/dev/null | grep -qE '/proc/$ff/(mem|maps)' && echo \${d#/proc/}; done",
                    45_000L
                ) ?: "").lines().mapNotNull { it.trim().toIntOrNull() }.filter { it != ff && it != android.os.Process.myPid() }
                for (op in openers.distinct().take(5)) {
                    val cmd = (readPriv("/proc/$op/cmdline")?.replace('\u0000', ' ')?.trim().orEmpty()).take(140)
                    if (cmd.startsWith("/system/") || cmd.startsWith("/apex/") || cmd.startsWith("/vendor/")) continue
                    add("Proses lain membuka memori game", "PID $op ($cmd) membuka memori/maps Free Fire (PID $ff). Aplikasi biasa tidak melakukan ini.", Severity.HIGH)
                }
            }
        }

        for (pid in ffPids) {
            val status = readPriv("/proc/$pid/status")
            val tracer = status?.lines()?.find { it.startsWith("TracerPid:") }
                ?.substringAfter(":")?.trim()?.toIntOrNull() ?: 0
            if (tracer > 0) {
                val tName = (readPriv("/proc/$tracer/cmdline")?.replace('\u0000', ' ')?.trim().takeUnless { it.isNullOrBlank() }
                    ?: readPriv("/proc/$tracer/comm")?.trim() ?: "tidak terbaca").take(120)
                val tl = tName.lowercase()
                val tool = listOf("frida", "gameguardian", "cheatengine").any { tl.contains(it) } ||
                    CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { tl.contains(it) }
                if (tool) add("Proses game di-trace oleh alat cheat", "PID $pid TracerPid=$tracer ($tName)", Severity.HIGH)
                else add("Proses game sedang di-trace", "PID $pid TracerPid=$tracer ($tName). Bisa debugger sah; sumbernya belum terbukti cheat.", Severity.MEDIUM)
            }

            val maps = readPriv("/proc/$pid/maps")
            if (maps.isNullOrBlank()) {
                add("Maps PID $pid tidak terbaca", "Tidak dapat diverifikasi.", Severity.INFO)
                continue
            }
            val foreign = linkedSetOf<String>()
            var anon = 0
            for (line in maps.lineSequence()) {
                val parts = line.trim().split(Regex("\\s+"), limit = 6)
                if (parts.size < 2) continue
                val perms = parts[1]
                val path = parts.getOrNull(5)?.trim().orEmpty().removeSuffix(" (deleted)")
                if (path.startsWith("/") && perms.contains('x') && !isSystemOrOwnPath(path)) foreign += path
                // anon executable besar (pure memory inject); region ART/JIT tidak dihitung
                if (perms.startsWith("r-x") && path.startsWith("[anon:") &&
                    !path.contains("dalvik") && !path.contains("jit")
                ) {
                    val range = parts[0].split("-")
                    if (range.size == 2) {
                        val start = range[0].toLongOrNull(16) ?: 0L
                        val end = range[1].toLongOrNull(16) ?: 0L
                        if (end - start > 0x100000) anon++
                    }
                }
            }

            // Library asing di proses game: vonis dari ISI (penanda hook), bukan dari nama.
            val candidates = foreign.take(25)
            val marks = if (candidates.isNotEmpty()) markersFor(candidates) else emptyMap()
            val frameworkTokens = listOf("zygisk", "riru", "lsposed", "xposed", "substrate", "edxp")
            val cheatNameTokens = CheatSignatures.MAPS_STRINGS.filter { it !in frameworkTokens && it != "frida" }
            for (path in candidates) {
                val name = path.substringAfterLast('/').lowercase()
                val m = marks[path].orEmpty()
                when {
                    m.isNotEmpty() ->
                        add("Library asing berpenanda hook dimuat di proses game", "PID $pid: $path\nPenanda di isi: ${m.joinToString()}", Severity.HIGH)
                    name.contains("frida") ->
                        add("Frida dimuat di proses game", "PID $pid: $path", Severity.HIGH)
                    frameworkTokens.any { name.contains(it) } -> {
                        val mod = if (path.startsWith("/data/adb/modules/")) path.removePrefix("/data/adb/modules/").substringBefore('/') else null
                        val targets = mod != null &&
                            !(suCmd("grep -a -rl -E '${ContentValidator.FF_REGEX}' '/data/adb/modules/$mod' 2>/dev/null | head -n 1") ?: "").isBlank()
                        if (targets) add("Modul ${mod} menargetkan Free Fire dan dimuat di proses game", "PID $pid: $path", Severity.MEDIUM)
                        else add(
                            "Framework injeksi dimuat di proses game",
                            "PID $pid: $path. Zygisk/LSPosed lazim memuat ke banyak aplikasi di perangkat root/custom; belum ada bukti menargetkan Free Fire.",
                            Severity.LOW
                        )
                    }
                    cheatNameTokens.any { mapsPathMatches(path, it) } ->
                        add("Library bernama mirip cheat (isi belum menunjukkan hook)", "PID $pid: $path", Severity.MEDIUM)
                }
            }
            if (anon > 0) add("Anon executable besar", "PID $pid: $anon region > 1 MB (belum tentu cheat; driver/runtime tertentu juga memakainya)", Severity.MEDIUM)
        }
    }

    /** Lokasi library sistem dan milik Free Fire sendiri tidak diperiksa sebagai "asing". */
    private fun isSystemOrOwnPath(p: String): Boolean {
        val sys = listOf(
            "/system/", "/vendor/", "/apex/", "/product/", "/system_ext/", "/odm/", "/vendor_dlkm/", "/odm_dlkm/",
            "/data/dalvik-cache/", "/dev/", "/proc/", "/memfd:", "/data/misc/"
        )
        if (sys.any { p.startsWith(it) }) return true
        if (p.startsWith("/data/app/") &&
            (CheatSignatures.FF_PACKAGES.any { p.contains(it) } || p.contains("/com.google.android.") || p.contains("/com.android."))
        ) return true
        return false
    }

    /** Penanda hook di ISI tiap file: root lewat satu panggilan su, tanpa root hanya file yang bisa dibaca. */
    private fun markersFor(paths: List<String>): Map<String, List<String>> {
        val res = LinkedHashMap<String, List<String>>()
        val safe = paths.filter { !it.contains('\'') && !it.contains('\n') }
        if (safe.isEmpty()) return res
        if (!rootGranted) {
            for (p in safe) res[p] = ContentValidator.fileHookMarkers(File(p))
            return res
        }
        val script = safe.joinToString("; ") { p ->
            "echo '##P'; echo '$p'; head -c 12582912 '$p' 2>/dev/null | grep -a -o -E '${ContentValidator.HOOK_REGEX}' | sort -u | head -n 6"
        }
        val lines = (suCmd(script, 60_000L) ?: return res).lines()
        var cur: String? = null
        val acc = ArrayList<String>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i].trim()
            if (l == "##P") {
                if (cur != null) res[cur] = acc.toList()
                acc.clear()
                cur = lines.getOrNull(i + 1)?.trim()
                i += 2
                continue
            }
            if (l.isNotEmpty() && cur != null) acc += l
            i++
        }
        if (cur != null) res[cur] = acc.toList()
        return res
    }

    private fun mapsPathMatches(path: String, sig: String): Boolean {
        val name = path.substringAfterLast('/').lowercase()
        val s = sig.lowercase()
        return if (s.length <= 3) name.split(Regex("[^a-z0-9]+")).any { it == s } else name.contains(s)
    }

    // -------------------------------------------------------------------------
    // 4. Network / VPN / local ports
    // -------------------------------------------------------------------------
    private fun scanNetworkAndVpn() {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        var vpn = false
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) vpn = true
        }
        if (vpn) add("VPN aktif", "Ada jaringan VPN yang terlihat. Pemeriksaan pemilik VPN ada di modul Proxy/VPN.", Severity.LOW)

        val netstat = if (rootGranted) suCmd("ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null") ?: ""
        else runCmd("ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null")
        if (netstat.isBlank()) return
        fun listening(port: Int) = Regex(":$port(\\s|$)", RegexOption.MULTILINE).containsMatchIn(netstat)
        val withProc = if (rootGranted) (suCmd("ss -ltnp 2>/dev/null || netstat -ltnp 2>/dev/null") ?: "") else ""
        for (p in CheatSignatures.HIGH_PORTS) if (listening(p)) {
            val owner = withProc.lines().firstOrNull { Regex(":$p(\\s|$)").containsMatchIn(it) }.orEmpty()
            if (owner.lowercase().contains("frida")) add("Port Frida listen", "Port $p dipegang proses frida-server: ${owner.trim().take(140)}", Severity.HIGH)
            else add(
                "Port bawaan Frida terbuka (pemilik belum terbukti)",
                "Port $p listen. " + if (rootGranted) "Proses pemilik bukan frida." else "Tanpa root pemilik port tidak bisa dilihat; bukan bukti cheat.",
                Severity.MEDIUM
            )
        }
        for (p in CheatSignatures.MEDIUM_PORTS) if (listening(p)) add("Port mencurigakan", "Port $p sedang listen", Severity.MEDIUM)
        for (p in CheatSignatures.LOW_PORTS) if (listening(p)) add("Port umum developer", "Port $p sedang listen", Severity.LOW)
    }

    // -------------------------------------------------------------------------
    // 5. Virtual space / multi-user
    // -------------------------------------------------------------------------
    private fun scanVirtualSpaces() {
        // Apakah scanner ini sendiri berjalan di dalam container?
        val own = context.filesDir.absolutePath
        val expected = Regex("^/data/(data|user/\\d+)/${Regex.escape(context.packageName)}/files$")
        if (!expected.matches(own)) {
            add(
                "Scanner berjalan di dalam container",
                "Path data: $own (bukan path normal Android). Umum dipakai sah (akun ganda); hasil scan di container tidak mewakili seluruh HP.",
                Severity.MEDIUM
            )
        }

        val users = runCmd("pm list users 2>/dev/null")
        if (users.lines().count { it.contains("UserInfo{") } > 1) {
            add("Multi-user terdeteksi", "Ada profil pengguna tambahan (work profile/secure folder/virtual space).", Severity.LOW)
        }

        val pm = context.packageManager
        for (c in CheatSignatures.CONTAINER_PACKAGES_HIGH + CheatSignatures.CONTAINER_PACKAGES_MEDIUM) {
            try {
                pm.getPackageInfo(c, 0)
                add("Virtual space terpasang", "$c. Nama saja bukan bukti; umum dipakai untuk akun ganda.", Severity.LOW)
            } catch (e: Exception) {
            }
        }
    }

    // -------------------------------------------------------------------------
    // 6. Kernel / root residual
    // -------------------------------------------------------------------------
    private fun scanKernelResiduals() {
        // properti (bisa dibaca tanpa root)
        val boot = runCmd("getprop ro.boot.verifiedbootstate").trim()
        if (boot.isNotEmpty() && boot != "green") {
            add("Boot state tidak green", "ro.boot.verifiedbootstate = $boot (bootloader unlocked/modifikasi)", Severity.LOW)
        }
        if (runCmd("getprop ro.debuggable").trim() == "1") {
            add("ro.debuggable=1", "Device dalam mode debug", Severity.LOW)
        }
        if (runCmd("getprop ro.secure").trim() == "0") {
            add("ro.secure=0", "Build non-secure (adb root)", Severity.LOW)
        }

        // jejak root yang bisa dilihat TANPA root: mount dan library di proses scanner sendiri
        val mounts = readFile(File("/proc/self/mountinfo"))
        if (mounts != null) {
            val m = mounts.lineSequence().filter {
                val l = it.lowercase()
                l.contains("magisk") || l.contains("/data/adb/modules") || l.contains("kernelsu") || l.contains(" ksu ") || l.contains("apatch")
            }.take(3).toList()
            if (m.isNotEmpty()) add("Mount jejak root", m.joinToString("\n") { it.take(120) }, Severity.MEDIUM)
        }
        val selfMaps = readFile(File("/proc/self/maps"))
        if (selfMaps != null) {
            val tokens = listOf("zygisk", "riru", "lsposed", "xposed", "frida", "substrate")
            val found = tokens.filter { t ->
                selfMaps.lineSequence().any { line ->
                    val p = line.trim().split(Regex("\\s+"), limit = 6).getOrNull(5).orEmpty()
                    p.isNotEmpty() && p.substringAfterLast('/').lowercase().contains(t)
                }
            }
            if (found.isNotEmpty()) {
                add("Library injeksi masuk ke proses scanner", found.joinToString(", "), Severity.MEDIUM)
            }
        }

        // Modul kernel yang dimuat tetapi berkasnya tidak ada di partisi sistem (kemungkinan dimuat manual / driver tambahan)
        if (rootGranted) {
            val mods = (suCmd("cat /proc/modules 2>/dev/null | cut -d' ' -f1") ?: "")
                .lines().map { it.trim() }.filter { it.isNotEmpty() && !it.contains(' ') && !it.contains(':') }
            if (mods.isNotEmpty()) {
                val onDisk = (suCmd(
                    "find /vendor/lib/modules /vendor_dlkm/lib/modules /system/lib/modules /system_dlkm/lib/modules /odm/lib/modules /lib/modules -name '*.ko' 2>/dev/null",
                    40_000L
                ) ?: "").lines().map { it.substringAfterLast('/').removeSuffix(".ko").replace('-', '_') }.toSet()
                val orphan = mods.filter { it.replace('-', '_') !in onDisk }
                val suspName = listOf("hack", "cheat", "rwmem", "memrw", "vmem", "kmem", "gardem")
                val suspicious = orphan.filter { n -> suspName.any { n.lowercase().contains(it) } }
                if (suspicious.isNotEmpty()) {
                    add("Modul kernel bernama mirip driver cheat (isi belum terbukti)", suspicious.joinToString(", "), Severity.MEDIUM)
                }
                if (orphan.isNotEmpty()) {
                    add(
                        "Modul kernel tanpa berkas di partisi sistem (${orphan.size})",
                        orphan.take(8).joinToString(", ") +
                            "\nBisa modul dari ramdisk/ROM custom yang sah, bisa juga driver yang dimuat manual. Periksa asalnya; bukan bukti cheat sendiri.",
                        Severity.LOW
                    )
                }
            }
        }

        // kallsyms: kernel modern memblokir non-root -> tidak dapat diverifikasi
        var kall = readFile(File("/proc/kallsyms"))
        if (kall.isNullOrBlank() && rootGranted) kall = suCmd("cat /proc/kallsyms 2>/dev/null")
        if (kall.isNullOrBlank()) {
            add("kallsyms tidak dapat diverifikasi", "Kernel memblokir pembacaan simbol. Bukan indikasi cheat.", Severity.INFO)
            return
        }
        val hit = linkedSetOf<String>()
        for (line in kall.lineSequence()) {
            val parts = line.split(' ')
            if (parts.size < 3) continue
            val sym = parts[2].lowercase()
            for (ind in CheatSignatures.ROOT_INDICATORS) {
                val match = if (ind == "ksu") Regex("(^|_)ksu(_|$)").containsMatchIn(sym) else sym.contains(ind)
                if (match) hit += ind
            }
            if (hit.size == CheatSignatures.ROOT_INDICATORS.size) break
        }
        hit.forEach { add("Symbol kernel", "kallsyms mengandung simbol \"$it\"", Severity.MEDIUM) }
    }


    // -------------------------------------------------------------------------
    // 6b. Daemon root dari folder data aplikasi (jejak daemon/driver cheat; root saja)
    // -------------------------------------------------------------------------
    private fun scanRootDaemons() {
        if (!rootGranted) {
            add("Daemon root tidak dapat diverifikasi", "Tanpa root, proses milik root tidak terlihat. Bukan indikasi cheat.", Severity.INFO)
            return
        }
        val out = suCmd(
            "for p in /proc/[0-9]*; do u=\$(stat -c %u \$p 2>/dev/null); [ \"\$u\" = 0 ] || continue; " +
                "e=\$(readlink \$p/exe 2>/dev/null); case \"\$e\" in " +
                "/data/data/*|/data/user/*|/data/local/tmp/*|/dev/shm/*|/sdcard/*|/storage/*|*\"(deleted)\"*) echo \"\${p#/proc/}|\$e\";; esac; done",
            40_000L
        ) ?: return
        val pm = context.packageManager
        val me = android.os.Process.myPid()
        val seen = HashSet<String>()
        for (line in out.lines().take(60)) {
            val pid = line.substringBefore('|').trim().toIntOrNull() ?: continue
            val exe = line.substringAfter('|').trim()
            if (pid == me || exe.isEmpty() || !seen.add(exe)) continue
            val low = exe.lowercase()
            val dataPkg = Regex("^/data/(?:data|user/\\d+)/([a-zA-Z0-9_.]+)/").find(exe)?.groupValues?.get(1)
            val cmd = (readPriv("/proc/$pid/cmdline")?.replace('\u0000', ' ')?.trim().orEmpty()).take(100)
            if (dataPkg != null) {
                val ai = try { pm.getApplicationInfo(dataPkg, 0) } catch (e: Exception) { null }
                if (ai == null) {
                    add("Daemon root hidup dari aplikasi yang sudah dihapus", "PID $pid: $exe $cmd\nAplikasi $dataPkg tidak terpasang, tetapi prosesnya masih berjalan sebagai root. Ini jejak yang tertinggal.", Severity.MEDIUM)
                    continue
                }
                val ev = ContentValidator.apkEvidence(ai.sourceDir)
                val menu = ContentValidator.menuEvidence(ai.sourceDir)
                val proof = listOfNotNull(
                    if (ev.known) "string sampel cheat di isi APK" else null,
                    if (menu.tokens.isNotEmpty()) "kelas menu cheat: ${menu.tokens.joinToString()}" else null,
                    if (menu.daemonLoader) "pola loader daemon" else null,
                    if (ev.hook.isNotEmpty()) "penanda hook: ${ev.hook.joinToString()}" else null
                )
                if (proof.isNotEmpty()) {
                    add("Daemon root milik app cheat berjalan", "PID $pid: $exe $cmd\nPemilik: $dataPkg\nBukti isi: ${proof.joinToString("; ")}", Severity.HIGH)
                } else {
                    add("Proses root berjalan dari folder data aplikasi", "PID $pid: $exe $cmd\nPemilik: $dataPkg. Isi APK tidak menunjukkan alat cheat; sebagian alat root sah juga melakukan ini.", Severity.LOW)
                }
            } else {
                val nameCheat = CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { low.contains(it) }
                if (nameCheat) add("Proses root bernama mirip cheat (isi belum terbukti)", "PID $pid: $exe $cmd", Severity.MEDIUM)
                else add("Proses root dari lokasi tidak lazim", "PID $pid: $exe $cmd\nLokasi seperti ini umum dipakai alat developer; bukan bukti cheat sendiri.", Severity.LOW)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 7. Accessibility (script / auto aim)
    // -------------------------------------------------------------------------
    private fun scanAccessibility() {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? android.view.accessibility.AccessibilityManager
            ?: return
        val enabled = am.getEnabledAccessibilityServiceList(
            android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        for (svc in enabled) {
            val si = svc.resolveInfo.serviceInfo
            val pkg = si.packageName.lowercase()
            if (si.applicationInfo != null && si.applicationInfo!!.flags and ApplicationInfo.FLAG_SYSTEM != 0) continue
            if (CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { pkg.contains(it) }) {
                add("Accessibility bernama mirip cheat", "$pkg. Nama saja bukan bukti.", Severity.MEDIUM)
            } else if (pkg.contains("autoclick") || pkg.contains("clicker") || pkg.contains("macro")) {
                add("Accessibility auto-click/macro", "$pkg. Umum dipakai sah.", Severity.LOW)
            }
        }
    }

    // -------------------------------------------------------------------------
    // 8. Shizuku / wireless ADB
    // -------------------------------------------------------------------------
    private fun scanShizukuAndAdb() {
        val processes = if (rootGranted) (suCmd("ps -A 2>/dev/null") ?: "") else runCmd("ps -A 2>/dev/null || ps 2>/dev/null")
        if (processes.contains("shizuku_server") || processes.contains("shizuku")) {
            add("Shizuku aktif", "shizuku_server berjalan. Alat sah (tema, automasi) tetapi juga bisa dipakai inject; bukan bukti cheat sendiri.", Severity.MEDIUM)
        }
        if (File("/data/local/tmp/shizuku_starter").exists() || File("/data/local/tmp/shizuku").exists()) {
            add("Shizuku residual file", "/data/local/tmp/shizuku*", Severity.LOW)
        }

        // ADB: hanya naik severity bila ada perangkat TERSAMBUNG / bukti data game diubah.
        // Debugging nirkabel yang sekadar menyala bukan cheat (lihat AdbSessionScanner).
        AdbSessionScanner(context, rootGranted) { suCmd(it) }.scan()
            .forEach { add(it.title, it.detail, it.severity) }
    }

    // -------------------------------------------------------------------------
    // 9. Data Free Fire (root, atau Android <= 10)
    // -------------------------------------------------------------------------
    private fun scanFreeFireResiduals() {
        val installed = CheatSignatures.FF_PACKAGES.filter { isInstalled(it) }
        if (installed.isEmpty()) return

        for (pkg in installed) {
            val dirs = listOf("/data/data/$pkg", "/sdcard/Android/data/$pkg", "/sdcard/Android/obb/$pkg")
            val files: List<String>? = if (rootGranted) {
                val q = dirs.joinToString(" ") { "'$it'" }
                suCmd("find $q -type f 2>/dev/null | head -n 20000", 60_000L)?.lines()?.filter { it.isNotBlank() }
            } else {
                val base = File("/sdcard/Android/data/$pkg")
                if (base.isDirectory && base.listFiles() != null)
                    base.walkTopDown().filter { it.isFile }.take(20000).map { it.absolutePath }.toList()
                else null
            }

            if (files == null) {
                add(
                    "Data $pkg tidak dapat diverifikasi",
                    "Android 11+ memblokir /data/data dan Android/data tanpa root. Bukan indikasi cheat.",
                    Severity.INFO
                )
                continue
            }

            var minor = 0
            val hitPaths = ArrayList<String>()
            for (path in files) {
                val n = path.substringAfterLast('/').lowercase()
                if (CheatSignatures.RESIDUAL_TOKENS.any { n.contains(it) }) {
                    if (hitPaths.size < 10) hitPaths += path
                } else if (n.endsWith(".bak") || n.endsWith(".old") || n.endsWith(".tmp")) {
                    minor++
                }
            }
            if (hitPaths.isNotEmpty()) {
                val marks = markersFor(hitPaths)
                for (path in hitPaths) {
                    val m = marks[path].orEmpty()
                    if (m.isNotEmpty()) add("Residual hook terbukti dari isi", "$path\nPenanda: ${m.joinToString()}", Severity.HIGH)
                    else add("File data FF bernama mirip hook (isi belum terbukti)", "$path\nNama saja tidak cukup; isi tidak menunjukkan hook atau tidak terbaca.", Severity.MEDIUM)
                }
            }
            if (minor > 0) add("File sementara/cadangan di data FF", "$pkg: $minor file .bak/.old/.tmp (umum, hanya informasi)", Severity.LOW)
            add("Data $pkg diperiksa", "${files.size} file", Severity.INFO)
        }
    }

    // -------------------------------------------------------------------------
    // Profil perangkat: ROM/kernel custom dan root BUKAN bukti cheat
    // -------------------------------------------------------------------------
    private fun scanEnvironmentProfile() {
        val props = HashMap<String, String>()
        Regex("(?m)^\\[([^\\]]+)]: \\[(.*)]$").findAll(runCmd("getprop")).forEach {
            props[it.groupValues[1]] = it.groupValues[2]
        }
        val tags = (Build.TAGS ?: "").lowercase()
        val hay = ((Build.DISPLAY ?: "") + " " + (Build.FINGERPRINT ?: "") + " " + (props["ro.build.flavor"] ?: "")).lowercase()
        val customProps = props.filterKeys { k ->
            val l = k.lowercase()
            l.endsWith(".version") && CheatSignatures.CUSTOM_ROM_HINTS.any { h -> l.contains(h.replace(" ", "")) } ||
                l == "ro.modversion" || l == "ro.lineage.version" || l == "ro.crdroid.version"
        }.keys
        val romCustom = tags.contains("test-keys") || customProps.isNotEmpty() || CheatSignatures.CUSTOM_ROM_HINTS.any { hay.contains(it) }
        val boot = props["ro.boot.verifiedbootstate"].orEmpty()
        val locked = props["ro.boot.flash.locked"].orEmpty()
        val vbmeta = props["ro.boot.vbmeta.device_state"].orEmpty()
        val bootUnlocked = (boot.isNotEmpty() && boot != "green") || locked == "0" || vbmeta == "unlocked"
        val kernel = System.getProperty("os.version").orEmpty()
        val kernelFlag = kernel.lowercase().let { it.contains("ksu") || it.contains("kernelsu") || it.contains("apatch") }
        val buildType = props["ro.build.type"].orEmpty()

        val sb = StringBuilder()
        sb.appendLine("ROM        : ${if (romCustom) "kemungkinan ROM custom" else "tampak stok/resmi"} (${Build.DISPLAY})")
        sb.appendLine("Bootloader : ${if (bootUnlocked) "unlocked/modifikasi" else if (boot.isNotEmpty()) "terkunci" else "tidak terbaca"}")
        sb.appendLine("Kernel     : $kernel${if (kernelFlag) " (membawa dukungan root)" else ""}")
        if (buildType.isNotEmpty() && buildType != "user") sb.appendLine("Build      : $buildType")
        sb.append("ROM/kernel custom, bootloader unlocked, dan root TIDAK dianggap cheat. Vonis hanya memakai bukti dari isi APK, library, dan modul yang berkaitan dengan Free Fire.")
        add("Profil perangkat", sb.toString(), Severity.INFO)
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private fun add(title: String, detail: String, sev: Severity) {
        val buf = sink.get()
        if (buf != null) buf += Finding(title, detail, sev)
        else synchronized(findings) { findings += Finding(title, detail, sev) }
    }

    private fun runStep(name: String, block: () -> Unit): List<Finding> {
        val local = ArrayList<Finding>()
        sink.set(local)
        try {
            block()
        } catch (e: Exception) {
            local += Finding("Modul $name gagal", e.message ?: e.javaClass.simpleName, Severity.INFO)
        } finally {
            sink.remove()
        }
        return local
    }

    private fun toFinding(i: IntegrityScanner.Item): Finding = Finding(
        i.title, i.detail,
        when (i.level) {
            IntegrityScanner.Level.CRITICAL -> Severity.HIGH
            IntegrityScanner.Level.WARN -> Severity.MEDIUM
            IntegrityScanner.Level.LOW -> Severity.LOW
            IntegrityScanner.Level.INFO -> Severity.INFO
        }
    )

    private fun installerOf(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) context.packageManager.getInstallSourceInfo(pkg).installingPackageName
        else @Suppress("DEPRECATION") context.packageManager.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    private fun isInstalled(pkg: String): Boolean = try {
        context.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun checkRoot(): Boolean {
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/data/local/su", "/data/local/bin/su"
        )
        if (paths.any { File(it).exists() }) return true
        if (CheatSignatures.ROOT_MANAGER_PACKAGES.any { isInstalled(it) }) return true
        return runCmd("which su 2>/dev/null").isNotBlank()
    }

    private fun readFile(f: File): String? {
        return try {
            if (f.exists() && f.canRead()) f.readText() else null
        } catch (e: Exception) {
            null
        }
    }

    /** Baca file; bila tidak bisa dan root diberikan, baca lewat su. */
    private fun readPriv(path: String): String? {
        val direct = readFile(File(path))
        if (!direct.isNullOrBlank()) return direct
        return if (rootGranted) suCmd("cat '$path' 2>/dev/null") else null
    }

    private fun runCmd(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out = BufferedReader(InputStreamReader(p.inputStream)).readText()
            p.waitFor()
            out
        } catch (e: Exception) {
            ""
        }
    }

    /** Jalankan perintah sebagai root (memunculkan dialog izin Magisk/KernelSU/APatch pada pemakaian pertama). */
    private fun suCmd(cmd: String, timeoutMs: Long = 25_000L): String? = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val dog = Thread {
            try { Thread.sleep(timeoutMs) } catch (e: InterruptedException) { return@Thread }
            p.destroy()
        }
        dog.isDaemon = true
        dog.start()
        val text = try { p.inputStream.bufferedReader().readText() } catch (e: Exception) { "" }
        val code = try { p.waitFor() } catch (e: InterruptedException) { -1 }
        dog.interrupt()
        if (code != 0 && text.isBlank()) null else text
    } catch (e: Exception) {
        null
    }

    data class ScanResult(
        val isCheat: Boolean,
        val verdict: VerdictPolicy.Verdict = VerdictPolicy.Verdict.CLEAN,
        val findings: List<Finding>,
        val rooted: Boolean,
        val timestamp: String,
        val rootGranted: Boolean = false
    )
}
