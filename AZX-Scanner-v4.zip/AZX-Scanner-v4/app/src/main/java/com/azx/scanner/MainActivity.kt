package com.azx.scanner

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.azx.scanner.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var engine: ScannerEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        engine = ScannerEngine(this)

        binding.btnScan.setOnClickListener {
            startScan()
        }
    }

    private fun startScan() {
        binding.btnScan.isEnabled = false
        binding.tvStatus.text = "SCAN…"
        binding.tvStatus.setTextColor(Color.parseColor("#8B949E"))
        binding.tvDetail.text = "Memindai jejak cheat…\nMohon tunggu."

        lifecycleScope.launch {
            val result = engine.runFullScan()
            showResult(result)
            binding.btnScan.isEnabled = true
        }
    }

    private fun showResult(result: ScannerEngine.ScanResult) {
        if (result.isCheat) {
            binding.tvStatus.text = "CHEAT"
            binding.tvStatus.setTextColor(Color.parseColor("#FF5252"))
        } else {
            binding.tvStatus.text = "BERSIH"
            binding.tvStatus.setTextColor(Color.parseColor("#00E676"))
        }

        val sb = StringBuilder()
        sb.appendLine("Waktu   : ${result.timestamp}")
        sb.appendLine("Root    : ${if (result.rooted) "Ya" else "Tidak"}")
        sb.appendLine("Temuan  : ${result.findings.size}")
        sb.appendLine()

        if (result.findings.isEmpty()) {
            sb.appendLine("Tidak ada jejak cheat yang terdeteksi.")
        } else {
            result.findings
                .sortedByDescending { it.severity.ordinal }
                .forEachIndexed { i, f ->
                    sb.appendLine("[${i + 1}] ${f.severity} — ${f.title}")
                    sb.appendLine("    ${f.detail}")
                    sb.appendLine()
                }
        }

        binding.tvDetail.text = sb.toString()
    }
}
