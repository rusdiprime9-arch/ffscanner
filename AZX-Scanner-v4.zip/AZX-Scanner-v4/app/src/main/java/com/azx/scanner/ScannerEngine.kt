package com.azx.scanner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScannerEngine(private val context: Context) {

    private val findings = mutableListOf<CheatSignatures.Finding>()
    private var isRooted = false

    suspend fun runFullScan(): ScanResult = withContext(Dispatchers.IO) {
        findings.clear()
        isRooted = checkRoot()

        scanPackages()
        scanFilesystem()
        scanProcMapsAndMemory()
        scanNetworkAndVpn()
        scanVirtualSpaces()
        scanKernelResiduals()
        scanAccessibility()
        scanShizukuAndAdb()
        scanFreeFireResiduals()

        val high = findings.count { it.severity == CheatSignatures.Severity.HIGH }
        val med = findings.count { it.severity == CheatSignatures.Severity.MEDIUM }
        val isCheat = high > 0 || med >= 3

        ScanResult(
            isCheat = isCheat,
            findings = findings.toList(),
            rooted = isRooted,
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        )
    }

    // -------------------------------------------------------------------------
    // 1. Package scan
    // -------------------------------------------------------------------------
    private fun scanPackages() {
        val pm = context.packageManager
        val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)

        for (pkg in packages) {
            val name = pkg.packageName.lowercase()
            for (kw in CheatSignatures.CHEAT_PACKAGE_KEYWORDS) {
                if (name.contains(kw)) {
                    findings += CheatSignatures.Finding(
                        "Package mencurigakan",
                        "${pkg.packageName} (keyword: $kw)",
                        CheatSignatures.Severity.HIGH
                    )
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // 2. Filesystem residual
    // -------------------------------------------------------------------------
    private fun scanFilesystem() {
        val paths = listOf(
            "/data/local/tmp",
            "/data/adb",
            "/sbin",
            "/system/xbin",
            "/system/bin"
        )
        for (base in paths) {
            val dir = File(base)
            if (!dir.exists() || !dir.canRead()) continue
            dir.walkTopDown().maxDepth(3).forEach { f ->
                val n = f.name.lowercase()
                if (CheatSignatures.ROOT_INDICATORS.any { n.contains(it) } ||
                    n.contains("inject") || n.contains("hook") || n.contains("frida")) {
                    findings += CheatSignatures.Finding(
                        "Binary residual",
                        f.absolutePath,
                        CheatSignatures.Severity.HIGH
                    )
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // 3. /proc maps + memory indicators (pure memory & drip)
    // -------------------------------------------------------------------------
    private fun scanProcMapsAndMemory() {
        val proc = File("/proc")
        if (!proc.exists()) return

        val ffPids = mutableListOf<Int>()
        proc.listFiles()?.forEach { dir ->
            val pid = dir.name.toIntOrNull() ?: return@forEach
            val cmdline = readFile(File(dir, "cmdline"))?.replace('\u0000', ' ') ?: return@forEach
            if (CheatSignatures.FF_PACKAGES.any { cmdline.contains(it) }) {
                ffPids += pid
            }
        }

        for (pid in ffPids) {
            // TracerPid
            val status = readFile(File("/proc/$pid/status")) ?: continue
            val tracer = status.lines().find { it.startsWith("TracerPid:") }
                ?.substringAfter(":")?.trim()?.toIntOrNull() ?: 0
            if (tracer > 0) {
                findings += CheatSignatures.Finding(
                    "Proses di-trace",
                    "PID $pid TracerPid=$tracer (indikasi memory attach)",
                    CheatSignatures.Severity.HIGH
                )
            }

            // maps strings
            val maps = readFile(File("/proc/$pid/maps")) ?: continue
            for (sig in CheatSignatures.MAPS_STRINGS) {
                if (maps.contains(sig, ignoreCase = true)) {
                    findings += CheatSignatures.Finding(
                        "String hook di maps",
                        "PID $pid → \"$sig\"",
                        CheatSignatures.Severity.HIGH
                    )
                }
            }

            // anon executable regions (common in pure memory inject)
            maps.lines().forEach { line ->
                if (line.contains("r-xp") && line.contains("[anon:") &&
                    line.split(" ").getOrNull(1)?.let {
                        val size = it.split("-")
                        if (size.size == 2) {
                            val start = size[0].toLongOrNull(16) ?: 0
                            val end = size[1].toLongOrNull(16) ?: 0
                            (end - start) > 0x100000 // > 1 MB
                        } else false
                    } == true
                ) {
                    findings += CheatSignatures.Finding(
                        "Anon executable besar",
                        "PID $pid maps: ${line.take(60)}…",
                        CheatSignatures.Severity.MEDIUM
                    )
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // 4. Network / VPN / local ports
    // -------------------------------------------------------------------------
    private fun scanNetworkAndVpn() {
        // VPN active?
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networks = cm.allNetworks
        for (n in networks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                findings += CheatSignatures.Finding(
                    "VPN aktif",
                    "Ada interface VPN (bisa dipakai proxy cheat)",
                    CheatSignatures.Severity.MEDIUM
                )
            }
        }

        // local listening ports
        val netstat = runCmd("ss -ltn 2>/dev/null || netstat -ltn 2>/dev/null")
        for (port in CheatSignatures.SUSPICIOUS_PORTS) {
            if (netstat.contains(":$port ") || netstat.contains(":$port\n")) {
                findings += CheatSignatures.Finding(
                    "Port mencurigakan",
                    "Port $port sedang listen (injector/proxy)",
                    CheatSignatures.Severity.HIGH
                )
            }
        }
    }

    // -------------------------------------------------------------------------
    // 5. Virtual space / multi-user
    // -------------------------------------------------------------------------
    private fun scanVirtualSpaces() {
        // check secondary users
        val users = runCmd("pm list users 2>/dev/null")
        if (users.contains("UserInfo{") && users.lines().count { it.contains("UserInfo{") } > 1) {
            findings += CheatSignatures.Finding(
                "Multi-user terdeteksi",
                "Ada user profile tambahan (kemungkinan virtual space)",
                CheatSignatures.Severity.MEDIUM
            )
        }

        // known container packages
        val containers = listOf(
            "com.lody.virtual", "com.parallel.space", "com.cloneapp.parallelspace",
            "com.excelliance.multiaccounts", "info.cloneapp.mochat.inclone",
            "com.oasisfeng.island", "com.dualspace"
        )
        val pm = context.packageManager
        for (c in containers) {
            try {
                pm.getPackageInfo(c, 0)
                findings += CheatSignatures.Finding(
                    "Virtual space terpasang",
                    c,
                    CheatSignatures.Severity.HIGH
                )
            } catch (_: Exception) {}
        }
    }

    // -------------------------------------------------------------------------
    // 6. Kernel residual (Magisk / KernelSU fully hidden)
    // -------------------------------------------------------------------------
    private fun scanKernelResiduals() {
        // prop
        val props = listOf(
            "ro.boot.verifiedbootstate",
            "ro.boot.flash.locked",
            "ro.boot.vbmeta.device_state",
            "ro.secure",
            "ro.debuggable"
        )
        for (p in props) {
            val v = runCmd("getprop $p").trim()
            if (p.contains("verifiedbootstate") && v != "green") {
                findings += CheatSignatures.Finding(
                    "Boot state tidak green",
                    "$p = $v",
                    CheatSignatures.Severity.MEDIUM
                )
            }
            if (p == "ro.debuggable" && v == "1") {
                findings += CheatSignatures.Finding(
                    "ro.debuggable=1",
                    "Device dalam mode debug",
                    CheatSignatures.Severity.LOW
                )
            }
        }

        // /data/adb still present
        if (File("/data/adb").exists()) {
            findings += CheatSignatures.Finding(
                "Folder /data/adb ada",
                "Indikasi Magisk/KernelSU (meski di-hide)",
                CheatSignatures.Severity.HIGH
            )
        }

        // kallsyms
        val kallsyms = readFile(File("/proc/kallsyms")) ?: ""
        for (ind in CheatSignatures.ROOT_INDICATORS) {
            if (kallsyms.contains(ind, ignoreCase = true)) {
                findings += CheatSignatures.Finding(
                    "Symbol kernel",
                    "kallsyms mengandung \"$ind\"",
                    CheatSignatures.Severity.HIGH
                )
            }
        }
    }

    // -------------------------------------------------------------------------
    // 7. Accessibility (script / auto aim)
    // -------------------------------------------------------------------------
    private fun scanAccessibility() {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? android.view.accessibility.AccessibilityManager
            ?: return
        val enabled = am.getEnabledAccessibilityServiceList(
            android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        for (svc in enabled) {
            val pkg = svc.resolveInfo.serviceInfo.packageName.lowercase()
            if (CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { pkg.contains(it) } ||
                pkg.contains("auto") || pkg.contains("clicker") || pkg.contains("macro")) {
                findings += CheatSignatures.Finding(
                    "Accessibility mencurigakan",
                    pkg,
                    CheatSignatures.Severity.HIGH
                )
            }
        }
    }

    // -------------------------------------------------------------------------
    // 8. Shizuku / wireless ADB
    // -------------------------------------------------------------------------
    private fun scanShizukuAndAdb() {
        val processes = runCmd("ps -A 2>/dev/null || ps 2>/dev/null")
        if (processes.contains("shizuku_server") || processes.contains("shizuku")) {
            findings += CheatSignatures.Finding(
                "Shizuku aktif",
                "shizuku_server berjalan (bisa dipakai inject)",
                CheatSignatures.Severity.HIGH
            )
        }
        if (File("/data/local/tmp/shizuku_starter").exists() ||
            File("/data/local/tmp/shizuku").exists()) {
            findings += CheatSignatures.Finding(
                "Shizuku residual file",
                "/data/local/tmp/shizuku*",
                CheatSignatures.Severity.MEDIUM
            )
        }

        // wireless adb
        val adb = runCmd("getprop service.adb.tcp.port").trim()
        if (adb.isNotEmpty() && adb != "-1" && adb != "0") {
            findings += CheatSignatures.Finding(
                "Wireless ADB aktif",
                "service.adb.tcp.port = $adb",
                CheatSignatures.Severity.MEDIUM
            )
        }
    }

    // -------------------------------------------------------------------------
    // 9. Free Fire data residual (drip clean-exit)
    // -------------------------------------------------------------------------
    private fun scanFreeFireResiduals() {
        for (pkg in CheatSignatures.FF_PACKAGES) {
            val dataDir = File("/data/data/$pkg")
            if (!dataDir.exists()) continue

            // look for recent .bak / .tmp / suspicious names
            dataDir.walkTopDown().maxDepth(4).forEach { f ->
                if (!f.isFile) return@forEach
                val n = f.name.lowercase()
                if (n.endsWith(".bak") || n.endsWith(".tmp") || n.endsWith(".old") ||
                    n.contains("hook") || n.contains("inject") || n.contains("drip") ||
                    n.contains("mod") || n.contains("patch")) {
                    findings += CheatSignatures.Finding(
                        "Residual di data FF",
                        f.absolutePath,
                        CheatSignatures.Severity.HIGH
                    )
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private fun checkRoot(): Boolean {
        val paths = arrayOf(
            "/system/bin/su", "/system/xbin/su", "/sbin/su",
            "/data/local/su", "/data/local/bin/su"
        )
        if (paths.any { File(it).exists() }) return true
        return runCmd("which su 2>/dev/null").isNotBlank()
    }

    private fun readFile(f: File): String? {
        return try {
            if (f.exists() && f.canRead()) f.readText() else null
        } catch (_: Exception) {
            null
        }
    }

    private fun runCmd(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
            val out = BufferedReader(InputStreamReader(p.inputStream)).readText()
            p.waitFor()
            out
        } catch (_: Exception) {
            ""
        }
    }

    data class ScanResult(
        val isCheat: Boolean,
        val findings: List<CheatSignatures.Finding>,
        val rooted: Boolean,
        val timestamp: String
    )
}
