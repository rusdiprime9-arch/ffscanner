package com.azx.scanner

object CheatSignatures {

    // Free Fire package variants
    val FF_PACKAGES = listOf(
        "com.dts.freefireth",
        "com.dts.freefiremax",
        "com.garena.game.kgvn",
        "com.garena.game.kgid",
        "com.garena.game.kgtw",
        "com.garena.game.kgbr",
        "com.garena.game.kgth"
    )

    // Known cheat / injector package patterns (partial match)
    val CHEAT_PACKAGE_KEYWORDS = listOf(
        "ffh4x", "ffmax", "drip", "yonso", "yoonso", "aovcheat",
        "wallhack", "aimbot", "espclient", "ffcheat", "freefirehack",
        "il2cpp", "unityhook", "gameguardian", "cheatengine",
        "virtualxposed", "parallel", "dualspace", "island", "shelter"
    )

    // Strings that appear in /proc/*/maps when memory is patched
    val MAPS_STRINGS = listOf(
        "unity_hook", "il2cpp_hook", "mono_hook", "ff_hook",
        "ESP", "Aimbot", "WallHack", "NoRecoil", "SpeedHack",
        "DripClient", "FFMax", "Yonso", "AOV", "HookLib",
        "substrate", "frida", "xposed", "lsposed", "zygisk"
    )

    // Suspicious local ports used by injectors / proxies
    val SUSPICIOUS_PORTS = listOf(
        27042, 27043, 23946, 5555, 5037, 40318, 40319,
        8080, 8888, 9999, 1337, 31337, 4444, 12345
    )

    // Residual file name patterns inside Free Fire data
    val RESIDUAL_PATTERNS = listOf(
        "*.bak", "*.tmp", "*.old", "*hook*", "*inject*",
        "*drip*", "*ffh4x*", "*yonso*", "*mod*"
    )

    // Kernel / root indicators
    val ROOT_INDICATORS = listOf(
        "magisk", "kernelsu", "ksu", "zygisk", "riru",
        "supersu", "superuser", "daemonsu"
    )

    data class Finding(
        val title: String,
        val detail: String,
        val severity: Severity
    )

    enum class Severity { HIGH, MEDIUM, LOW, INFO }
}
