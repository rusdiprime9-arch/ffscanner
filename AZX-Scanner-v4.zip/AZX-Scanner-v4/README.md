# AZX Scanner v4.0

Free Fire Trace Engine — deteksi jejak cheat (memory, drip residual, virtual space, kernel, VPN/Shizuku).

## Fitur Deteksi

| Modul | Yang dicek |
|-------|------------|
| Package | keyword cheat, injector, virtual space |
| Filesystem | residual binary di /data/local/tmp, /data/adb, dll |
| /proc maps | string hook, anon executable, TracerPid |
| Network | VPN aktif, port injector/proxy |
| Virtual Space | multi-user, Parallel Space, Island, dll |
| Kernel | Magisk/KernelSU residual, kallsyms, prop |
| Accessibility | service auto-click / macro |
| Shizuku / ADB | process + residual file + wireless adb |
| FF Data | residual .bak/.tmp/hook di /data/data Free Fire |

## Build

```bash
git clone https://github.com/YOUR_USER/AZX-Scanner.git
cd AZX-Scanner
./gradlew assembleRelease
```

Output: `app/build/outputs/apk/release/app-release-unsigned.apk`

Sign sendiri dengan `apksigner` atau Android Studio.

## Catatan

- Butuh `QUERY_ALL_PACKAGES` untuk scan package list.
- Deteksi memory & residual paling akurat saat device **rooted** (atau Magisk).
- Non-root tetap jalan, tapi cakupan lebih terbatas.
- Hasil hanya dua status: **BERSIH** atau **CHEAT**.

## License

MIT — bebas dipakai, dimodifikasi, didistribusikan.
