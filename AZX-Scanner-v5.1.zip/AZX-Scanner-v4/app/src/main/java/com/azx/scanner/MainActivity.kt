package com.azx.scanner

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.azx.scanner.CheatSignatures.Severity
import com.azx.scanner.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var engine: ScannerEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        engine = ScannerEngine(this)

        binding.btnScan.setOnClickListener { startScan() }
        binding.btnBaseline.setOnClickListener { makeBaseline() }
    }

    /** Deteksi overlay: Android menandai sentuhan bila jendela kita tertutup jendela lain. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if ((ev.flags and MotionEvent.FLAG_WINDOW_IS_OBSCURED) != 0 ||
            (ev.flags and MotionEvent.FLAG_WINDOW_IS_PARTIALLY_OBSCURED) != 0) {
            engine.overlayObscuredSeen = true
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun startScan() {
        binding.btnScan.isEnabled = false
        binding.btnBaseline.isEnabled = false
        binding.tvStatus.text = "SCAN…"
        binding.tvStatus.setTextColor(Color.parseColor("#8B949E"))
        binding.tvDetail.text = "Memindai jejak cheat dan memverifikasi isi APK…\n" +
            "Bisa memakan 30-90 detik. Jika ada dialog izin root, pilih IZINKAN."

        lifecycleScope.launch {
            val result = engine.runFullScan()
            showResult(result)
            binding.btnScan.isEnabled = true
            binding.btnBaseline.isEnabled = true
        }
    }

    private fun showResult(result: ScannerEngine.ScanResult) {
        if (result.isCheat) {
            binding.tvStatus.text = "CHEAT"
            binding.tvStatus.setTextColor(Color.parseColor("#FF5252"))
        } else {
            binding.tvStatus.text = "BERSIH"
            binding.tvStatus.setTextColor(Color.parseColor("#00E676"))
        }

        val issues = result.findings.filter { it.severity != Severity.INFO }.sortedBy { it.severity.ordinal }
        val info = result.findings.filter { it.severity == Severity.INFO }

        val rootText = when {
            result.rooted && result.rootGranted -> "Ya (akses diberikan)"
            result.rooted -> "Ya (akses ditolak)"
            else -> "Tidak"
        }
        val sb = StringBuilder()
        sb.appendLine("Waktu   : ${result.timestamp}")
        sb.appendLine("Root    : $rootText")
        sb.appendLine("Cakupan : ${if (result.rootGranted) "PENUH (root)" else "TERBATAS (non-root)"}")
        sb.appendLine("Temuan  : ${issues.size}")
        sb.appendLine()

        if (issues.isEmpty()) {
            sb.appendLine("Tidak ada jejak cheat yang terdeteksi.")
            sb.appendLine()
        } else {
            issues.forEachIndexed { i, f ->
                sb.appendLine("[${i + 1}] ${f.severity} — ${f.title}")
                sb.appendLine("    ${f.detail.replace("\n", "\n    ")}")
                sb.appendLine()
            }
        }

        if (info.isNotEmpty()) {
            sb.appendLine("— Catatan verifikasi (bukan cheat) —")
            info.forEach {
                sb.appendLine("• ${it.title}")
                if (it.detail.isNotBlank()) sb.appendLine("    ${it.detail.replace("\n", "\n    ")}")
            }
        }

        binding.tvDetail.text = sb.toString()
    }

    /**
     * Membuat baseline dari Free Fire yang terpasang dari Play Store.
     * Ditolak otomatis bila FF tidak berasal dari Play Store.
     */
    private fun makeBaseline() {
        binding.btnScan.isEnabled = false
        binding.btnBaseline.isEnabled = false
        binding.tvDetail.text = "Membuat baseline dari Free Fire Play Store…\nBisa memakan 30-90 detik."

        lifecycleScope.launch {
            val files = ArrayList<File>()
            val errors = ArrayList<String>()
            withContext(Dispatchers.IO) {
                val installed = CheatSignatures.FF_PACKAGES.filter { isInstalled(it) }
                if (installed.isEmpty()) errors += "Free Fire resmi tidak terpasang."
                for (pkg in installed) {
                    try {
                        files += IntegrityScanner.exportBaseline(this@MainActivity, pkg)
                    } catch (e: Exception) {
                        errors += "$pkg: ${e.message}"
                    }
                }
            }

            val sb = StringBuilder()
            if (files.isNotEmpty()) {
                sb.appendLine("Baseline dibuat:")
                files.forEach { sb.appendLine("• ${it.name} (${it.length() / 1024} KB)") }
                sb.appendLine()
                sb.appendLine("Kirim file ini ke repo: taruh di app/src/main/assets/baselines/ lalu build ulang,")
                sb.appendLine("supaya semua HP bisa membandingkan FF mereka dengan FF Play Store versi tersebut.")
            }
            errors.forEach { sb.appendLine("✗ $it") }
            binding.tvDetail.text = sb.toString()

            if (files.isNotEmpty()) shareFiles(files)
            binding.btnScan.isEnabled = true
            binding.btnBaseline.isEnabled = true
        }
    }

    private fun shareFiles(files: List<File>) {
        try {
            val uris = ArrayList(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
            val intent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
            }
            intent.type = "application/json"
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Bagikan baseline"))
        } catch (e: Exception) {
            binding.tvDetail.append("\nGagal membuka menu bagikan: ${e.message}")
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }
}
