package com.azx.scanner

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import android.provider.Settings
import com.azx.scanner.CheatSignatures.Finding
import com.azx.scanner.CheatSignatures.Severity
import java.io.File
import java.net.NetworkInterface
import java.security.KeyStore
import java.util.zip.ZipFile

/**
 * Deteksi cheat yang bekerja lewat proxy/VPN (contoh: BAGASXIT PROXY).
 *
 * Kenapa cheat ini lolos dari v5:
 *  1. Ia memakai VpnService PER-APLIKASI (hanya Free Fire yang diarahkan). VPN seperti itu
 *     tidak terlihat oleh app lain lewat ConnectivityManager.allNetworks, jadi cek TRANSPORT_VPN
 *     di v5 tidak melihat apa pun.
 *  2. Isi APK-nya dibungkus packer (dex asli terenkripsi di assets, dimuat dari memori),
 *     nama package/lib acak, sehingga cek nama package saja tidak cukup.
 *
 * Strategi v5.1: korelasi banyak sinyal, bukan satu sinyal.
 *  - Statis (non-root): app yang punya service BIND_VPN_SERVICE dibedah isi APK-nya.
 *  - Jaringan (non-root, best effort): interface tun*, proxy sistem, CA pengguna.
 *  - Root: pemilik VPN (dumpsys), aturan routing per-UID, koneksi proses Free Fire.
 *  - Overlay: jendela lain menutupi scanner saat dipakai.
 */
class ProxyVpnScanner(
    private val context: Context,
    private val rootGranted: Boolean,
    private val overlayObscured: Boolean,
    private val su: (String) -> String?
) {
    private val out = mutableListOf<Finding>()
    private val pm = context.packageManager

    private class Candidate(val pkg: String, val score: Int, val reasons: List<String>, val known: Boolean)

    private val candidates = mutableListOf<Candidate>()

    fun scan(): List<Finding> {
        scanVpnCapablePackages()
        val tun = tunInterfaces()
        scanProxySettings()
        scanUserCa()
        scanActiveVpn(tun)
        if (rootGranted) scanRootNetwork()
        correlate(tun)
        return out
    }

    private fun add(title: String, detail: String, sev: Severity) {
        out += Finding(title, detail, sev)
    }

    // -------------------------------------------------------------------------
    // A. App yang BISA menjadi VPN (service BIND_VPN_SERVICE) + bedah isi APK
    // -------------------------------------------------------------------------
    private fun scanVpnCapablePackages() {
        @Suppress("DEPRECATION")
        val pkgs: List<PackageInfo> = pm.getInstalledPackages(
            PackageManager.GET_SERVICES or PackageManager.GET_PERMISSIONS
        )
        for (p in pkgs) {
            if (p.packageName == context.packageName) continue
            val ai = p.applicationInfo ?: continue
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (isSystem) continue

            val name = p.packageName
            val knownByName = CheatSignatures.KNOWN_CHEAT_PACKAGES.contains(name) ||
                CheatSignatures.CHEAT_PACKAGE_KEYWORDS.any { name.lowercase().contains(it) }
            val hasVpnService = p.services?.any { it.permission == "android.permission.BIND_VPN_SERVICE" } == true
            if (!hasVpnService && !knownByName) continue

            val reasons = mutableListOf<String>()
            var score = 0
            var known = knownByName
            if (knownByName) reasons += "nama package cocok sampel cheat"
            if (hasVpnService) reasons += "punya VpnService"

            val perms = p.requestedPermissions?.toSet() ?: emptySet()
            if ("android.permission.SYSTEM_ALERT_WINDOW" in perms) { score += 1; reasons += "izin overlay (menu melayang)" }
            if ("android.permission.QUERY_ALL_PACKAGES" in perms) { score += 1; reasons += "membaca daftar semua app" }

            val installer = installerOf(name)
            if (installer != "com.android.vending") { score += 1; reasons += "bukan dari Play Store (${installer ?: "sideload"})" }

            val factory = appComponentFactoryOf(ai)
            if (factory != null && !factory.startsWith("androidx.") && !factory.startsWith("android.")) {
                score += 1; reasons += "appComponentFactory khusus: $factory"
            }

            val apk = analyzeApk(ai.sourceDir)
            if (apk.knownString) { known = true; reasons += "string sampel cheat di dalam APK" }
            if (apk.packer.isNotEmpty()) { score += 3; reasons += "packer/shell: ${apk.packer.joinToString()}" }
            if (apk.tunnel.isNotEmpty()) { score += 2; reasons += "native tunnel: ${apk.tunnel.joinToString()}" }
            if (apk.hiddenNestedApk) { score += 1; reasons += "APK/ZIP tersembunyi di assets tanpa ekstensi" }
            if (apk.nonAsciiEntries >= 5) { score += 1; reasons += "${apk.nonAsciiEntries} entri APK bernama karakter aneh (obfuscation)" }
            if (apk.tinyDexBigNative) { score += 1; reasons += "dex kecil + lib native besar (kulit packer)" }

            if (name in CheatSignatures.LEGIT_VPN_PACKAGES && apk.packer.isEmpty() && !known) score -= 3

            candidates += Candidate(name, score, reasons, known)

            val label = try { pm.getApplicationLabel(ai).toString() } catch (e: Exception) { name }
            val detail = "$label ($name)\n" + reasons.joinToString("\n") { "- $it" }
            when {
                known -> add("Cheat proxy/VPN dikenali", detail, Severity.HIGH)
                score >= 5 -> add("App VPN sangat mencurigakan (pola cheat proxy)", detail, Severity.HIGH)
                score >= 2 -> add("App VPN mencurigakan", detail, Severity.MEDIUM)
                score >= 0 && hasVpnService -> add("App VPN terpasang", "$label ($name)", Severity.LOW)
            }
        }
    }

    private class ApkTraits(
        val knownString: Boolean,
        val packer: List<String>,
        val tunnel: List<String>,
        val hiddenNestedApk: Boolean,
        val nonAsciiEntries: Int,
        val tinyDexBigNative: Boolean
    )

    private fun analyzeApk(path: String?): ApkTraits {
        val packer = linkedSetOf<String>()
        val tunnel = linkedSetOf<String>()
        var known = false
        var nested = false
        var nonAscii = 0
        var dexSize = 0L
        var nativeSize = 0L
        if (path == null) return ApkTraits(false, emptyList(), emptyList(), false, 0, false)
        try {
            ZipFile(path).use { z ->
                val en = z.entries()
                while (en.hasMoreElements()) {
                    val e = en.nextElement()
                    val n = e.name
                    if (n.any { it.code > 0x7E }) nonAscii++
                    if (e.isDirectory) continue
                    if (n.startsWith("assets/ondev/")) packer += "assets/ondev/"

                    when {
                        n == "AndroidManifest.xml" && e.size in 1..2_000_000 -> {
                            val b = z.getInputStream(e).use { it.readBytes() }
                            for (k in CheatSignatures.KNOWN_CHEAT_STRINGS) {
                                if (indexOf(b, k.toByteArray(Charsets.UTF_16LE)) >= 0 ||
                                    indexOf(b, k.toByteArray(Charsets.UTF_8)) >= 0) known = true
                            }
                        }
                        n.startsWith("classes") && n.endsWith(".dex") && e.size in 1..12_000_000 -> {
                            dexSize += e.size
                            val b = z.getInputStream(e).use { it.readBytes() }
                            for (m in CheatSignatures.PACKER_MARKERS) if (indexOf(b, m.toByteArray()) >= 0) packer += m
                            for (k in CheatSignatures.KNOWN_CHEAT_STRINGS) if (indexOf(b, k.toByteArray()) >= 0) known = true
                        }
                        n.startsWith("lib/") && n.endsWith(".so") && e.size in 1..6_000_000 -> {
                            nativeSize += e.size
                            val b = z.getInputStream(e).use { it.readBytes() }
                            for (m in CheatSignatures.TUNNEL_NATIVE_MARKERS) if (indexOf(b, m.toByteArray()) >= 0) tunnel += m
                            for (m in CheatSignatures.PACKER_MARKERS) if (indexOf(b, m.toByteArray()) >= 0) packer += m
                        }
                        n.startsWith("assets/") && !n.substringAfterLast('/').contains('.') && e.size in 4096..40_000_000 -> {
                            val h = ByteArray(4)
                            val r = z.getInputStream(e).use { it.read(h) }
                            if (r == 4 && h[0] == 'P'.code.toByte() && h[1] == 'K'.code.toByte() &&
                                h[2] == 3.toByte() && h[3] == 4.toByte()) nested = true
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // APK tidak terbaca: abaikan, sinyal lain tetap dipakai
        }
        return ApkTraits(known, packer.toList(), tunnel.toList(), nested, nonAscii, dexSize in 1..200_000 && nativeSize > 3_000_000)
    }

    private fun indexOf(hay: ByteArray, needle: ByteArray): Int {
        if (needle.isEmpty() || hay.size < needle.size) return -1
        val first = needle[0]
        val last = hay.size - needle.size
        var i = 0
        while (i <= last) {
            if (hay[i] == first) {
                var j = 1
                while (j < needle.size && hay[i + j] == needle[j]) j++
                if (j == needle.size) return i
            }
            i++
        }
        return -1
    }

    private fun installerOf(pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    private fun appComponentFactoryOf(ai: ApplicationInfo): String? = try {
        ApplicationInfo::class.java.getField("appComponentFactory").get(ai) as? String
    } catch (e: Throwable) {
        null
    }

    // -------------------------------------------------------------------------
    // B. Jaringan: interface tun, proxy sistem, CA pengguna
    // -------------------------------------------------------------------------
    private fun tunInterfaces(): List<String> {
        val names = linkedSetOf<String>()
        try {
            NetworkInterface.getNetworkInterfaces()?.toList()?.forEach { if (it.isUp) names += it.name }
        } catch (e: Exception) { }
        try {
            File("/sys/class/net").list()?.forEach { names += it }
        } catch (e: Exception) { }
        return names.filter { CheatSignatures.VPN_IFACE_REGEX.containsMatchIn(it) }
    }

    private fun scanProxySettings() {
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val px = cm.defaultProxy
            if (px != null && !px.host.isNullOrBlank()) {
                add("Proxy sistem aktif", "Proxy ${px.host}:${px.port}. Proxy HTTP di Wi-Fi/APN bisa dipakai untuk memanipulasi trafik game.", Severity.MEDIUM)
            }
        } catch (e: Exception) { }
        try {
            val g = Settings.Global.getString(context.contentResolver, "http_proxy")
            if (!g.isNullOrBlank() && g != ":0") add("Setelan http_proxy global terisi", g, Severity.MEDIUM)
        } catch (e: Exception) { }
    }

    private fun scanUserCa() {
        try {
            val ks = KeyStore.getInstance("AndroidCAStore")
            ks.load(null)
            val n = ks.aliases().toList().count { it.startsWith("user:") }
            if (n > 0) add("Sertifikat CA pengguna terpasang ($n)", "Dibutuhkan proxy yang membuka trafik HTTPS. Bisa juga sah (mis. alat debug).", Severity.LOW)
        } catch (e: Exception) { }
    }

    private fun scanActiveVpn(tun: List<String>) {
        var visibleVpn = false
        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            for (n in cm.allNetworks) {
                val c = cm.getNetworkCapabilities(n) ?: continue
                if (c.hasTransport(android.net.NetworkCapabilities.TRANSPORT_VPN)) visibleVpn = true
            }
        } catch (e: Exception) { }

        if (tun.isNotEmpty() && !visibleVpn) {
            add(
                "VPN per-aplikasi tersembunyi",
                "Interface ${tun.joinToString()} ada, tetapi Android tidak menampilkan jaringan VPN ke scanner. " +
                    "Ini pola VPN yang hanya mengarahkan app tertentu (mis. Free Fire) dan sengaja tidak mencakup app lain.",
                Severity.MEDIUM
            )
        } else if (tun.isNotEmpty()) {
            add("Interface VPN aktif", tun.joinToString(), Severity.LOW)
        }
    }

    // -------------------------------------------------------------------------
    // C. Root: pemilik VPN, routing per-UID, koneksi proses Free Fire
    // -------------------------------------------------------------------------
    private fun scanRootNetwork() {
        // 1. Siapa pemilik VPN aktif
        val dump = su("dumpsys connectivity 2>/dev/null | grep -iE 'vpn|tun[0-9]' | head -60") ?: ""
        if (dump.isNotBlank()) {
            val owners = candidates.map { it.pkg }.filter { dump.contains(it) }
            for (o in owners) {
                val c = candidates.first { it.pkg == o }
                val sev = when {
                    c.known || c.score >= 5 -> Severity.HIGH
                    c.score >= 2 -> Severity.MEDIUM
                    else -> Severity.LOW
                }
                add("VPN aktif dimiliki $o", "Terkonfirmasi lewat dumpsys connectivity (root).", sev)
            }
            if (owners.isEmpty() && Regex("(?i)vpn").containsMatchIn(dump)) {
                add("VPN aktif (pemilik tidak dikenali)", dump.lines().take(6).joinToString("\n"), Severity.LOW)
            }
        }

        // 2. Apakah Free Fire diarahkan ke interface VPN (per UID)
        val ffUids = CheatSignatures.FF_PACKAGES.mapNotNull {
            try { it to pm.getApplicationInfo(it, 0).uid } catch (e: Exception) { null }
        }
        if (ffUids.isEmpty()) return

        val rules = su("ip rule 2>/dev/null") ?: ""
        for (line in rules.lines()) {
            val m = Regex("uidrange\\s+(\\d+)-(\\d+).*?lookup\\s+(\\S+)").find(line) ?: continue
            val lo = m.groupValues[1].toLong()
            val hi = m.groupValues[2].toLong()
            val table = m.groupValues[3]
            if (!CheatSignatures.VPN_IFACE_REGEX.containsMatchIn(table)) continue
            for ((pkg, uid) in ffUids) {
                if (uid.toLong() in lo..hi) {
                    val narrow = (hi - lo) <= 2
                    add(
                        "Trafik $pkg diarahkan ke VPN",
                        "Aturan routing UID $lo-$hi -> $table." +
                            if (narrow) "\nHanya app ini yang diarahkan (per-app VPN): pola khas cheat proxy." else "",
                        if (narrow) Severity.MEDIUM else Severity.LOW
                    )
                }
            }
        }

        // 3. Koneksi nyata proses Free Fire lewat IP tun
        val addr = su("ip -o addr show 2>/dev/null") ?: ""
        val tunIps = Regex("(?m)^\\d+:\\s+(tun|ppp|wg|tap)\\d*\\s+inet6?\\s+([0-9a-fA-F:.]+)").findAll(addr)
            .map { it.groupValues[2] }.toList()
        if (tunIps.isNotEmpty()) {
            val ss = su("ss -tanp 2>/dev/null") ?: ""
            for ((pkg, _) in ffUids) {
                val hit = ss.lines().firstOrNull { l -> l.contains(pkg) && tunIps.any { l.contains(it) } }
                if (hit != null) {
                    add("Koneksi $pkg keluar lewat IP tunnel", hit.trim().take(160), Severity.MEDIUM)
                }
            }
        }
    }

    // -------------------------------------------------------------------------
    // D. Korelasi: gabungkan sinyal lemah menjadi bukti kuat
    // -------------------------------------------------------------------------
    private fun correlate(tun: List<String>) {
        val top = candidates.maxByOrNull { it.score }
        val suspicious = top != null && (top.known || top.score >= 3)

        if (suspicious && tun.isNotEmpty()) {
            add(
                "Korelasi: VPN aktif + app VPN mencurigakan",
                "Interface ${tun.joinToString()} aktif dan ${top!!.pkg} (skor ${top.score}) terpasang. " +
                    "Kombinasi ini bukan kebetulan VPN biasa.",
                Severity.HIGH
            )
        }
        if (overlayObscured) {
            val sev = if (suspicious) Severity.HIGH else Severity.MEDIUM
            add(
                "Jendela overlay menutupi scanner",
                "Saat scanner dipakai ada jendela lain di atasnya (menu melayang). " +
                    if (suspicious) "Bersamaan dengan app VPN mencurigakan: menu cheat melayang." else
                        "Bisa sah (gelembung chat, perekam layar), tetapi menu cheat juga memakai teknik ini.",
                sev
            )
        }
    }
}
