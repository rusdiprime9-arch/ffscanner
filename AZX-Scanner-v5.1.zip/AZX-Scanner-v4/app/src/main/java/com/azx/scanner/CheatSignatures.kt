package com.azx.scanner

object CheatSignatures {

    // Free Fire package variants (resmi)
    val FF_PACKAGES = listOf(
        "com.dts.freefireth",
        "com.dts.freefiremax",
        "com.garena.game.kgvn",
        "com.garena.game.kgid",
        "com.garena.game.kgtw",
        "com.garena.game.kgbr",
        "com.garena.game.kgth"
    )

    // Nama paket yang SPESIFIK cheat/injector (partial match) -> HIGH
    val CHEAT_PACKAGE_KEYWORDS = listOf(
        "ffh4x", "ffmax", "dripclient", "yonso", "yoonso", "aovcheat",
        "wallhack", "aimbot", "espclient", "ffcheat", "freefirehack",
        "unityhook", "gameguardian", "cheatengine", "virtualxposed",
        "bagasxit", "paramod"
    )

    // Kata ambigu: bisa aplikasi sah -> hanya MEDIUM
    val AMBIGUOUS_PACKAGE_KEYWORDS = listOf(
        "il2cpp", "parallel", "dualspace", "island", "shelter"
    )

    // Aplikasi container / virtual space
    val CONTAINER_PACKAGES_HIGH = listOf(
        "com.lody.virtual", "com.parallel.space", "com.cloneapp.parallelspace",
        "com.excelliance.multiaccounts", "info.cloneapp.mochat.inclone", "com.dualspace"
    )
    val CONTAINER_PACKAGES_MEDIUM = listOf("com.oasisfeng.island")

    // Aplikasi manajer root (hanya indikator keberadaan root)
    val ROOT_MANAGER_PACKAGES = listOf(
        "com.topjohnwu.magisk", "me.weishu.kernelsu", "me.bmax.apatch",
        "io.github.vvb2060.magisk", "io.github.huskydg.magisk"
    )

    // Toko aplikasi resmi selain Play Store
    val ALT_STORES = setOf(
        "com.sec.android.app.samsungapps", "com.huawei.appmarket",
        "com.xiaomi.mipicks", "com.heytap.market", "com.vivo.appstore",
        "com.amazon.venezia"
    )

    // Token nama library di /proc/PID/maps (dicocokkan ke NAMA FILE, bukan seluruh teks maps)
    // token <= 3 huruf harus sama persis dengan satu kata di nama file
    val MAPS_STRINGS = listOf(
        "unity_hook", "il2cpp_hook", "mono_hook", "ff_hook",
        "esp", "aimbot", "wallhack", "norecoil", "speedhack",
        "dripclient", "ffmax", "yonso", "aov", "hooklib",
        "substrate", "frida", "xposed", "lsposed", "zygisk"
    )

    // Port: Frida = pasti injector; sisanya hanya petunjuk
    val HIGH_PORTS = listOf(27042, 27043)
    val MEDIUM_PORTS = listOf(23946, 40318, 40319, 31337, 1337, 4444)
    val LOW_PORTS = listOf(5555, 5037, 8080, 8888, 9999, 12345)
    val SUSPICIOUS_PORTS = HIGH_PORTS + MEDIUM_PORTS + LOW_PORTS

    // Nama file residual di data Free Fire yang spesifik (tanpa "mod"/"patch": terlalu umum)
    val RESIDUAL_TOKENS = listOf("hook", "inject", "drip", "ffh4x", "yonso")
    val RESIDUAL_PATTERNS = listOf(
        "*.bak", "*.tmp", "*.old", "*hook*", "*inject*",
        "*drip*", "*ffh4x*", "*yonso*"
    )

    // Kernel / root indicators
    val ROOT_INDICATORS = listOf(
        "magisk", "kernelsu", "ksu", "zygisk", "riru",
        "supersu", "superuser", "daemonsu"
    )


    // ---- Cheat berbasis proxy/VPN (v5.1) ----
    // Paket / string yang terbukti dari sampel BAGASXIT_PROXY_V13_FIX_APK (HIGH)
    val KNOWN_CHEAT_PACKAGES = listOf("com.bagasxit.proxy")
    val KNOWN_CHEAT_STRINGS = listOf("bagasxit", "com.paramod", "com/paramod")

    // Penanda packer/shell yang membungkus dex asli (dex dienkripsi di assets, dimuat di memori)
    val PACKER_MARKERS = listOf(
        "on/dev/shellv3", "OnDevBootV3", "OnDevShellV3", "libondevx",
        "assets/ondev/", "com.ano.gshell", "cloudinject"
    )

    // Penanda native tunnel (tun2socks) di dalam .so
    val TUNNEL_NATIVE_MARKERS = listOf(
        "hev_socks5", "hev-socks5", "tun2socks", "tun2http", "badvpn"
    )

    // VPN sah yang umum (mengurangi false positive; BUKAN pengecualian bila ada penanda packer)
    val LEGIT_VPN_PACKAGES = setOf(
        "org.wireguard.android", "de.blinkt.openvpn", "net.openvpn.openvpn",
        "com.cloudflare.onedotonedotonedotone", "com.nordvpn.android",
        "com.expressvpn.vpn", "ch.protonvpn.android", "com.surfshark.vpnclient.android",
        "com.google.android.apps.subscriptions.red", "net.mullvad.mullvadvpn",
        "com.v2ray.ang", "app.intra", "org.torproject.android"
    )

    val VPN_IFACE_REGEX = Regex("^(tun|ppp|wg|tap)\\d*")

    data class Finding(
        val title: String,
        val detail: String,
        val severity: Severity
    )

    enum class Severity { HIGH, MEDIUM, LOW, INFO }
}
