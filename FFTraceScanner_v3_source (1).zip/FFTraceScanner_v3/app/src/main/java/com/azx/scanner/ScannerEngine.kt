package com.azx.scanner

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit

/**
 * Scanner 10 layer.
 * Output bahasa sederhana + klasifikasi jenis cheat.
 */
class ScannerEngine(private val ctx: Context) {

    private val sb = StringBuilder()
    private var rootAvailable = false
    private val findings = mutableListOf<CheatSignatures.Finding>()

    fun runFullScan(onProgress: (String) -> Unit = {}): String {
        sb.clear()
        findings.clear()
        rootAvailable = checkSu()

        header()
        onProgress("1/11 Cek aplikasi…")
        scanPackages()
        onProgress("2/11 Cek file…")
        scanFilesystem()
        onProgress("3/11 Cek memori proses…")
        scanProcMapsMounts()
        onProgress("4/11 Cek root / sistem…")
        scanKernelSelinuxProp()
        onProgress("5/11 Cek keaslian APK Free Fire…")
        scanFfApkIntegrity()
        onProgress("6/11 Cek proses berjalan…")
        scanProcesses()
        onProgress("7/11 Cek file tersembunyi…")
        scanHiddenBinaries()
        onProgress("8/11 Cek layanan aksesibilitas…")
        scanAccessibilityOverlay()
        onProgress("9/11 Cek port jaringan…")
        scanNetworkSockets()
        onProgress("10/11 Cek jejak MT Manager…")
        scanMtManagerTraces()
        onProgress("11/11 Cek panel tersembunyi…")
        scanHiddenPanels()

        footer()
        return sb.toString()
    }

    // ── helpers ──────────────────────────────────────────────

    private fun line(s: String) { sb.appendLine(s) }
    private fun info(s: String) { line("    ·  $s") }
    private fun ok(s: String) { line("    OK $s") }

    private fun section(t: String) {
        val num = when {
            t.contains("Aplikasi") -> 1
            t.contains("File di") -> 2
            t.contains("Memori") || t.contains("/proc") -> 3
            t.contains("Root") && t.contains("sistem") -> 4
            t.contains("Keaslian") || t.contains("APK Free Fire") -> 5
            t.contains("Proses") -> 6
            t.contains("Binary") || (t.contains("tersembunyi") && t.contains("Panel").not()) -> 7
            t.contains("aksesibilitas") || t.contains("overlay") || t.contains("Layanan") -> 8
            t.contains("Port") || t.contains("jaringan") -> 9
            t.contains("MT Manager") -> 10
            t.contains("Panel") -> 11
            else -> 0
        }
        val title = t.replace(Regex("^\\d+\\.\\s*"), "").trim()
        line("")
        line("  ────────────────────────────────")
        line("  [$num] $title")
        line("  ────────────────────────────────")
    }

    private fun severityOf(kind: CheatSignatures.Kind): String = when (kind) {
        CheatSignatures.Kind.INJECTOR,
        CheatSignatures.Kind.PATCHED_APK,
        CheatSignatures.Kind.MOD_MENU -> "TINGGI"
        CheatSignatures.Kind.MEMORY_EDITOR,
        CheatSignatures.Kind.PROXY,
        CheatSignatures.Kind.HOOK_FRAMEWORK,
        CheatSignatures.Kind.COPILOT -> "SEDANG"
        else -> "RENDAH"
    }

    private fun found(kind: CheatSignatures.Kind, detail: String, evidence: String = "") {
        findings += CheatSignatures.Finding(kind, detail, evidence)
        val sev = severityOf(kind)
        line("    [!] [$sev] ${kind.label}")
        line("        $detail")
        if (evidence.isNotBlank()) line("        bukti : $evidence")
    }

    private fun header() {
        val ts = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
            .format(java.util.Date())
        line("╔══════════════════════════════════════╗")
        line("║         AZX SCANNER  v3.0           ║")
        line("║     Laporan Analisis Jejak Cheat     ║")
        line("╚══════════════════════════════════════╝")
        line("")
        line("  Waktu      : $ts")
        line("  Perangkat  : ${Build.MANUFACTURER} ${Build.MODEL}")
        line("  Android    : API ${Build.VERSION.SDK_INT}")
        line("  Mode Root  : ${if (rootAvailable) "Aktif — scan mendalam" else "Tidak aktif — scan terbatas"}")
        line("")
        line("  Keterangan : Root / Magisk / KernelSU dicatat")
        line("               sebagai informasi, bukan temuan cheat.")
    }

    private fun footer() {
        line("")
        line("╔══════════════════════════════════════╗")
        line("║           RINGKASAN HASIL            ║")
        line("╚══════════════════════════════════════╝")
        line("")
        if (findings.isEmpty()) {
            line("  Status     : BERSIH")
            line("  Temuan     : 0")
            line("  Kesimpulan : Tidak ada jejak cheat yang terdeteksi")
            line("               pada perangkat ini.")
        } else {
            val byKind = findings.groupBy { it.kind }
            val high = findings.count { severityOf(it.kind) == "TINGGI" }
            val med = findings.count { severityOf(it.kind) == "SEDANG" }
            val low = findings.count { severityOf(it.kind) == "RENDAH" }

            line("  Status     : TERDETEKSI")
            line("  Total      : ${findings.size} temuan")
            line("  Tingkat    : TINGGI=$high  SEDANG=$med  RENDAH=$low")
            line("")
            line("  ── Klasifikasi ──────────────────────")
            byKind.entries.sortedByDescending { severityOf(it.key) }.forEach { (kind, list) ->
                line("")
                line("  ${kind.label}  (${list.size})  [${severityOf(kind)}]")
                line("  ${kind.contoh}")
                list.forEachIndexed { i, f ->
                    line("    ${i + 1}. ${f.detail}")
                    if (f.evidence.isNotBlank()) line("       bukti: ${f.evidence}")
                }
            }
            line("")
            line("  ── Risiko ───────────────────────────")
            line("  Akun / perangkat berpotensi terkena")
            line("  sanksi ACE (ban akun atau device ban).")
        }
        line("")
        line("────────────────────────────────────────")
        line("  Batasan: scan statis. Cheat memory-only")
        line("  atau rename total tanpa residual dapat")
        line("  tidak terdeteksi.")
        line("────────────────────────────────────────")
        line("  Laporan selesai.")
    }

    private fun checkSu(): Boolean {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor(3, TimeUnit.SECONDS)
            out.contains("uid=0")
        } catch (_: Exception) { false }
    }

    private fun su(cmd: String, timeoutSec: Long = 8): String {
        if (!rootAvailable) return ""
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor(timeoutSec, TimeUnit.SECONDS)
            out.trim()
        } catch (_: Exception) { "" }
    }

    private fun fileExists(path: String): Boolean = File(path).exists()

    private fun sha256(file: File): String? {
        return try {
            val md = MessageDigest.getInstance("SHA-256")
            FileInputStream(file).use { fis ->
                val buf = ByteArray(8192)
                var n: Int
                while (fis.read(buf).also { n = it } > 0) md.update(buf, 0, n)
            }
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (_: Exception) { null }
    }

    // ── 1. Package ───────────────────────────────────────────

    private fun scanPackages() {
        section("1. Aplikasi terpasang")
        val pm = ctx.packageManager
        var total = 0
        var cheatCount = 0

        try {
            val apps = if (Build.VERSION.SDK_INT >= 33) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
            total = apps.size
            for (ai in apps) {
                val pkg = ai.packageName
                val label = try { pm.getApplicationLabel(ai).toString() } catch (_: Exception) { pkg }

                when {
                    pkg in CheatSignatures.TOOL_PACKAGES ->
                        info("tool (bukan cheat): $pkg")
                    pkg in CheatSignatures.CHEAT_PACKAGES ||
                    CheatSignatures.CHEAT_NAME_REGEX.containsMatchIn(pkg) ||
                    CheatSignatures.CHEAT_NAME_REGEX.containsMatchIn(label) ||
                    CheatSignatures.PANEL_LABEL_REGEX.containsMatchIn("$pkg $label") -> {
                        val kind = CheatSignatures.classifyPackage(pkg, label)
                        found(kind, "$pkg ($label)")
                        cheatCount++
                    }
                }
            }
        } catch (e: Exception) {
            info("daftar aplikasi terbatas: ${e.message}")
        }

        info("total aplikasi dicek: $total")
        if (cheatCount == 0) ok("tidak ada aplikasi cheat")
    }

    // ── 2. Filesystem ────────────────────────────────────────

    private fun scanFilesystem() {
        section("2. File di penyimpanan")
        var any = false

        for (p in CheatSignatures.CHEAT_PATHS) {
            if (fileExists(p)) {
                found(CheatSignatures.classify(p), "file ditemukan: $p")
                any = true
            }
        }
        for (p in CheatSignatures.ROOT_INFO_PATHS) {
            if (fileExists(p)) info("root path (bukan cheat): $p")
        }

        if (rootAvailable) {
            val findCmd = """
                find /data/adb /data/local/tmp /data/misc /dev -type f \( \
                  -name '*frida*' -o -name '*dobby*' -o -name '*substrate*' \
                  -o -name '*gg*' -o -name '*gameguardian*' -o -name '*libgadget*' \
                  -o -name '*libhook*' -o -name '*libinject*' \
                \) 2>/dev/null | head -40
            """.trimIndent().replace("\n", " ")
            val deep = su(findCmd)
            if (deep.isNotBlank()) {
                deep.lines().filter { it.isNotBlank() }.forEach {
                    found(CheatSignatures.classify(it), "file injector: $it")
                    any = true
                }
            }
            val strCmd = """
                find /data/local/tmp /data/adb /dev /system/xbin /sbin -type f -executable 2>/dev/null | \
                while read f; do strings "$f" 2>/dev/null | grep -qiE 'frida|libdobby|lsPosed|GameGuardian|libgadget|libhook|libinject' && echo "$f"; done | head -20
            """.trimIndent().replace("\n", " ")
            val strHits = su(strCmd, 15)
            if (strHits.isNotBlank()) {
                strHits.lines().filter { it.isNotBlank() }.forEach {
                    found(CheatSignatures.classify(it), "binary berisi string cheat: $it")
                    any = true
                }
            }
        } else {
            info("scan file dalam butuh root")
        }
        if (!any) ok("tidak ada file cheat")
    }

    // ── 3. /proc maps ────────────────────────────────────────

    private fun scanProcMapsMounts() {
        section("3. Memori proses (/proc)")
        var any = false

        try {
            val maps = File("/proc/self/maps").readText()
            val hits = CheatSignatures.INJECTOR_STRINGS.filter { maps.contains(it, ignoreCase = true) }
            if (hits.isEmpty()) {
                ok("tidak ada injeksi di proses scanner")
            } else {
                hits.forEach {
                    found(CheatSignatures.classify(it), "string di maps: $it")
                    any = true
                }
            }
        } catch (e: Exception) {
            info("gagal baca maps: ${e.message}")
        }

        if (rootAvailable) {
            val mapsCmd = "grep -rE 'frida|dobby|lsposed|xposed|substrate|libgadget|libhook|libinject|gameguardian|modmenu' /proc/*/maps 2>/dev/null | head -30"
            val mapsOut = su(mapsCmd, 12)
            if (mapsOut.isNotBlank()) {
                mapsOut.lines().filter { it.isNotBlank() }.forEach {
                    found(CheatSignatures.classify(it), "injeksi di proses lain")
                    any = true
                }
            } else if (!any) {
                ok("tidak ada string cheat di maps proses")
            }

            val mountCmd = "cat /proc/1/mountinfo 2>/dev/null | grep -E 'magisk|zygisk|overlay|tmpfs.*adb' | head -10"
            val mountOut = su(mountCmd)
            if (mountOut.isNotBlank()) {
                mountOut.lines().filter { it.isNotBlank() }.forEach {
                    info("mount root-hide (bukan cheat): ${it.take(80)}")
                }
            }
        } else {
            info("scan maps proses lain butuh root")
        }
    }

    // ── 4. Kernel / prop ─────────────────────────────────────

    private fun scanKernelSelinuxProp() {
        section("4. Root & sistem (info)")

        val props = listOf("ro.debuggable", "ro.secure", "ro.build.tags", "ro.boot.verifiedbootstate")
        for (p in props) {
            val v = getProp(p)
            if (v.isNotBlank()) info("$p = $v")
        }

        if (rootAvailable) {
            val lsmod = su("lsmod 2>/dev/null | grep -iE 'magisk|ksu|apatch|zygisk|hide|dobby|frida'")
            if (lsmod.isNotBlank()) {
                lsmod.lines().filter { it.isNotBlank() }.forEach {
                    info("modul kernel (bukan cheat otomatis): ${it.take(60)}")
                }
            }
        }
    }

    private fun getProp(name: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("getprop", name))
            p.inputStream.bufferedReader().readText().trim()
        } catch (_: Exception) { "" }
    }

    // ── 5. FF integrity ──────────────────────────────────────

    private fun scanFfApkIntegrity() {
        section("5. Keaslian APK Free Fire")
        val pm = ctx.packageManager
        var checked = 0

        for (pkg in CheatSignatures.FF_OFFICIAL) {
            try {
                val ai = if (Build.VERSION.SDK_INT >= 33) {
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getApplicationInfo(pkg, 0)
                }
                val src = ai.sourceDir ?: continue
                val apk = File(src)
                if (!apk.exists()) continue
                checked++

                val sha = sha256(apk)
                info("$pkg")
                info("  ukuran: ${apk.length()} byte")
                info("  SHA-256: ${sha ?: "n/a"}")

                val certs = getApkCerts(src)
                if (certs.isEmpty()) {
                    found(CheatSignatures.Kind.PATCHED_APK, "$pkg: sertifikat tidak terbaca")
                } else {
                    certs.forEachIndexed { i, c ->
                        info("  cert[$i]: ${c.subjectDN}")
                        val dn = c.subjectDN.toString().lowercase()
                        if (dn.contains("android debug") || dn.contains("testkey") ||
                            dn.contains("unknown") || dn.contains("mod")) {
                            found(
                                CheatSignatures.Kind.PATCHED_APK,
                                "$pkg: sertifikat mencurigakan (kemungkinan di-sign ulang)",
                                c.subjectDN.toString()
                            )
                        }
                    }
                }
                if (src.contains(".mod") || src.contains("ffmod")) {
                    found(CheatSignatures.Kind.PATCHED_APK, "$pkg: path mengandung indikator mod")
                }
            } catch (_: PackageManager.NameNotFoundException) {
                // not installed
            } catch (e: Exception) {
                info("$pkg error: ${e.message}")
            }
        }

        if (checked == 0) info("Free Fire tidak terpasang — dilewati")
        else info("bandingkan SHA-256 dengan build resmi untuk kepastian penuh")
    }

    private fun getApkCerts(apkPath: String): List<X509Certificate> {
        return try {
            val pm = ctx.packageManager
            val flags = if (Build.VERSION.SDK_INT >= 28) {
                PackageManager.GET_SIGNING_CERTIFICATES
            } else {
                @Suppress("DEPRECATION")
                PackageManager.GET_SIGNATURES
            }
            val pkgInfo = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageArchiveInfo(apkPath, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageArchiveInfo(apkPath, flags)
            } ?: return emptyList()

            val result = mutableListOf<X509Certificate>()
            if (Build.VERSION.SDK_INT >= 28) {
                val si = pkgInfo.signingInfo ?: return emptyList()
                val sigs = if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
                for (s in sigs) {
                    val cf = CertificateFactory.getInstance("X.509")
                    result += cf.generateCertificate(s.toByteArray().inputStream()) as X509Certificate
                }
            } else {
                @Suppress("DEPRECATION")
                for (s in pkgInfo.signatures ?: emptyArray()) {
                    val cf = CertificateFactory.getInstance("X.509")
                    result += cf.generateCertificate(s.toByteArray().inputStream()) as X509Certificate
                }
            }
            result
        } catch (_: Exception) { emptyList() }
    }

    // ── 6. Process ───────────────────────────────────────────

    private fun scanProcesses() {
        section("6. Proses yang berjalan")
        var any = false

        if (!rootAvailable) {
            info("scan proses dalam butuh root")
            try {
                val p = Runtime.getRuntime().exec(arrayOf("ps", "-A"))
                val out = p.inputStream.bufferedReader().readText()
                out.lines().filter { CheatSignatures.CHEAT_PROCESS_REGEX.containsMatchIn(it) }
                    .forEach {
                        found(CheatSignatures.classify(it), "proses: ${it.trim().take(80)}")
                        any = true
                    }
            } catch (_: Exception) { info("ps tidak tersedia") }
            if (!any) ok("tidak ada proses cheat (mode non-root)")
            return
        }

        val psCmd = "ps -A -o PID,USER,NAME,ARGS 2>/dev/null | grep -iE 'frida|gg|gameguardian|cheat|hack|modmenu|injector|dobby|lsposed|xposed|riru|substrate|proxy|copilot|mitm'"
        val out = su(psCmd)
        if (out.isBlank()) {
            ok("tidak ada proses cheat")
        } else {
            out.lines().filter { it.isNotBlank() }.forEach {
                found(CheatSignatures.classify(it), "proses: ${it.trim().take(80)}")
            }
        }
    }

    // ── 7. Hidden binary ─────────────────────────────────────

    private fun scanHiddenBinaries() {
        section("7. Binary tersembunyi / diganti nama")
        if (!rootAvailable) {
            info("butuh root")
            return
        }
        val cmd = """
            find /data/local/tmp /data/adb /dev /system/xbin /sbin -type f -executable 2>/dev/null | \
            while read f; do
              strings "$f" 2>/dev/null | grep -qiE 'frida|libdobby|lsPosed|GameGuardian|libgadget|libhook|libinject' && echo "$f"
            done | head -20
        """.trimIndent().replace("\n", " ")
        val out = su(cmd, 15)
        if (out.isBlank()) {
            ok("tidak ada binary injector tersembunyi")
        } else {
            out.lines().filter { it.isNotBlank() }.forEach {
                found(CheatSignatures.classify(it), "binary tersembunyi: $it")
            }
        }
    }

    // ── 8. Accessibility / overlay ───────────────────────────

    private fun scanAccessibilityOverlay() {
        section("8. Layanan aksesibilitas / overlay")
        val pm = ctx.packageManager
        var hit = false
        try {
            val services = if (Build.VERSION.SDK_INT >= 33) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_SERVICES.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(PackageManager.GET_SERVICES)
            }
            for (pi in services) {
                val svcs = pi.services ?: continue
                for (s in svcs) {
                    val name = (s.name + " " + (s.permission ?: "")).lowercase()
                    if (CheatSignatures.SUSPICIOUS_SERVICES.any { name.contains(it) } &&
                        CheatSignatures.CHEAT_NAME_REGEX.containsMatchIn(pi.packageName + name)) {
                        val kind = when {
                            name.contains("copilot") || name.contains("auto") -> CheatSignatures.Kind.COPILOT
                            name.contains("overlay") || name.contains("floating") || name.contains("modmenu") -> CheatSignatures.Kind.MOD_MENU
                            else -> CheatSignatures.Kind.COPILOT
                        }
                        found(kind, "layanan: ${pi.packageName}/${s.name}")
                        hit = true
                    }
                }
            }
            if (!hit) ok("tidak ada layanan mencurigakan")
        } catch (e: Exception) {
            info("error enum service: ${e.message}")
        }
    }

    // ── 9. Network ports ─────────────────────────────────────

    private fun scanNetworkSockets() {
        section("9. Port jaringan (injector / proxy)")
        val ports = listOf(
            27042 to CheatSignatures.Kind.INJECTOR,  // frida
            27043 to CheatSignatures.Kind.INJECTOR,
            23946 to CheatSignatures.Kind.MEMORY_EDITOR, // GG
            7912 to CheatSignatures.Kind.PROXY,
            4444 to CheatSignatures.Kind.PROXY,
            5555 to CheatSignatures.Kind.PROXY,
            8888 to CheatSignatures.Kind.PROXY,
            8080 to CheatSignatures.Kind.PROXY,
            8889 to CheatSignatures.Kind.PROXY,
            9999 to CheatSignatures.Kind.PROXY
        )
        var hit = false

        if (rootAvailable) {
            val out = su("ss -ltnp 2>/dev/null || netstat -ltnp 2>/dev/null")
            for ((port, kind) in ports) {
                if (out.contains(":$port")) {
                    found(kind, "port $port sedang listen")
                    hit = true
                }
            }
            out.lines().filter { CheatSignatures.CHEAT_PROCESS_REGEX.containsMatchIn(it) }
                .forEach {
                    found(CheatSignatures.classify(it), "socket: ${it.take(80)}")
                    hit = true
                }
        } else {
            try {
                val tcp = File("/proc/net/tcp").readText() + runCatching { File("/proc/net/tcp6").readText() }.getOrDefault("")
                for ((port, kind) in ports) {
                    val hex = "%04X".format(port)
                    if (tcp.contains(hex)) {
                        found(kind, "kemungkinan port $port aktif")
                        hit = true
                    }
                }
            } catch (_: Exception) {
                info("scan port terbatas tanpa root")
            }
        }
        if (!hit) ok("tidak ada port injector/proxy aktif")
    }

    // ── 10. MT Manager traces ────────────────────────────────

    private fun scanMtManagerTraces() {
        section("10. Jejak MT Manager / file manager")
        val pm = ctx.packageManager
        val installedTools = mutableListOf<String>()

        for (pkg in CheatSignatures.TOOL_PACKAGES) {
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getApplicationInfo(pkg, 0)
                }
                installedTools += pkg
            } catch (_: PackageManager.NameNotFoundException) { }
        }

        if (installedTools.isEmpty()) {
            ok("tidak ada MT Manager / tool sejenis")
            return
        }
        installedTools.forEach { info("tool terpasang: $it (cek apakah pernah sentuh FF)") }

        val kw = Regex("(?i)(freefire|free fire|com\\.dts\\.freefire|com\\.garena\\.game\\.kg|libil2cpp|libunity|base\\.apk)")
        var evidence = 0

        // public storage
        val publicRoots = listOf(
            "/sdcard", "/storage/emulated/0",
            "/storage/emulated/0/Download",
            "/storage/emulated/0/MT2", "/storage/emulated/0/MTManager", "/storage/emulated/0/mt2"
        )
        for (root in publicRoots) {
            val dir = File(root)
            if (!dir.exists() || !dir.canRead()) continue
            try {
                dir.walkTopDown().maxDepth(4)
                    .filter { it.isFile && (it.extension.equals("apk", true) || it.extension.equals("bak", true)) }
                    .filter { kw.containsMatchIn(it.name) || kw.containsMatchIn(it.absolutePath) }
                    .take(15)
                    .forEach {
                        found(
                            CheatSignatures.Kind.PATCHED_APK,
                            "salinan APK FF di storage: ${it.name}",
                            it.absolutePath
                        )
                        evidence++
                    }
            } catch (_: Exception) { }
        }

        if (rootAvailable) {
            for (pkg in installedTools) {
                val dataDir = "/data/data/$pkg"
                val grepCmd = """
                    grep -rE 'freefire|com\.dts\.freefire|com\.garena\.game\.kg|libil2cpp|base\.apk' \
                      $dataDir --include='*.xml' --include='*.log' --include='*.txt' \
                      --include='*.json' --include='*recent*' --include='*history*' 2>/dev/null | head -30
                """.trimIndent().replace("\n", " ")
                val grepOut = su(grepCmd, 12)
                if (grepOut.isNotBlank()) {
                    grepOut.lines().filter { it.isNotBlank() }.take(10).forEach {
                        found(
                            CheatSignatures.Kind.PATCHED_APK,
                            "MT Manager pernah buka/edit file FF",
                            it.take(120)
                        )
                        evidence++
                    }
                }
                val findApk = su("find $dataDir -type f \\( -iname '*freefire*.apk' -o -iname '*ff*.apk' -o -name 'base.apk' -o -name '*.bak' \\) 2>/dev/null | head -15")
                if (findApk.isNotBlank()) {
                    findApk.lines().filter { it.isNotBlank() }.forEach {
                        found(CheatSignatures.Kind.PATCHED_APK, "APK FF di data $pkg", it)
                        evidence++
                    }
                }
            }
        } else {
            info("scan data MT Manager butuh root (storage publik sudah dicek)")
        }

        if (evidence == 0) {
            ok("tool terpasang tapi tidak ada jejak menyentuh Free Fire")
        } else {
            info("$evidence jejak konkret tool ↔ Free Fire")
        }
    }

    // ── 11. Hidden / renamed panels (next-level) ─────────────
    // Menangkap panel yang package-nya di-rename tapi:
    //  - label masih mengandung yonso/dript/panel/mod menu
    //  - punya SYSTEM_ALERT_WINDOW / accessibility
    //  - atau proses/path residual brand

    private fun scanHiddenPanels() {
        section("11. Panel tersembunyi / di-rename")
        val pm = ctx.packageManager
        var hit = 0

        // A. Scan SEMUA package by label (bukan cuma list hardcoded)
        try {
            val apps = if (Build.VERSION.SDK_INT >= 33) {
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledApplications(0)
            }
            for (ai in apps) {
                val pkg = ai.packageName
                if (pkg in CheatSignatures.FF_OFFICIAL || pkg in CheatSignatures.TOOL_PACKAGES) continue
                if (pkg.startsWith("com.android.") || pkg.startsWith("com.google.")) continue

                val label = try { pm.getApplicationLabel(ai).toString() } catch (_: Exception) { "" }
                val combined = "$pkg $label"

                // brand / panel label hit even if package random
                if (CheatSignatures.PANEL_LABEL_REGEX.containsMatchIn(combined) ||
                    CheatSignatures.CHEAT_NAME_REGEX.containsMatchIn(label)) {
                    // skip if already reported in layer 1
                    val already = findings.any { it.detail.contains(pkg) }
                    if (!already) {
                        val kind = CheatSignatures.classifyPackage(pkg, label)
                        found(kind, "panel by label: $pkg ($label)")
                        hit++
                    }
                }

                // overlay permission + suspicious label
                val hasOverlay = try {
                    if (Build.VERSION.SDK_INT >= 23) {
                        android.provider.Settings.canDrawOverlays(ctx) // device-level; per-app below
                        false
                    } else false
                } catch (_: Exception) { false }

                // check AppOps / permission flag for SYSTEM_ALERT_WINDOW on this package
                val wantsOverlay = try {
                    val pi = if (Build.VERSION.SDK_INT >= 33) {
                        pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
                    }
                    pi.requestedPermissions?.any {
                        it == android.Manifest.permission.SYSTEM_ALERT_WINDOW ||
                        it == "android.permission.SYSTEM_ALERT_WINDOW"
                    } == true
                } catch (_: Exception) { false }

                if (wantsOverlay && (
                        CheatSignatures.PANEL_LABEL_REGEX.containsMatchIn(combined) ||
                        CheatSignatures.CHEAT_NAME_REGEX.containsMatchIn(combined)
                    )) {
                    val already = findings.any { it.detail.contains(pkg) }
                    if (!already) {
                        val kind = CheatSignatures.classifyPackage(pkg, label)
                        found(kind, "overlay+panel pattern: $pkg ($label)")
                        hit++
                    }
                }
            }
        } catch (e: Exception) {
            info("scan label gagal: ${e.message}")
        }

        // B. Residual path / process for brand names (yonso, dript)
        for (p in listOf(
            "/data/local/tmp/yonso", "/data/local/tmp/yoonso",
            "/data/local/tmp/dript", "/data/local/tmp/drip",
            "/data/local/tmp/dripclient", "/sdcard/yonso", "/sdcard/dript"
        )) {
            if (fileExists(p)) {
                found(CheatSignatures.classify(p), "residual path: $p")
                hit++
            }
        }

        if (rootAvailable) {
            val brandProc = su(
                "ps -A 2>/dev/null | grep -iE 'yonso|yoonso|dript|dripclient|drip' | grep -v grep | head -15"
            )
            if (brandProc.isNotBlank()) {
                brandProc.lines().filter { it.isNotBlank() }.forEach {
                    found(CheatSignatures.classify(it), "proses brand: ${it.trim().take(80)}")
                    hit++
                }
            }
            val brandFind = su(
                "find /data/local/tmp /data/adb /sdcard -maxdepth 3 " +
                "\( -iname '*yonso*' -o -iname '*yoonso*' -o -iname '*dript*' -o -iname '*dripclient*' \) " +
                "2>/dev/null | head -20"
            )
            if (brandFind.isNotBlank()) {
                brandFind.lines().filter { it.isNotBlank() }.forEach {
                    found(CheatSignatures.classify(it), "file brand: $it")
                    hit++
                }
            }
        }

        // C. FF installed + many overlay-capable non-system apps (heuristic)
        val ffInstalled = CheatSignatures.FF_OFFICIAL.any { pkg ->
            try {
                if (Build.VERSION.SDK_INT >= 33) {
                    pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getApplicationInfo(pkg, 0)
                }
                true
            } catch (_: Exception) { false }
        }
        if (ffInstalled && hit == 0) {
            info("FF terpasang; tidak ada panel by-label / residual brand")
        }

        if (hit == 0) ok("tidak ada panel tersembunyi terdeteksi")
        else info("$hit temuan panel/brand (termasuk yang package-nya di-rename)")
    }
}
