package com.azx.scanner

/**
 * Signature DB + klasifikasi jenis cheat.
 *
 * Mapping khusus (permintaan):
 *   Yonso / Yoonso  → PROXY
 *   Dript / Drip    → MOD_MENU
 */
object CheatSignatures {

    enum class Kind(val label: String, val contoh: String) {
        MOD_MENU(
            "Mod Menu",
            "menu floating (ESP, aimbot, wallhack, headshot, auto aim)"
        ),
        MEMORY_EDITOR(
            "Memory Editor",
            "GameGuardian / tool sejenis yang ubah nilai HP, damage, dll di RAM"
        ),
        INJECTOR(
            "Injector",
            "Frida / Dobby / libgadget / libhook — suntik kode ke proses game"
        ),
        PROXY(
            "Proxy / Traffic Tool",
            "proxy / tool traffic / panel yang mengintervensi koneksi game"
        ),
        COPILOT(
            "Copilot / Auto Helper",
            "script / bot yang bantu aim, loot, atau gerakan otomatis (sering lewat accessibility)"
        ),
        PATCHED_APK(
            "Patched APK",
            "base.apk Free Fire yang sudah diubah / di-sign ulang"
        ),
        HOOK_FRAMEWORK(
            "Hook Framework",
            "LSPosed / Xposed / Riru / Zygisk module yang bisa load cheat ke game"
        ),
        TOOL(
            "Tool (bukan cheat)",
            "MT Manager, APK Editor, dll — hanya mencurigakan jika pernah sentuh file FF"
        ),
        UNKNOWN(
            "Tidak dikenal",
            "jejak mencurigakan tapi tipenya belum bisa dipastikan"
        )
    }

    data class Finding(
        val kind: Kind,
        val detail: String,
        val evidence: String = ""
    )

    val FF_OFFICIAL = setOf(
        "com.dts.freefireth",
        "com.dts.freefiremax",
        "com.garena.game.kgth",
        "com.garena.game.kgvn",
        "com.garena.game.kgtw",
        "com.garena.game.kgid"
    )

    val TOOL_PACKAGES = setOf(
        "bin.mt.plus", "bin.mt.plus.canary", "bin.mt.plus.na", "com.mt.plus",
        "com.gmail.heagoo.apkeditor", "com.gmail.heagoo.apkeditor.pro",
        "com.aefyr.sai", "com.aefyr.sai.fdroid",
        "com.termux", "ru.zdevs.zarchiver",
        "com.mixplorer", "com.mixplorer.silver"
    )

    // Package exact → Kind
    val PACKAGE_KIND = mapOf(
        // ── Yonso / Yoonso → PROXY ──
        "com.yonso" to Kind.PROXY,
        "com.yonso.mod" to Kind.PROXY,
        "com.yonso.vip" to Kind.PROXY,
        "com.yoonso" to Kind.PROXY,
        "com.yoonso.mod" to Kind.PROXY,
        "com.yoonso.vip" to Kind.PROXY,
        "com.yonso.ff" to Kind.PROXY,
        "com.yoonso.ff" to Kind.PROXY,
        // ── Dript / Drip Client → MOD_MENU ──
        "com.dript" to Kind.MOD_MENU,
        "com.dript.client" to Kind.MOD_MENU,
        "com.drip.client" to Kind.MOD_MENU,
        "com.dripclient" to Kind.MOD_MENU,
        "com.drip.mod" to Kind.MOD_MENU,
        "com.dript.mod" to Kind.MOD_MENU,
        "com.drip.ff" to Kind.MOD_MENU,
        "com.dript.ff" to Kind.MOD_MENU,
        // classic mod menus
        "com.dts.freefireth.mod" to Kind.MOD_MENU,
        "com.dts.freefiremax.mod" to Kind.MOD_MENU,
        "com.ff.mod" to Kind.MOD_MENU,
        "com.ffmod" to Kind.MOD_MENU,
        "com.freefire.mod" to Kind.MOD_MENU,
        "com.garena.mod" to Kind.MOD_MENU,
        "com.modmenu.ff" to Kind.MOD_MENU,
        "com.aimbot.ff" to Kind.MOD_MENU,
        "com.esp.ff" to Kind.MOD_MENU,
        "com.headshot.ff" to Kind.MOD_MENU,
        "com.wallhack.ff" to Kind.MOD_MENU,
        "com.autoaim.ff" to Kind.MOD_MENU,
        // memory
        "com.gameguardian" to Kind.MEMORY_EDITOR,
        // patcher
        "com.luckypatcher" to Kind.PATCHED_APK,
        "com.chelpus.lackypatch" to Kind.PATCHED_APK,
        "com.android.vending.billing.InAppBillingService.COIN" to Kind.PATCHED_APK,
        // hook
        "org.lsposed.manager" to Kind.HOOK_FRAMEWORK,
        "io.github.lsposed.manager" to Kind.HOOK_FRAMEWORK,
        "de.robv.android.xposed.installer" to Kind.HOOK_FRAMEWORK,
        "org.meowcat.edxposed.manager" to Kind.HOOK_FRAMEWORK,
        "com.saurik.substrate" to Kind.HOOK_FRAMEWORK,
        "com.topjohnwu.magisk" to Kind.HOOK_FRAMEWORK,
        "io.github.huskydg.magisk" to Kind.HOOK_FRAMEWORK,
        "com.rifsxd.ksunext" to Kind.HOOK_FRAMEWORK,
        "me.weishu.kernelsu" to Kind.HOOK_FRAMEWORK,
        "com.apatch" to Kind.HOOK_FRAMEWORK
    )

    val CHEAT_PACKAGES = PACKAGE_KIND.keys.filterNot { it in FF_OFFICIAL || it in TOOL_PACKAGES }.toSet()

    /**
     * Keyword → Kind. Order = priority (first match wins).
     * Yonso/Yoonso forced to PROXY, Dript/Drip forced to MOD_MENU.
     */
    private val KEYWORD_KIND = listOf(
        // forced brand mapping first
        Regex("(?i)(yonso|yoonso)") to Kind.PROXY,
        Regex("(?i)(dript|drip\\s*client|dripclient|drip\\s*mod|drip\\s*panel|drip\\s*ff)") to Kind.MOD_MENU,
        // generic
        Regex("(?i)(modmenu|mod.?menu|floating.?menu|panel.?ff|ff.?panel)") to Kind.MOD_MENU,
        Regex("(?i)(aimbot|auto.?aim|headshot|wallhack|esp\\b|magnet|aim.?kill|teleport)") to Kind.MOD_MENU,
        Regex("(?i)(gameguardian|\\bgg\\b|libgg)") to Kind.MEMORY_EDITOR,
        Regex("(?i)(frida|libfrida|frida-server|frida-gadget|re\\.frida)") to Kind.INJECTOR,
        Regex("(?i)(dobby|libdobby|libhook|libinject|libgadget|substrate)") to Kind.INJECTOR,
        Regex("(?i)(proxy|http.?canary|charles|mitm|packet.?capture|pcap|wireshark|netys)") to Kind.PROXY,
        Regex("(?i)(copilot|auto.?play|auto.?loot|script.?bot|accessibility.?bot)") to Kind.COPILOT,
        Regex("(?i)(lsposed|xposed|edxposed|riru|zygisk)") to Kind.HOOK_FRAMEWORK,
        Regex("(?i)(lucky.?patcher|re.?sign|patched|modded.?apk)") to Kind.PATCHED_APK
    )

    fun classify(text: String): Kind {
        for ((re, kind) in KEYWORD_KIND) {
            if (re.containsMatchIn(text)) return kind
        }
        return Kind.UNKNOWN
    }

    fun classifyPackage(pkg: String, label: String = ""): Kind {
        PACKAGE_KIND[pkg]?.let { return it }
        // substring brand check on package name itself
        val lower = pkg.lowercase()
        when {
            lower.contains("yonso") || lower.contains("yoonso") -> return Kind.PROXY
            lower.contains("dript") || lower.contains("dripclient") ||
                (lower.contains("drip") && (lower.contains("client") || lower.contains("mod") || lower.contains("ff"))) ->
                return Kind.MOD_MENU
        }
        return classify("$pkg $label")
    }

    // Broad name/label regex used in package scan
    val CHEAT_NAME_REGEX = Regex(
        "(?i)(yonso|yoonso|dript|drip\\s*client|dripclient|modmenu|headshot|aimbot|wallhack|esp|" +
        "autoaim|freefire.*mod|ff.*hack|garena.*mod|libhook|libinject|libgadget|dobby|frida|" +
        "substrate|xposed|lsposed|riru|zygisk|gameguardian|gg\\b|lucky.?patcher|cheat|hack.?menu|" +
        "proxy|copilot|auto.?play|ff.?panel|panel.?ff|netys|aim.?kill)",
        RegexOption.IGNORE_CASE
    )

    // Paths that indicate injector / panel residual
    val CHEAT_PATHS = listOf(
        "/data/local/tmp/frida-server",
        "/data/local/tmp/re.frida.server",
        "/data/local/tmp/fs",
        "/data/local/tmp/gg",
        "/data/local/tmp/gameguardian",
        "/data/local/tmp/drip",
        "/data/local/tmp/dript",
        "/data/local/tmp/yonso",
        "/data/local/tmp/yoonso",
        "/data/adb/frida",
        "/data/adb/modules/riru",
        "/data/adb/modules/zygisk",
        "/data/adb/modules/lsposed",
        "/data/adb/modules/shamiko"
    )

    val ROOT_INFO_PATHS = listOf(
        "/data/adb/magisk", "/data/adb/ksu", "/data/adb/ap", "/data/adb/modules",
        "/sbin/su", "/system/bin/su", "/system/xbin/su",
        "/data/local/su", "/system/app/Superuser.apk",
        "/dev/.magisk", "/sbin/.magisk"
    )

    val INJECTOR_STRINGS = listOf(
        "frida", "libfrida", "re.frida", "frida-agent", "frida-gadget",
        "libdobby", "dobby", "libhook", "libinject", "libgadget",
        "lsposed", "xposed", "edxposed", "riru", "zygisk",
        "substrate", "cydia", "gameguardian", "libgg",
        "modmenu", "aimbot", "wallhack", "il2cpp_hook", "unity_hook",
        "proxy", "copilot", "yonso", "yoonso", "dript", "dripclient", "drip_client"
    )

    val CHEAT_PROCESS_REGEX = Regex(
        "(?i)(frida|gg|gameguardian|cheat|hack|modmenu|injector|dobby|" +
        "lsposed|xposed|riru|substrate|proxy|copilot|mitm|" +
        "yonso|yoonso|dript|dripclient|drip.?client|drip.?mod)",
        RegexOption.IGNORE_CASE
    )

    val SUSPICIOUS_SERVICES = listOf(
        "accessibility", "overlay", "floating", "modmenu", "esp", "aim",
        "copilot", "yonso", "yoonso", "dript", "drip"
    )

    /** Label patterns that look like paid panel even if package is random */
    val PANEL_LABEL_REGEX = Regex(
        "(?i)(yonso|yoonso|dript|drip\\s*client|vip\\s*menu|mod\\s*menu|ff\\s*panel|" +
        "panel\\s*ff|aim\\s*kill|esp\\s*menu|headshot\\s*menu|antiban\\s*panel)",
        RegexOption.IGNORE_CASE
    )
}
