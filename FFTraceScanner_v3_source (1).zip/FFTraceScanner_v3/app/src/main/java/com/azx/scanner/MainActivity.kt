package com.azx.scanner

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var btnScan: Button
    private lateinit var tvResult: TextView
    private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnScan = findViewById(R.id.btnScan)
        tvResult = findViewById(R.id.tvResult)

        btnScan.setOnClickListener {
            if (scanning) return@setOnClickListener
            startScan()
        }
    }

    private fun startScan() {
        scanning = true
        btnScan.isEnabled = false
        btnScan.text = getString(R.string.scanning)
        tvResult.text = "Memulai scan…\n"

        lifecycleScope.launch {
            val engine = ScannerEngine(applicationContext)
            val result = withContext(Dispatchers.IO) {
                engine.runFullScan { progress ->
                    runOnUiThread {
                        tvResult.append("$progress\n")
                    }
                }
            }
            tvResult.text = result
            btnScan.isEnabled = true
            btnScan.text = getString(R.string.scan_now)
            scanning = false
        }
    }
}
