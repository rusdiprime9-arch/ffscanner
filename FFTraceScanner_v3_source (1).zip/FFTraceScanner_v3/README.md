# AZX Scanner v3

Improved rewrite of the original `2.0-warn` debug APK.

## Fixes vs original

| Issue | Original | v3 |
|-------|----------|----|
| Icon | system default `@0x01080041` (missing) | custom vector launcher icon |
| versionName | `2.0-warn` | `3.0` |
| Signing | Android Debug only | release buildType ready (sign with your keystore) |
| Package list | 4–5 hardcoded | expanded + regex name/label match |
| Integrity | MD5 only | SHA-256 + cert DN + cert SHA-256 + re-sign heuristic |
| Layers | 7 | 10 (accessibility/overlay + network + MT Manager traces) |
| Root handling | mixed | root = INFO only, never counted as cheat |
| MT Manager | flagged as SUSPICIOUS_PKG | INFO only; finding only if FF files were touched |
| UI | static text | progress updates per layer |

## Detection layers

1. Package scan (name + label + regex) — tools like MT Manager = INFO only
2. Filesystem trace (known paths + deep `find`/`strings` via su)
3. `/proc` maps + mount namespace
4. Kernel / SELinux / property (info)
5. Free Fire APK integrity (SHA-256 + signing cert)
6. Process trace
7. Hidden / renamed binary
8. Accessibility / overlay services
9. Network sockets (Frida 27042, GG, common gadget ports)
10. **MT Manager / file-manager traces** — only counts when FF files were actually touched
    (data-dir history, recent, APK copies, work/sign dirs; public storage checked without root)

## Build

```bash
# open in Android Studio or:
cd AZXScanner
# ensure local.properties points to SDK
./gradlew assembleRelease   # or assembleDebug
```

APK output:
- `app/build/outputs/apk/release/app-release-unsigned.apk` (sign it)
- `app/build/outputs/apk/debug/app-debug.apk`

## Limits (honest)

Static signatures + integrity + process snapshots **cannot** reach 100%.

Still missable:
- pure memory cheats with no file / no process name
- fully renamed packages + stripped strings
- custom injectors that never listen on known ports
- short-lived processes between scan snapshots

For higher coverage you need continuous sensors (memory pattern, syscall monitor, ACE live status). This build is the strongest practical static scanner from the previous surface.

## Package

`com.azx.scanner`  
minSdk 24 · targetSdk 34 · Kotlin
